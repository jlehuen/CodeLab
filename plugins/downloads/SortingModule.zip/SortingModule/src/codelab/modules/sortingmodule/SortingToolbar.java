package codelab.modules.sortingmodule;

import codelab.AbstractToolbar;
import codelab.ToolButton;
import java.awt.Dimension;
import javax.swing.ImageIcon;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class SortingToolbar extends AbstractToolbar {

	private ImageIcon icon_pause_on = loadImageIcon("icon_pause_on.png");
	private ImageIcon icon_pause_off = loadImageIcon("icon_pause_off.png");
	private ToolButton pauseButton;
	private JSlider slider;

	///////////////////////////////////////////////////
	// Constructor
	///////////////////////////////////////////////////

	public SortingToolbar(SortingModule module) {
		super(module);
		addSeparator();

		slider = new JSlider(JSlider.HORIZONTAL, 0, 1000, 500); // min-max-init
		slider.setPreferredSize(new Dimension(130, 20));
		slider.setMaximumSize(new Dimension(130, 20));
		slider.setMinimumSize(new Dimension(130, 20));
		slider.setToolTipText("Vitesse d'exécution");
		slider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				module.setSpeed(slider.getValue());
			}
		});

		add(pauseButton = new ToolButton("PAUSE", "Pause", "Mettre une pause", icon_pause_off, this));
		add(slider);
		endToolbar();
	}

	///////////////////////////////////////////////////
	// Button updating
	///////////////////////////////////////////////////

	public void update() {
		super.update();
	}

	///////////////////////////////////////////////////
	// Action handler
	///////////////////////////////////////////////////

	public void action(String ident) {
		switch (ident) {
			case "PAUSE": action_pause(); break;
			default: super.action(ident);
		}
	}

	private void action_pause() {
		Histogram histogram = ((SortingModule)module).getHisto();
		if (histogram.PAUSE) {
			pauseButton.setIcon(icon_pause_off);
			histogram.PAUSE = false;
		}
		else {
			pauseButton.setIcon(icon_pause_on);
			histogram.PAUSE = true;
		}
	}
}
