package codelab.modules.sortingmodule;

import codelab.CodeLab;
import codelab.AbstractModule;

import java.util.Map;

/**
*	Main class of the Sorting module
*	@author Jérôme Lehuen
*	@version 10/03/23
*/

public class SortingModule extends AbstractModule {

	private Histogram panel;

	///////////////////////////////////////////////////
	// Constructor
	///////////////////////////////////////////////////

	public SortingModule(CodeLab codelab) {
		super(codelab);
		loadProperties("lang.properties");
		setTitle(getLangProperty("title"));
		setToolbar(new SortingToolbar(this));
		setComponent(panel = new Histogram(codelab));
	}

	///////////////////////////////////////////////////
	// AbstractModule methods to implement
	///////////////////////////////////////////////////

	public void init() {
	}
	public void exit() {
	}
	public void start() {
	}
	public void stop() {
	}
	public void reset() {
	}

	///////////////////////////////////////////////////
	// Other public methodes
	///////////////////////////////////////////////////

	public Histogram getHisto() {
		return panel;
	}

	public void setSpeed(int speed) {
		panel.setSpeed(speed);
	}

	///////////////////////////////////////////////////
	// Instruction handler
	///////////////////////////////////////////////////

	public String handleRequest(Map<String, String> params) {
		String cmd = params.get("cmd");
		int index, value, size;
		int index1, index2;
		switch (cmd) {

			case "redraw":
				return String.valueOf(panel.redraw());

			case "getValue":
				index = Integer.valueOf(params.get("index"));
				return String.valueOf(panel.getValue(index));

			case "setValue":
				index = Integer.valueOf(params.get("index"));
				value = Integer.valueOf(params.get("value"));
				return String.valueOf(panel.setValue(index, value));

			case "setSize":
				size = Integer.valueOf(params.get("size"));
				return String.valueOf(panel.setSize(size));

			case "swapValues":
				index1 = Integer.valueOf(params.get("index1"));
				index2 = Integer.valueOf(params.get("index2"));
				return String.valueOf(panel.swapValues(index1, index2));

			default:
				return unknownCommandError(cmd);
		}
	}
}
