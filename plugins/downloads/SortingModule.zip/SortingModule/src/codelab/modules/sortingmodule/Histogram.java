package codelab.modules.sortingmodule;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;

import javax.swing.JPanel;

import codelab.CodeLab;

/**
*	Histogram viewer class
*	@author Jérôme Lehuen
*	@version 10/03/23
*/

public class Histogram extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final Color COLOR1 = new Color(250, 100, 100);
	private static final Color COLOR2 = new Color(250, 200, 150);
	private static final int XOFFSET = 11; // Left and right margins
	private static final int YOFFSET = 30; // Up and bottom margins
	
	private CodeLab codelab; // Pour les messages d'erreur

	private int[] data;
	private int size;
	private int maxValue;
	private int lastIndex1 = -1;
	private int lastIndex2 = -1;
	private int delay = 500;

	public boolean PAUSE = false;

	///////////////////////////////////////////////////
	// Constructor
	///////////////////////////////////////////////////

	public Histogram(CodeLab codelab) {
		this.codelab = codelab;
	}

	///////////////////////////////////////////////////
	// Public methods
	///////////////////////////////////////////////////

	public int redraw() {
        maxValue = Arrays.stream(data).max().getAsInt();
		repaint();
		return 1;
	}

	public void setSpeed(int speed) {
		delay = 1000 - speed;
	}

	public int setSize(int size) {
		data = new int[size];
		this.size = size;
		return 1;
	}

	public int getValue(int index) {
		return data[index];
	}

	public int setValue(int index, int value) {
		data[index] = value;
		lastIndex1 = index;
		lastIndex2 = -1;
		repaint();
		return 1;
	}

	public int swapValues(int index1, int index2) {
		lastIndex1 = index1;
		lastIndex2 = index2;
		repaint();
		if (delay > 0) sleep(delay);
		while (PAUSE) sleep(10);
		try {
			int v1 = data[index1];
			int v2 = data[index2];
			data[index1] = v2;
			data[index2] = v1;
		}
		catch (ArrayIndexOutOfBoundsException e) {
			String msg = String.format("RUNTIME ERROR: Can't swap %d and %d (index out of bounds)", index1, index2);
			codelab.printlnToConsole(msg, Color.RED);
			codelab.halt();
			return -1;
		}
		repaint();
		if (delay > 0) sleep(delay);
		while (PAUSE) sleep(10);
		return 1;
	}

	///////////////////////////////////////////////////
	// Private methods
	///////////////////////////////////////////////////

	private static void sleep(int ms) {
		try { Thread.sleep(ms); }
		catch (InterruptedException e) {}
	}

	///////////////////////////////////////////////////
	// Histogram display
	///////////////////////////////////////////////////

	protected void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		int width = getWidth() - (XOFFSET * 2);
		int height = getHeight() - (YOFFSET * 2);
		float barWidth = (float) width / size; // Width of the bars

		Graphics2D g2d = getGraphics2D(graphics);
		g2d.setColor(Color.DARK_GRAY);
		g2d.drawLine(XOFFSET, height+YOFFSET, width-XOFFSET, height+YOFFSET);

		float x = (float) XOFFSET;
		for (int i = 0; i < size; i++) {
			int value = data[i];
			int barHeight = Math.round(((float) value / (float) maxValue) * height); // Height of the bar
			int y = height - barHeight + YOFFSET;
			Rectangle2D bar = new Rectangle2D.Float(x, y, barWidth, barHeight);
			String index_str = String.valueOf(i);
			String value_str = String.valueOf(value);
			int w1 = g2d.getFontMetrics().stringWidth(value_str) / 2; // Half text width
			int w2 = g2d.getFontMetrics().stringWidth(index_str) / 2; // Half text width
			if (i == lastIndex1 || i == lastIndex2) g2d.setColor(COLOR1);
			else g2d.setColor(COLOR2);
			g2d.fill(bar);
			g2d.setColor(Color.DARK_GRAY);
			g2d.draw(bar);
			g2d.setColor(Color.BLACK);
			g2d.drawString(value_str, x + (float) barWidth / 2 - w1, y - 5);
			g2d.drawString(index_str, x + (float) barWidth / 2 - w2, height + YOFFSET + 20);
			x += barWidth;
		}
		g2d.dispose();
	}

	private Graphics2D getGraphics2D(Graphics graphics) {
		Graphics2D g2d = (Graphics2D) graphics;
		g2d.setRenderingHint(
			RenderingHints.KEY_ANTIALIASING,
			RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.setRenderingHint(
			RenderingHints.KEY_TEXT_ANTIALIASING,
			RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		return g2d;
	}
}
