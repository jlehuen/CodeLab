#####################################################################
##  This file is part of the software CodeLab IDE and Simulators   ##
##  Python language example program - Sorting module               ##
##  Author: Jérôme Lehuen                                          ##
#####################################################################

from codelab.sortingmodule.panel import *
from codelab.utils import *
import random

def swap(tab, i1, i2):
	if i1 == i2: return
	tab[i1], tab[i2] = tab[i2], tab[i1]
	print('Swapping %d and %d' % (i1, i2))
	swapValues(i1, i2) # Update the panel

def partition(tab, low, high):
	i = low - 1
	pivot = tab[high]
	print('Pivot =', pivot)
	for j in range(low, high):
		if tab[j] <= pivot:
			i = i + 1
			swap(tab, i, j)
	swap(tab, i+1, high)
	return (i+1)

def quickSort(tab, low, high):
	if low < high:
		partition_index = partition(tab, low, high)
		quickSort(tab, low, partition_index-1)
		quickSort(tab, partition_index+1, high)

tab = [random.randint(0, 10) for i in range(50)]
initValues(tab) # Update the panel
t0 = systemTime()
quickSort(tab, 0, len(tab)-1) # Sort the array
dt = systemTime() - t0
print('Execution time = %d ms' % dt)
