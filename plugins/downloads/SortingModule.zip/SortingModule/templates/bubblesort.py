#####################################################################
##  This file is part of the software CodeLab IDE and Simulators   ##
##  Python language example program - Sorting module               ##
##  Author: Jérôme Lehuen                                          ##
#####################################################################

from codelab.sortingmodule.panel import *
from codelab.utils import *
import random

def swap(tab, i1, i2):
	if i1 == i2: return
	tab[i1], tab[i2] = tab[i2], tab[i1]
	print('Swapping %d and %d' % (i1, i2))
	swapValues(i1, i2) # Update the panel

def bubble_sort(tableau):
	for i in range(len(tab)-1, 0, -1):
		for j in range(i):
			if tab[j] > tab[j+1]:
				swap(tab, j, j+1)

tab = [random.randint(0, 10) for i in range(50)]
initValues(tab) # Update the panel
t0 = systemTime()
bubble_sort(tab) # Sort the array
dt = systemTime() - t0
print('Execution time = %d ms' % dt)
