package codelab.modules.hellomodule;

import codelab.AbstractModule;
import codelab.CodeLab;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.util.Map;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class HelloModule extends AbstractModule {

	private JPanel panel; // Or any other JComponent
	private JLabel label; // The content of the panel

	///////////////////////////////////////////////////
	// Constructor
	///////////////////////////////////////////////////

	public HelloModule(CodeLab codelab) {
		super(codelab);
		loadProperties("lang.properties");
		setTitle(getLangProperty("title"));
		setToolbar(new HelloToolbar(this));
		setComponent(panel = new JPanel());
		panel.setLayout(new GridBagLayout());
		panel.add(label = new JLabel());
	}

	///////////////////////////////////////////////////
	// AbstractModule methods to implement
	///////////////////////////////////////////////////

	public void init() {
	}
	public void exit() {
	}
	public void start() {
	}
	public void stop() {
	}
	public void reset() {
	}

	///////////////////////////////////////////////////
	// Other public methodes
	///////////////////////////////////////////////////

	public int setText(String str) {
		label.setText(str);
		return 1;
	}

	public int setFont(String name, int size) {
		label.setFont(new Font(name, 1, size));
		return 1;
	}

	public int clear() {
		panel.removeAll();
		panel.add(label = new JLabel());
		panel.repaint();
		return 1;
	}

	///////////////////////////////////////////////////
	// Instruction handler
	///////////////////////////////////////////////////

	public String handleRequest(Map<String, String> params) {
		String cmd = params.get("cmd");
		switch (cmd) {

			case "setText":
				String str = params.get("str");
				return String.valueOf(setText(str));

			case "setFont":
				String name = params.get("name");
				int size = Integer.valueOf(params.get("size"));
				return String.valueOf(setFont(name, size));

			default:
				return unknownCommandError(cmd);
		}
	}
}
