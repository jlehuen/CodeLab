package codelab.modules.hellomodule;

import codelab.AbstractToolbar;
import codelab.ToolButton;

import java.awt.Color;
import javax.swing.ImageIcon;

public class HelloToolbar extends AbstractToolbar {

	private ImageIcon icon_hello = loadImageIcon("icon_hello.png");
	private ImageIcon icon_clear = loadImageIcon("icon_clear.png");

	///////////////////////////////////////////////////
	// Constructor
	///////////////////////////////////////////////////

	public HelloToolbar(HelloModule module) {
		super(module);
		addSeparator();

		add(new ToolButton("HELLO",
			getLangProperty("btn_hello"),
			getLangProperty("btn_hello_tooltip"), icon_hello, this));

		add(new ToolButton("CLEAR",
			getLangProperty("btn_clear"),
			getLangProperty("btn_clear_tooltip"), icon_clear, this));

		endToolbar();
	}

	///////////////////////////////////////////////////
	// Action handler
	///////////////////////////////////////////////////

	public void action(String ident) {
		switch (ident) {
			case "HELLO": action_hello(); break;
			case "CLEAR": action_clear(); break;
			default: super.action(ident);
		}
	}

	private void action_hello() {
		((HelloModule)module).setFont("Times new Roman", 30);
		((HelloModule)module).setText("Hello World!");
	}

	private void action_clear() {
		((HelloModule)module).clear();
	}
}
