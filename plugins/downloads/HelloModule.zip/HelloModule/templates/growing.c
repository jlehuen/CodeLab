/*
 * Program _fileName_
 * Created by _author_ on _date_
 */

#include "codelab/hellomodule/HelloBase.c"

int main() {
	setText("Hello World!");
	for (int size = 0; size < 50; size++)
		setFont("Times new Roman", size);
	return 0;
}
