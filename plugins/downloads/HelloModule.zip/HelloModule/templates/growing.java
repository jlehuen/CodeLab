/*
 * Class _className_
 * Created by _author_ on _date_
 */

import codelab.hellomodule.HelloBase;

class _className_ extends HelloBase {

	private void run() {
		setText("Hello World!");
		for (int size = 0; size < 50; size++)
			setFont("Times new Roman", size);
	}

	public static void main(String args[]) {
		new _className_().run();
	}
}
