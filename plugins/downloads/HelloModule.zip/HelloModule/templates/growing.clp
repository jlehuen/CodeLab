;; Program _fileName_
;; Created by _author_ on _date_

#requires codelab.hellomodule.HelloBase

(defrule only-rule
	=>
	(setText "Hello World!")
	(loop-for-count (?size 0 50)
		(setFont "Times new Roman" ?size)))
