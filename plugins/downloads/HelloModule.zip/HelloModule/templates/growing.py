## Program _fileName_
## Created by _author_ on _date_

from codelab.hellomodule.HelloBase import *

setText('Hello World!')
for size in range(0, 50):
	setFont('Times new Roman', size)
