package codelab.modules.turtlemodule;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Font;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.imageio.ImageIO;

import codelab.CodeLab;

public class TurtleCanvas extends JPanel {
	
	public final int WIDTH = 2000;
	public final int HEIGHT = 1500;
	
	private BufferedImage background;
	private BufferedImage background_saved;
	private Rectangle background_rectangle;
	private int background_index = 0;
		
	private Graphics2D backgroundG2D;
	private Color color = Color.BLACK;
	
	private TurtleModule module;
	private TurtleListener listener;
	private Turtle turtle;

	public boolean DEBUG = false;
	
	///////////////////////////////////////////////////
	// Constructeur
	///////////////////////////////////////////////////
	
	public TurtleCanvas(TurtleModule module) {
		this.module = module;
		turtle = new Turtle(this);
		
		// Background blanc par défaut
		Dimension size = new Dimension(WIDTH, HEIGHT);
		setBackgroundImage(Utils.createBackground(size, Color.WHITE));
		
		// Ajout du listener de souris
		listener = new TurtleListener(this, turtle);
		addMouseListener(listener);
		addMouseMotionListener(listener);
		addMouseWheelListener(listener);
	}
	
	///////////////////////////////////////////////////
	// Méthodes publiques
	///////////////////////////////////////////////////
	
	public void reset() {
		turtle.reset();
		repaint();
	}
	
	public void turtleSwitch() {
		turtle.visible = !turtle.visible;
		repaint();
	}
	
	public void setBackgroundImage(BufferedImage image) {
		int largeur = image.getWidth();
		int hauteur = image.getHeight();
		background_saved = image;
		background_rectangle = new Rectangle(largeur, hauteur);
		clearScreen();
	}
	
	public void setBackgroundFromSelector(BufferedImage image, int index) {
		setBackgroundImage(image);
		background_index = index;
	}
	
	public BufferedImage getBackgroundImage() {
		return background_saved;
	}
	
	public Rectangle getBackgroundRectangle() {
		return background_rectangle;
	}
	
	public int getBackgroundIndex() {
		return background_index;
	}
	
	public void paint(Graphics g) {
		Dimension d = getSize();
		Image offScreenImage = createImage(d.width, d.height);
		Graphics offScreenGraphics = offScreenImage.getGraphics();
		offScreenGraphics.drawImage(background, 0, 0, null);
		if (DEBUG) drawCoordinates(offScreenGraphics);
		drawTurtle(offScreenGraphics);
		g.drawImage(offScreenImage, 0, 0, null);
	}

	public void drawTurtle(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		Utils.configureRender(g2d);
		turtle.draw(g2d, color);
	}
	
	public void drawCoordinates(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(Color.red);
		g2d.setFont(new Font("Arial", Font.PLAIN, 10));
		g2d.drawString("px", 112, 22);
		g2d.drawString("px", 34, 104);
		
		for (int x = 100; x < WIDTH; x += 100) {
			g2d.drawLine(x, 0, x, 10);
			g2d.drawString(Integer.toString(x), x - 8, 22);
			
			for (int y = 100; y < HEIGHT; y += 100) {
				g2d.drawLine(x-2, y, x+2, y);
				g2d.drawLine(x, y-2, x, y+2);
			}
		}
		
		for (int y = 100; y < HEIGHT; y += 100) {
			g2d.drawLine(0, y, 10, y);
			g2d.drawString(Integer.toString(y), 14, y + 4);
		}
	}
	
	///////////////////////////////////////////////////
	// Instructions de l'API
	///////////////////////////////////////////////////
	
	public int clearScreen() {
		background = Utils.clone(background_saved);
		backgroundG2D = (Graphics2D) background.getGraphics();
		Utils.configureRender(backgroundG2D);
		repaint();
		return 1;
	}
	
	/*
	public int setColor(String color) {
		try {
			this.color = ColorUtils.str2color(color);
			return 1;
		}
		catch (Exception e) {
			module.printToConsole("ERROR: Unknown color: " + color, Color.RED);
			return 0;
		}
	}
	*/
	
	public int setColor(String c) {
		switch (c) {
			case "COLOR_RED" : color = Color.RED; break;
			case "COLOR_GREEN": color = Color.GREEN; break;
			case "COLOR_BLUE": color = Color.BLUE; break;
			case "COLOR_CYAN": color = Color.CYAN; break;
			case "COLOR_YELLOW": color = Color.YELLOW; break;
			case "COLOR_MAGENTA": color = Color.MAGENTA; break;
			case "COLOR_BLACK": color = Color.BLACK; break;
			case "COLOR_WHITE": color = Color.WHITE; break;
			default: return -1;
		}
		return 1;
	}
	
	public String getColor() {
		return turtle.getColor();
	}
	
	public int getBrightness() {
		return turtle.getBrightness();
	}
	
	public int turtleForward(int dist) {
		turtle.forward(dist);
		return 1;
	}
	
	public int turtleTurnRight(int angle) {
		turtle.turn(angle);
		return 1;
	}
	
	public int turtleTurnLeft(int angle) {
		turtle.turn(-angle);
		return 1;
	}
	
	public int turtleReset() {
		turtle.reset();
		return 1;
	}
	
	public int turtleGoto(int x, int y, int theta) {
		turtle.gotoXY(x, y, theta);
		return 1;
	}
	
	public int drawLine(int x1, int y1, int x2, int y2) {
		backgroundG2D.setColor(color);
		backgroundG2D.drawLine(x1, y1, x2, y2);
		repaint();
		return 1;
	}
	
	public int drawCircle(int x, int y, int rayon) {
		backgroundG2D.setColor(color);
		backgroundG2D.drawOval(x - rayon, y - rayon, 2 * rayon, 2 * rayon);
		repaint();
		return 1;
	}
}
