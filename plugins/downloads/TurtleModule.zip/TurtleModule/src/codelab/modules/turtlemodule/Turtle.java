package codelab.modules.turtlemodule;

import java.awt.Color;
import java.awt.Point;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.geom.AffineTransform;
import java.awt.geom.Path2D;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.IOException;

import codelab.helper.PluginUtils;

public class Turtle {
	
	private final String imageName = "turtle.png";
	private final int delay = 3;

	private TurtleCanvas canvas;
	private AffineTransform transform;
	private BufferedImage image;
	private Path2D.Double path;
	private Path2D.Double transformedPath;
	
	private int TURTLE_WIDTH;
	private int TURTLE_HEIGHT;
	private int TURTLE_CENTER_X;
	private int TURTLE_CENTER_Y;
	
	private double x;
	private double y;
	private double theta; // Degrés
	
	private double x0;
	private double y0;
	
	private int sensorL_x;
	private int sensorL_y;
	
	private int sensorC_x;
	private int sensorC_y;
	
	private int sensorR_x;
	private int sensorR_y;
	
	private boolean walking = false;
	public boolean visible = true;
	
	public Turtle(TurtleCanvas canvas) {
		this.canvas = canvas;
		image = PluginUtils.loadBufferedImage(TurtleModule.INSTANCE, imageName);
		TURTLE_WIDTH = image.getWidth();
		TURTLE_HEIGHT = image.getHeight();
		TURTLE_CENTER_X = TURTLE_WIDTH / 2;
		TURTLE_CENTER_Y = TURTLE_HEIGHT / 2;
		// Calcul de la forme
		Rectangle2D rectangle = new Rectangle2D.Double(0, 0, TURTLE_WIDTH, TURTLE_HEIGHT);
		path = new Path2D.Double();
		path.append(rectangle, false);
	}
	
	public void reset() {
		Dimension d = canvas.getSize();
		x = (d.width - TURTLE_WIDTH) / 2;
		y = (d.height - TURTLE_HEIGHT) / 2;
		theta = -90;
	}
	
	public void gotoXY(int x, int y, int theta) {
		Dimension d = canvas.getSize();
		this.x = x - TURTLE_WIDTH;
		this.y = y - TURTLE_HEIGHT;
		this.theta = theta;
	}
	
	public boolean contains(Point point) {
		return transformedPath.contains(point);
	}
	
	public void move(int dx, int dy) {
		x += dx;
		y += dy;
		canvas.repaint();
	}
	
	public void rotate(int delta) {
		theta += delta;
		canvas.repaint();
	}
	
	public String getColor() {
		if (canvas.getBackgroundRectangle().contains(new Point(sensorC_x, sensorC_y))) {
			int rgb = canvas.getBackgroundImage().getRGB(sensorC_x, sensorC_y);
			return ColorUtils.getColorNameFromHex(rgb);
		}
		else return "COLOR_ERROR";
	}
	
	public int getBrightness() {
		if (canvas.getBackgroundRectangle().contains(new Point(sensorC_x, sensorC_y))) {
			int rgb = canvas.getBackgroundImage().getRGB(sensorC_x, sensorC_y);
			return ColorUtils.getBrightness(rgb);
		}
		else return -1;
	}
	
	public void draw(Graphics2D g2d, Color color) {
		if (!visible) return;
		
		// Calcul de la transformation
		transform = new AffineTransform();
		transform.setToTranslation(x, y);
		transform.rotate(Math.toRadians(theta), TURTLE_CENTER_X, TURTLE_CENTER_Y);
		
		// Calcul du point de capteur
		sensorC_x = (int) (x + TURTLE_CENTER_X + 40 * Math.cos(Math.toRadians(theta)));
		sensorC_y = (int) (y + TURTLE_CENTER_Y + 40 * Math.sin(Math.toRadians(theta)));
		sensorL_x = (int) (x + TURTLE_CENTER_X + 46 * Math.cos(Math.toRadians(theta-30)));
		sensorL_y = (int) (y + TURTLE_CENTER_Y + 46 * Math.sin(Math.toRadians(theta-30)));
		sensorR_x = (int) (x + TURTLE_CENTER_X + 46 * Math.cos(Math.toRadians(theta+30)));
		sensorR_y = (int) (y + TURTLE_CENTER_Y + 46 * Math.sin(Math.toRadians(theta+30)));
		
		// Calcul du contour de la tortue
		transformedPath = (Path2D.Double) path.clone();
		transformedPath.transform(transform);
		
		if (walking) {
			// Affichage du tracé intermédiaire
			g2d.setColor(color);
			int x1 = (int) x0 + TURTLE_CENTER_X;
			int y1 = (int) y0 + TURTLE_CENTER_Y;
			int x2 = (int) x + TURTLE_CENTER_X;
			int y2 = (int) y + TURTLE_CENTER_Y;		
			g2d.drawLine(x1, y1, x2, y2);
		}
		// Affichage de la tortue
		g2d.drawImage(image, transform, null);
		
		if (canvas.DEBUG) {
			// Affichage des tracés rouges
			g2d.setColor(Color.red);
			g2d.draw(transformedPath);
			g2d.drawOval(sensorL_x-2, sensorL_y-2, 4, 4);
			g2d.drawOval(sensorC_x-2, sensorC_y-2, 4, 4);
			g2d.drawOval(sensorR_x-2, sensorR_y-2, 4, 4);
		}
	}
	
	public void forward(int dist) {
		x0 = x;
		y0 = y;
		if (visible) {
			int r = 0;
			walking = true;
			while (r < dist) {
				x = x0 + r * Math.cos(Math.toRadians(theta));
				y = y0 + r * Math.sin(Math.toRadians(theta));
				r += 1;
				canvas.repaint();
				Utils.wait(delay);
			}
			walking = false;
		}
		x = x0 + dist * Math.cos(Math.toRadians(theta));
		y = y0 + dist * Math.sin(Math.toRadians(theta));
		int x1 = (int) x0 + TURTLE_CENTER_X;
		int y1 = (int) y0 + TURTLE_CENTER_Y;
		int x2 = (int) x + TURTLE_CENTER_X;
		int y2 = (int) y + TURTLE_CENTER_Y;	
		canvas.drawLine(x1, y1, x2, y2);		
	}
	
	public void turn(int angle) {
		double theta_fin = theta + angle;
		if (visible) {
			if (angle > 0) {
				while (theta < theta_fin) {
					theta += 1;
					canvas.repaint();
					Utils.wait(delay);
				}
			} else {
				while (theta > theta_fin) {
					theta -= 1;
					canvas.repaint();
					Utils.wait(delay);
				}
			}
		}
		theta = theta_fin;
	}
}
