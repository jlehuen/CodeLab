package codelab.modules.turtlemodule;

import java.awt.Font;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.image.BufferedImage;
import java.awt.geom.Rectangle2D;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.JDialog;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;

import codelab.CodeLab;
import codelab.helper.PluginUtils;

public class BackgroundChooser extends JDialog {

	private ArrayList<BufferedImage> liste;
	private boolean empty = false;
	private int old_index;
	private int new_index;

	private int LARG = 400;
	private int HAUT = 300;
	
	private JLabel label;
	private BufferedImage icon_left = PluginUtils.loadBufferedImage(TurtleModule.INSTANCE, "icon_left.png");
	private BufferedImage icon_right = PluginUtils.loadBufferedImage(TurtleModule.INSTANCE, "icon_right.png");

	private void closeFrame() {
		dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
	}

	///////////////////////////////////////////////////
	// Constructeur
	///////////////////////////////////////////////////

	public BackgroundChooser(TurtleModule module, int index) {
		super(CodeLab.FRAME, true);

		liste = module.getBackgrounds();
		old_index = index;
		new_index = index;
		
		label = new JLabel();
		label.setPreferredSize(new Dimension(LARG, HAUT));
		
		if (liste.size() == 0) {
			label.setText("No background available");
			label.setFont(new Font("Serif", Font.PLAIN, 14));
			label.setHorizontalAlignment(SwingConstants.CENTER);
			empty = true;
		}
		else updateImage();

		JButton bouton_gauche = new JButton();
		JButton bouton_droite = new JButton();
		bouton_gauche.setIcon(new ImageIcon(icon_left));
		bouton_droite.setIcon(new ImageIcon(icon_right));
		bouton_gauche.setFocusable(false);
		bouton_droite.setFocusable(false);

		bouton_gauche.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (empty) return;
				if (--new_index < 0) new_index = liste.size() - 1;
				updateImage();
			}
		});

		bouton_droite.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (empty) return;
				if (++new_index == liste.size()) new_index = 0;
				updateImage();
			}
		});

		addMouseListener(new MouseAdapter() {
			public void mouseReleased(MouseEvent e) {
				if (empty) return;
				if (new_index != old_index) {
					BufferedImage image = liste.get(new_index);
					module.setBackgroundFromSelector(image, new_index);
				}
				closeFrame();
			}
		});

		getContentPane().add(label, BorderLayout.CENTER);
		getContentPane().add(bouton_gauche, BorderLayout.WEST);
		getContentPane().add(bouton_droite, BorderLayout.EAST);
		pack();

		setTitle("Background chooser");
		setLocationRelativeTo(CodeLab.FRAME);
		setResizable(false);
		setVisible(true);
		setModal(true);
	}

	private void updateImage() {
		BufferedImage image = liste.get(new_index);
		image = Utils.resize(image, LARG, HAUT);
		label.setIcon(new ImageIcon(image));
	}
}
