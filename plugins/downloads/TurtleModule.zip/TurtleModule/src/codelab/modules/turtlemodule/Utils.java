package codelab.modules.turtlemodule;

import java.awt.image.BufferedImage;
import java.awt.RenderingHints;
import java.awt.Graphics2D;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.Point;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.imageio.ImageIO;

public class Utils {

	public static void wait(int ms) {
		try {
			Thread.sleep(ms);
		}
		catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void saveImage(BufferedImage image, String filename) {
		try {
			File outputfile = new File(filename);
			ImageIO.write(image, "png", outputfile);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void createDirectory(String name) throws IOException {
		Path path = Paths.get(name);
		Files.createDirectories(path);
	}
	
	public static String getExtension(String filename) {
		if (filename.indexOf('.') == -1) return "";
		return filename.substring(filename.lastIndexOf('.'), filename.length());
	}
	
	public static boolean folderExists(String filename) {
		File file = new File(filename);
		return file.exists() && file.isDirectory();
	}
	
	public static File[] getFolderFiles(String folder) {
		File file = new File(folder);
		return file.listFiles();
	}
	
	public static BufferedImage loadBufferedImage(File file) {
		try {
			return ImageIO.read(file);
		}
		catch (IOException e) {
			System.err.println("ERROR: Can't read file: " + file);
			return null;
		}
	}
	
	public static BufferedImage clone(BufferedImage image) {
		BufferedImage clone = new BufferedImage(image.getWidth(), image.getHeight(), image.getType());
		Graphics2D g2d = clone.createGraphics();
		g2d.drawImage(image, 0, 0, null);
		g2d.dispose();
		return clone;
	}
	
	public static BufferedImage resize(BufferedImage src, int targetWidth, int targetHeight) {
		double scaleW = (double) targetWidth / (double) src.getWidth();
		double scaleH = (double) targetHeight / (double) src.getHeight();
		double scale = scaleW < scaleH ? scaleW : scaleH;
		BufferedImage result = new BufferedImage((int) (src.getWidth() * scale), (int) (src.getHeight() * scale), BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2d = result.createGraphics();
		g2d.drawImage(src, 0, 0, result.getWidth(), result.getHeight(), null);
		g2d.dispose();
		return result;
	}
	
	public static BufferedImage createBackground(Dimension d, Color color) {
		BufferedImage image = new BufferedImage(d.width, d.height, BufferedImage.TYPE_INT_RGB);
		Graphics2D g2d = (Graphics2D) image.getGraphics();
		g2d.setColor(color);
		g2d.fillRect(0, 0, d.width, d.height);
		g2d.dispose();
		return image;
	}
	
	public static Point limit(Point p, Dimension d) {
		if (p.x < 0) p.x = 0;
		if (p.y < 0) p.y = 0;
		if (p.x > d.width) p.x = d.width;
		if (p.y > d.height) p.y = d.height;
		return p;
	}
	
	public static void configureRender(Graphics2D g2d) {
		g2d.setRenderingHint(
			RenderingHints.KEY_ANTIALIASING,
			RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.setRenderingHint(
			RenderingHints.KEY_TEXT_ANTIALIASING,
			RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		g2d.setRenderingHint(
			RenderingHints.KEY_ALPHA_INTERPOLATION,
			RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
		g2d.setRenderingHint(
			RenderingHints.KEY_INTERPOLATION,
			RenderingHints.VALUE_INTERPOLATION_BILINEAR);
	}
}
