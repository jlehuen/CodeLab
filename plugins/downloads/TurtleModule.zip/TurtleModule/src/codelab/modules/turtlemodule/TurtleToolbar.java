package codelab.modules.turtlemodule;

import java.awt.Color;

import javax.swing.ImageIcon;

import codelab.AbstractToolbar;
import codelab.ToolButton;

public class TurtleToolbar extends AbstractToolbar {

	private ImageIcon icon_back = loadImageIcon("icon_back.png");
	private ImageIcon icon_clear = loadImageIcon("icon_clear.png");
	private ImageIcon icon_turtle = loadImageIcon("icon_turtle.png");
	private ImageIcon icon_toggle_on = loadImageIcon("icon_toggle_on.png");
	private ImageIcon icon_toggle_off = loadImageIcon("icon_toggle_off.png");
		
	private TurtleModule module;
	private ToolButton debugButton;

	///////////////////////////////////////////////////
	// Constructeur
	///////////////////////////////////////////////////

	public TurtleToolbar(TurtleModule module) {
		super(module);
		this.module = (TurtleModule) module;
		addSeparator();
		addButton("NUMPAD");
		addButton("STICK");
		addButton("CTRL");
		addSeparator();
		addButton("RESET");
		add(new ToolButton("BACK", "Back", "Choose a background", icon_back, this));
		add(debugButton = new ToolButton("DEBUG", "Marks", "Show or hide the marks", icon_toggle_off, this));
		add(new ToolButton("TURTLE", "Turtle", "Show or hide the turtle", icon_turtle, this));
		add(new ToolButton("CLEAR", "Clear", "Clear the canvas", icon_clear, this));
		endToolbar();
	}

	///////////////////////////////////////////////////
	// Action handler
	///////////////////////////////////////////////////

	public void action(String ident) {
		switch (ident) {
			case "TURTLE": action_turtle(); break;
			case "CLEAR": action_clear(); break;
			case "DEBUG": action_debug(); break;
			case "BACK": action_back(); break;
			default: super.action(ident);
		}
	}
	
	private void action_turtle() {
		module.canvas.turtleSwitch();
	}
	
	private void action_clear() {
		module.canvas.clearScreen();
	}
	
	private void action_back() {
		int current_index = module.canvas.getBackgroundIndex();
		new BackgroundChooser(module, current_index);
	}
	
	private void action_debug() {
		if (module.canvas.DEBUG) {
			debugButton.setIcon(icon_toggle_off);
			module.canvas.DEBUG = false;
			module.canvas.repaint();
		}
		else {
			debugButton.setIcon(icon_toggle_on);
			module.canvas.DEBUG = true;
			module.canvas.repaint();
		}
	}
}
