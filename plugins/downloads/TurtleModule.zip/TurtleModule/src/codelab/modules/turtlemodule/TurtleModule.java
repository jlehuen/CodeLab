package codelab.modules.turtlemodule;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.util.Map;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;

import javax.swing.JPanel;
import javax.imageio.ImageIO;

import codelab.AbstractModule;
import codelab.CodeLab;

public class TurtleModule extends AbstractModule {

	public TurtleCanvas canvas;

	///////////////////////////////////////////////////
	// Constructeur
	///////////////////////////////////////////////////

	public static TurtleModule INSTANCE;

	public TurtleModule(CodeLab codelab) {
		super(codelab);
		INSTANCE = this;
		
		setTitle("Turtle");
		setToolbar(new TurtleToolbar(this));
		setComponent(canvas = new TurtleCanvas(this));
		
		prepareUserDirectory(canvas);
	}
	
	///////////////////////////////////////////////////
	// Gestion des backgrounds
	///////////////////////////////////////////////////
	
	public static final String dirname = CodeLab.getUserDataFolder() + "/turtle";
	public static final String emptyBG = dirname + "/empty.png";

	private ArrayList<BufferedImage> backgrounds = new ArrayList<BufferedImage>();

	public ArrayList<BufferedImage> getBackgrounds() {
		return backgrounds;
	}
	
	private void prepareUserDirectory(TurtleCanvas canvas) {
		try {
			Utils.createDirectory(dirname); // If not exists
			Dimension size = new Dimension(canvas.WIDTH, canvas.HEIGHT);
			BufferedImage whiteBackground = Utils.createBackground(size, Color.WHITE);
			Utils.saveImage(whiteBackground, emptyBG);
			
			backgrounds.add(whiteBackground); // Add white background
			loadBackgrouds(); // Load user backgrounds
		}
		catch (IOException e) {
			printToConsole("ERROR: Can't create directory: " + dirname, Color.RED);
		}
	}
	
	private void loadBackgrouds() {
		if (!Utils.folderExists(dirname)) return;
		for (File file : Utils.getFolderFiles(dirname)) {
			if (file.getName().equals("empty.png")) continue;
			String ext = Utils.getExtension(file.getName());
			boolean isImage = (ext.equals(".png") || ext.equals(".jpg"));
			if (file.isFile() && isImage) {
				BufferedImage image = Utils.loadBufferedImage(file);
				backgrounds.add(image);
			}
		}
	}
	
	public void setBackgroundFromSelector(BufferedImage image, int index) {
		canvas.setBackgroundFromSelector(image, index);
	}

	///////////////////////////////////////////////////
	// Méthodes de l'interface AbstractModule
	///////////////////////////////////////////////////

	public void init() {
		canvas.reset();
	}
	
	public void reset() {
		canvas.reset();
	}
	
	public void start() {}
	public void stop() {}
	public void exit() {}
	
	///////////////////////////////////////////////////
	// Gestionnaire d'instructions
	///////////////////////////////////////////////////

	public String handleRequest(Map<String, String> params) {
		String cmd = params.get("cmd");
		String filename, color;
		int distance, angle;
		int x1, y1, x2, y2;
		int x, y, r;
		
		switch (cmd) {
			case "clearScreen":
				return String.valueOf(canvas.clearScreen());
			case "setColor":
				color = params.get("color");
				return String.valueOf(canvas.setColor(color));
			case "drawLine":
				x1 = Integer.valueOf(params.get("x1"));
				y1 = Integer.valueOf(params.get("y1"));
				x2 = Integer.valueOf(params.get("x2"));
				y2 = Integer.valueOf(params.get("y2"));
				return String.valueOf(canvas.drawLine(x1, y1, x2, y2));
			case "drawCircle":
				x1 = Integer.valueOf(params.get("x"));
				y1 = Integer.valueOf(params.get("y"));
				r = Integer.valueOf(params.get("r"));
				return String.valueOf(canvas.drawCircle(x1, y1, r));

			case "turtleForward":
				distance = Integer.valueOf(params.get("distance"));
				return String.valueOf(canvas.turtleForward(distance));
			case "turtleTurnRight":
				angle = Integer.valueOf(params.get("angle"));
				return String.valueOf(canvas.turtleTurnRight(angle));
			case "turtleTurnLeft":
				angle = Integer.valueOf(params.get("angle"));
				return String.valueOf(canvas.turtleTurnLeft(angle));	
			case "turtleGoto":
				x1 = Integer.valueOf(params.get("x"));
				y1 = Integer.valueOf(params.get("y"));
				r = Integer.valueOf(params.get("theta"));
				return String.valueOf(canvas.turtleGoto(x1, y1, r));
			case "turtleReset":
				return String.valueOf(canvas.turtleReset());	
			case "getBrightness":
				return String.valueOf(canvas.getBrightness());
			case "getColor":
				return canvas.getColor();
			
			default:
				return unknownCommandError(cmd);
		}
	}
}
