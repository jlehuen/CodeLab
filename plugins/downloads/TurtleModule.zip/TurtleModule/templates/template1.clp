;; Program _fileName_
;; Created by _author_ on _date_

#requires codelab.yourmodule.yourAPI

(defrule only-rule
	=>
	; TODO
)
