<?xml version="1.0" encoding="utf-8"?>

<!--
#####################################################################
##  This file is part of the CodeLab IDE and Robot Simulator       ##
##  Copyright © Jérôme Lehuen 2021 - Jerome.Lehuen@univ-lemans.fr  ##
#####################################################################
-->

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

<xsl:output method="html"
            encoding="utf-8"
            doctype-public="-//W3C//DTD HTML 4.01//EN"
            doctype-system="http://www.w3.org/TR/html4/strict.dtd"
            indent="yes"/>

<xsl:template match="/">
	<HTML>
	<BODY>
		<xsl:apply-templates select="//instruction"/>
	</BODY>
	</HTML>
</xsl:template>

<xsl:template match="instruction">
    <li>Hello World!</li>
</xsl:template>

</xsl:stylesheet>

