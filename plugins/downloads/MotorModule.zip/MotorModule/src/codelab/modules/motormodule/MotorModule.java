package codelab.modules.motormodule;

import codelab.CodeLab;
import codelab.AbstractModule;

import java.util.Map;

public class MotorModule extends AbstractModule {

	private MotorSimulator simulator;
	public CodeLab codelab;

	///////////////////////////////////////////////////
	// Constructor
	///////////////////////////////////////////////////

	public MotorModule(CodeLab codelab) {
		super(codelab);
		this.codelab = codelab;
		loadProperties("lang.properties");
		setTitle(getLangProperty("title"));
		setToolbar(new MotorToolbar(this));
		simulator = new MotorSimulator(this);
		setComponent(simulator);
		setSystem(simulator);
	}

	///////////////////////////////////////////////////
	// AbstractModule methods to implement
	///////////////////////////////////////////////////

	public void init() {
	}
	public void exit() {
	}

	public void start() {
		simulator.start();
	}

	public void stop() {
		simulator.stop();
	}

	public void reset() {
		simulator.reset();
	}

	///////////////////////////////////////////////////
	// Instruction handler
	///////////////////////////////////////////////////

	public String handleRequest(Map<String, String> params) {
		String cmd = params.get("cmd");
		int port, power;
		switch (cmd) {

			case "motorOn":
				port = Integer.valueOf(params.get("port"));
				power = Integer.valueOf(params.get("power"));
				return String.valueOf(simulator.motorOn(port, power));

			case "motorOff":
				port = Integer.valueOf(params.get("port"));
				return String.valueOf(simulator.motorOff(port));

			case "motorRotationCount":
				port = Integer.valueOf(params.get("port"));
				return String.valueOf(simulator.motorRotationCount(port));

			case "resetMotorRotationCount":
				port = Integer.valueOf(params.get("port"));
				return String.valueOf(simulator.resetMotorRotationCount(port));

			default:
				return unknownCommandError(cmd);
		}
	}
}
