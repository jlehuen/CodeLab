package codelab.modules.motormodule;

import codelab.AbstractToolbar;

public class MotorToolbar extends AbstractToolbar {

	///////////////////////////////////////////////////
	// Constructor
	///////////////////////////////////////////////////

	public MotorToolbar(MotorModule module) {
		super(module);
		addSeparator();
		addButton("NUMPAD");
		addButton("STICK");
		addButton("CTRL");
		addSeparator();
		addButton("RESET");
		addButton("DATA");
		endToolbar();
	}

	///////////////////////////////////////////////////
	// Action handler
	///////////////////////////////////////////////////

	public void action(String ident) {
		switch (ident) {
			// No specific button
			default: super.action(ident);
		}
	}
}
