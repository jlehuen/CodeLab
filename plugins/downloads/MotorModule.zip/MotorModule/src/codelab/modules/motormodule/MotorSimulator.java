package codelab.modules.motormodule;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

import codelab.DataTableInterface;
import codelab.helper.AbstractSimulator;
import codelab.helper.PluginUtils;
import codelab.helper.AudioPlayer;

public class MotorSimulator extends AbstractSimulator implements DataTableInterface {

	private MotorModule module;

	private BufferedImage image1; // Image of the motor block
	private BufferedImage image2; // Image of the rotating part
	private AudioPlayer player; // Sound player for the realism

	private double power = 0; // Power given to he motor
	private double alpha = 0; // Actual angle of the axis
	private double counter = 0; // Resetable counter

	private final int OUT_A = 0;

	///////////////////////////////////////////////////
	// Constructor
	///////////////////////////////////////////////////

	public MotorSimulator(MotorModule module) {
		this.module = module;
		image1 = PluginUtils.loadBufferedImage(module, "motor.png");
		image2 = PluginUtils.loadBufferedImage(module, "axe.png");
		player = new AudioPlayer(module, "motor.wav");
	}

	///////////////////////////////////////////////////
	// Instruction methods
	///////////////////////////////////////////////////

	public int motorOn(int port, int power) {
		if (port != OUT_A) return port_error(port);
		if (Math.abs(power) > 100) return power_error(power);
		this.power = ((double) power) / 1000;
		player.loop(); // Start audio player
		return 1;
	}

	public int motorOff(int port) {
		if (port != OUT_A) return port_error(port);
		power = 0;
		player.stop(); // Stop audio player
		return 1;
	}

	public int motorRotationCount(int port) {
		if (port != OUT_A) return port_error(port);
		return (int) Math.toDegrees(counter);
	}

	public int resetMotorRotationCount(int port) {
		if (port != OUT_A) return port_error(port);
		counter = 0;
		return 1;
	}

	private int port_error(int port) {
		String message = String.format("MOTOR ERROR: port %d not used\n", port);
		module.printToConsole(message, Color.RED);
		stop(); // Arrêter le simulateur
		module.codelab.halt(); // Arrêter l'exécution
		return -1;
	}

	private int power_error(int power) {
		String message = String.format("MOTOR ERROR: power %d not allowed\n", power);
		module.printToConsole(message, Color.RED);
		stop(); // Arrêter le simulateur
		module.codelab.halt(); // Arrêter l'exécution
		return -1;
	}

	///////////////////////////////////////////////////
	// Toobar methods
	///////////////////////////////////////////////////

	public void stop() {
		power = 0;
		player.stop(); // Stop audio player
		super.stop(); // Stop simulation
		repaint(); // Repaint the motor
	}

	public void reset() {
		power = 0;
		alpha = 0;
		counter = 0;
		player.stop(); // Stop audio player
		super.stop(); // Stop simulation
		repaint(); // Repaint the motor
	}

	///////////////////////////////////////////////////
	// Updating method
	///////////////////////////////////////////////////

	protected void update() {
		alpha += power;
		counter += power;
		repaint(); // Repaint the motor
	}

	///////////////////////////////////////////////////
	// Implementation of DataTableInterface
	///////////////////////////////////////////////////

	private final int NBDATA = 3;
	private String[] propKey = new String[NBDATA];
	private String[] propVal = new String[NBDATA];

	public int getNbProp() {
		return NBDATA;
	}

	public String getPropKey(int i) {
		return propKey[i];
	}

	public String getPropVal(int i) {
		return propVal[i];
	}

	public void updateValues() {
		propKey[0] = "Port";
		propVal[0] = "OUT_A";
		propKey[1] = "Power";
		propVal[1] = String.valueOf(power * 1000);
		propKey[2] = "Counter";
		propVal[2] = String.format("%d°", motorRotationCount(OUT_A));
	}

	///////////////////////////////////////////////////
	// Drawing method
	///////////////////////////////////////////////////

	private static final int WIDTH = 2000;
	private static final int HEIGHT = 1500;
	private static final int X0 = 540+53;
	private static final int Y0 = 118+50;
	private static final Color bgcolor = new Color(231, 231, 231);

	private double a, cos, sin;

	public void paintComponent(Graphics graphics) {
		AffineTransform affine = new AffineTransform();
		affine.setToTranslation(540, 118);
		affine.rotate(alpha, 53, 50);

		super.paintComponent(graphics);
		Graphics2D g2d = getGraphics2D(graphics);
		g2d.setBackground(bgcolor);
		g2d.clearRect(0, 0, WIDTH, HEIGHT);
		g2d.drawImage(image1, null, null);
		g2d.drawImage(image2, affine, null);
		if (module.getDataFlag()) {
			g2d.setColor(Color.red);
			for (int deg = 0; deg < 360; deg += 10) {
				a =  Math.toRadians(deg);
				cos = Math.cos(a);
				sin = Math.sin(a);
				g2d.drawLine(
					X0 + (int)(120*cos), Y0 + (int)(120*sin),
					X0 + (int)(130*cos), Y0 + (int)(130*sin));
			}
		}
		g2d.dispose();
	}
}
