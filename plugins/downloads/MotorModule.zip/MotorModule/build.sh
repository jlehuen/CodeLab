#!/bin/bash
#####################################################################
## This file is part of the software CodeLab IDE and Simulators    ##
## For any question about CodeLab e-mail to codelab@univ-lemans.fr ##
#####################################################################

## DO NOT DELETE, MODIFY OR MOVE THIS SCRIPT !!

BASE=$(pwd)
CODELAB_FILES=$(echo $BASE | rev | cut -d/ -f3- | rev)
JAVA_HOME=$(grep JAVA_HOME $CODELAB_FILES/.hidden/infos.txt | cut -c11-)
CLASSNAME=$(basename "$BASE")
PACKAGE=$(echo "$CLASSNAME" | tr '[:upper:]' '[:lower:]')
DIRECTORY=codelab/modules/$PACKAGE
CLS="printf \33c\e[3J"

JAR=$JAVA_HOME/bin/jar
JAVA=$JAVA_HOME/bin/java
JAVAC=$JAVA_HOME/bin/javac
CLASSPATH=class:lib/*

#########################################################
# Display some information
#########################################################

$CLS
echo ---------------------------------------------------
echo "BASE=$BASE"
echo "CODELAB_FILES=$CODELAB_FILES"
echo "JAVA_HOME=$JAVA_HOME"
echo "CLASSNAME=$CLASSNAME"
echo "PACKAGE=$PACKAGE"
echo "DIRECTORY=$DIRECTORY"
echo ---------------------------------------------------

#########################################################
# Compile the Java files
#########################################################

echo "Compile the Java files..."

rm -rf class/*
set -e
$JAVAC -encoding UTF8 \
	-classpath $CLASSPATH \
	-sourcepath src \
	-d class \
	src/$DIRECTORY/*.java

#########################################################
# Generate the libraries
#########################################################

echo "Generate the libraries..."

cd includes
for fname in *.xml; do
	[ -f "$fname" ] || continue
	echo "   $fname"
	$JAVA -jar ../lib/codelab.jar Parser $fname
done

#########################################################
# Package the module
#########################################################

echo "Package the module..."

cd ..
cp -r data class
cp -r includes class
cp -r templates class
cp -r exercices class
find class -name *.DS_Store -delete

cd class
for fname in ../lib/*.jar; do
	[ -f "$fname" ] || continue
	$JAR -xf $fname
done

rm -rf META-INF
$JAR cf $CLASSNAME.pac $DIRECTORY *
mv $CLASSNAME.pac $CODELAB_FILES/modules

#########################################################
# That's All Folks
#########################################################

cd ..
echo ---------------------------------------------------
echo "A new file '$CLASSNAME.pac' was generated"
echo "Have a look into $CODELAB_FILES/modules"
echo
