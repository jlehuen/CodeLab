:: #####################################################################
:: ## This file is part of the software CodeLab IDE and Simulators    ##
:: ## For any question about CodeLab e-mail to codelab@univ-lemans.fr ##
:: #####################################################################

:: DO NOT DELETE OR MODIFY THIS SCRIPT !!

@ECHO OFF & SETLOCAL ENABLEEXTENSIONS ENABLEDELAYEDEXPANSION

:: Base directory
SET "BASE=%~dp0"
CALL :dirname %BASE% TEMP
CALL :dirname %TEMP% CODELAB_FILES
:: Java directory
FINDSTR "JAVA_HOME" %CODELAB_FILES%.hidden\infos.txt >> tmp
SET /p "TEMP=" < tmp
DEL tmp
SET JAVA_HOME=%TEMP:~10%
:: Module name
CALL :basename %BASE% CLASSNAME
:: Package name
SET PACKAGE=%CLASSNAME%
CALL :tolower PACKAGE
:: Path to the main class
SET DIRECTORY=codelab\modules\%PACKAGE%

SET JAR=%JAVA_HOME%\bin\jar
SET JAVA=%JAVA_HOME%\bin\java
SET JAVAC=%JAVA_HOME%\bin\javac
SET CLASSPATH=class;lib\*

:: #########################################################
:: Display some information
:: #########################################################

ECHO ---------------------------------------------------
ECHO BASE=%BASE%
ECHO CODELAB_FILES=%CODELAB_FILES%
ECHO JAVA_HOME=%JAVA_HOME%
ECHO CLASSNAME=%CLASSNAME%
ECHO PACKAGE=%PACKAGE%
ECHO DIRECTORY=%DIRECTORY%
ECHO ---------------------------------------------------

:: #########################################################
:: # Compile the Java files
:: #########################################################

ECHO Compile the Java files...

DEL /S /F /Q class\* 1>nul
%JAVAC% -encoding UTF8 ^
	-classpath %CLASSPATH% ^
	-sourcepath src ^
	-d class ^
	src\%DIRECTORY%\*.java

:: #########################################################
:: # Generate the libraries
:: #########################################################

ECHO Generate the libraries...

CD includes
FOR %%i in (*.xml) DO (
	@ECHO %%i
	%JAVA% -jar ..\lib\codelab.jar Parser %%i
)

:: #########################################################
:: # Package the module
:: #########################################################

ECHO Package the module...

CD ..
ROBOCOPY /S data class\data 1>nul
ROBOCOPY /S includes class\includes 1>nul
ROBOCOPY /S templates class\templates 1>nul
ROBOCOPY /S exercices class\exercices 1>nul

CD class
FOR %%i in (..\lib\*.jar) DO (
	%JAR% -xf %%i
)

RMDIR /S /Q META-INF
%JAR% cf %CLASSNAME%.pac %DIRECTORY% *
MOVE %CLASSNAME%.pac %CODELAB_FILES%modules 1>nul

:: #########################################################
:: That's All Folks
:: #########################################################

CD ..
ECHO ---------------------------------------------------
ECHO A new file '%CLASSNAME%.pac' was generated
ECHO Have a look into %CODELAB_FILES%modules
PAUSE
EXIT

:tolower
	FOR %%L IN (^^ a b c d e f g h i j k l m n o p q r s t u v w x y z) DO SET %1=!%1:%%L=%%L!
GOTO :EOF

:basename
    SETLOCAL ENABLEEXTENSIONS ENABLEDELAYEDEXPANSION
    SET _dir=%~dp1
    SET _dir=%_dir:~0,-1%
    ENDLOCAL & FOR %%i IN ("%_dir%") DO SET %2=%%~nxi
GOTO :EOF

:dirname
    SETLOCAL ENABLEEXTENSIONS ENABLEDELAYEDEXPANSION
    SET _dir=%~dp1
    SET _dir=%_dir:~0,-1%
    ENDLOCAL & FOR %%i IN ("%_dir%") DO SET %2=%%~dpi
GOTO :EOF
