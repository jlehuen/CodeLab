/*
 * Program _fileName_
 * Created by _author_ on _date_
 */

package main

import (robot "codelab/motormodule/NXTMotor")

func main() {
	
	robot.ResetMotorRotationCount(robot.OUT_A)
	robot.MotorOn(robot.OUT_A, 25)
	for robot.MotorRotationCount(robot.OUT_A) < 360 {
	}
	robot.MotorOff(robot.OUT_A)
}
