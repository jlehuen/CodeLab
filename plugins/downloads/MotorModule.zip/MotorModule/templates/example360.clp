;; Program _fileName_
;; Created by _author_ on _date_

#requires codelab.motormodule.NXTMotor

(defrule only-rule
	=>
	(resetMotorRotationCount ?*OUT_A*)
	(motorOn ?*OUT_A* 25)
	(while (< (motorRotationCount ?*OUT_A*) 360) do)
	(motorOff ?*OUT_A*))
