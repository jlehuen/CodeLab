/*
 * Program _fileName_
 * Created by _author_ on _date_
 */

#include "codelab/motormodule/NXTMotor.c"

void main() {
	resetMotorRotationCount(OUT_A);
	motorOn(OUT_A, 25);
	while (motorRotationCount(OUT_A) < 360);
	motorOff(OUT_A);
}
