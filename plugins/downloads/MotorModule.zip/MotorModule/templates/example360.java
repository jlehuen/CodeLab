/*
 * Class _className_
 * Created by _author_ on _date_
 */

import codelab.motormodule.NXTMotor;

class _className_ extends NXTMotor {

	private void run() {
		resetMotorRotationCount(OUT_A);
		motorOn(OUT_A, 25);
		while (motorRotationCount(OUT_A) < 360);
		motorOff(OUT_A);
	}

	public static void main(String args[]) {
		new _className_().run();
	}
}
