## Program _fileName_
## Created by _author_ on _date_

from codelab.motormodule.NXTMotor import *

resetMotorRotationCount(OUT_A)
motorOn(OUT_A, 25)
while motorRotationCount(OUT_A) < 360: pass
motorOff(OUT_A)
