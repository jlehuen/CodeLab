#####################################################################
## This file is part of the software CodeLab IDE and Simulators    ##
## For any question about CodeLab e-mail to codelab@univ-lemans.fr ##
#####################################################################

## DO NOT DELETE OR MODIFY THIS SCRIPT !!

cd "$(dirname "$0")"
BASE=$(pwd)
MODULE=$(basename "$BASE")

rm -rf class/*
rm includes/*.c
rm includes/*.go
rm includes/*.py
rm includes/*.clp
rm includes/*.java
rm includes/*.html

cd ..

echo "Suppression des fichiers cachés..."
find $MODULE -type f -name '__MACOSX' -delete
find $MODULE -type f -name '.DS_Store' -delete
find $MODULE -type f -name '._*' -delete

echo "Compression du dossier..."
zip -qr $MODULE.zip $MODULE
