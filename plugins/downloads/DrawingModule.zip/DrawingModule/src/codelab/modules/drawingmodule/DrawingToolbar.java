package codelab.modules.drawingmodule;

import codelab.AbstractToolbar;
import codelab.ToolButton;

import javax.swing.ImageIcon;

public class DrawingToolbar extends AbstractToolbar {

	private ImageIcon icon_clear = loadImageIcon("icon_clear.png");

	///////////////////////////////////////////////////
	// Constructor
	///////////////////////////////////////////////////

	public DrawingToolbar(DrawingModule module) {
		super(module);
		addSeparator();
		add(new ToolButton("CLEAR",
			getLangProperty("btn_clear"),
			getLangProperty("btn_clear_tooltip"), icon_clear, this));
		endToolbar();
	}

	///////////////////////////////////////////////////
	// Action handler
	///////////////////////////////////////////////////

	public void action(String ident) {
		switch (ident) {
			case "CLEAR": action_clear(); break;
			default: super.action(ident);
		}
	}

	private void action_clear() {
		DrawingPanel canvas = (DrawingPanel) module.getComponent();
		canvas.clearScreen();
	}
}
