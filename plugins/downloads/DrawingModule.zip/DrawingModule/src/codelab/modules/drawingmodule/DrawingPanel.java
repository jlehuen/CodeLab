package codelab.modules.drawingmodule;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;
import javax.swing.ImageIcon;

public class DrawingPanel extends JPanel {

	private static final int WIDTH = 2000;
	private static final int HEIGHT = 1500;
	private static final int TYPE = BufferedImage.TYPE_INT_ARGB;

	private BufferedImage image;
	private Graphics2D g2d;

	public DrawingPanel() {
		image = new BufferedImage(WIDTH, HEIGHT, TYPE);
		g2d = getGraphics2D(image);
		clearScreen();
	}

	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.drawImage(image, 0, 0, null);
	}

	public int drawLine(int x1, int y1, int x2, int y2) {
		g2d.drawLine(x1, y1, x2, y2);
		repaint();
		return 1;
	}

	public int drawCircle(int x, int y, int r) {
		g2d.drawOval(x-r, y-r, 2*r, 2*r);
		repaint();
		return 1;
	}

	public int setColor(int code) {
		switch (code) {
			case 0: g2d.setColor(Color.BLACK); return 1;
			case 1: g2d.setColor(Color.WHITE); return 1;
			case 2: g2d.setColor(Color.GREEN); return 1;
			case 3: g2d.setColor(Color.BLUE); return 1;
			case 4: g2d.setColor(Color.RED); return 1;
			default: return 0;
		}
	}

	public int clearScreen() {
		g2d.setBackground(Color.WHITE);
		g2d.clearRect(0, 0, WIDTH, HEIGHT);
		repaint();
		return 1;
	}

	private Graphics2D getGraphics2D(BufferedImage image) {
		Graphics2D g2d = image.createGraphics();
		g2d.setRenderingHint(
			RenderingHints.KEY_ANTIALIASING,
			RenderingHints.VALUE_ANTIALIAS_ON);
		return g2d;
	}
}
