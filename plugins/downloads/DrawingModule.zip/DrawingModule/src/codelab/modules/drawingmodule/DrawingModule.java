package codelab.modules.drawingmodule;

import java.util.Map;
import codelab.CodeLab;
import codelab.AbstractModule;

public class DrawingModule extends AbstractModule {

	private DrawingPanel canvas;

	///////////////////////////////////////////////////
	// Constructor
	///////////////////////////////////////////////////

	public DrawingModule(CodeLab codelab) {
		super(codelab);
		loadProperties("lang.properties");
		setTitle(getLangProperty("title"));
		setToolbar(new DrawingToolbar(this));
		setComponent(canvas = new DrawingPanel());
	}

	///////////////////////////////////////////////////
	// AbstractModule methods to implement
	///////////////////////////////////////////////////

	public void init() {
	}
	public void exit() {
	}
	public void start() {
	}
	public void stop() {
	}
	public void reset() {
	}

	///////////////////////////////////////////////////
	// Instruction handler
	///////////////////////////////////////////////////

	public String handleRequest(Map<String, String> params) {
		String cmd = params.get("cmd");
		switch (cmd) {

			case "clearScreen":
				return String.valueOf(canvas.clearScreen());

			case "setColor":
				int color = Integer.valueOf(params.get("color"));
				return String.valueOf(canvas.setColor(color));

			case "drawLine":
				int x1 = Integer.valueOf(params.get("x1"));
				int y1 = Integer.valueOf(params.get("y1"));
				int x2 = Integer.valueOf(params.get("x2"));
				int y2 = Integer.valueOf(params.get("y2"));
				return String.valueOf(canvas.drawLine(x1, y1, x2, y2));

			case "drawCircle":
				int x = Integer.valueOf(params.get("x"));
				int y = Integer.valueOf(params.get("y"));
				int r = Integer.valueOf(params.get("r"));
				return String.valueOf(canvas.drawCircle(x, y, r));

			default:
				return unknownCommandError(cmd);
		}
	}
}