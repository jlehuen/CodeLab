## Program _fileName_
## Created by _author_ on _date_

from codelab.drawingmodule.Canvas import *

clearScreen()
setColor(COLOR_RED)
drawLine(0, 0, 100, 100)
setColor(COLOR_BLUE)
drawCircle(100, 100, 50)
