/*
 * Program _fileName_
 * Created by _author_ on _date_
 */

#include "codelab/drawingmodule/Canvas.c"

int main() {
    clearScreen();
    setColor(COLOR_RED);
    drawLine(0, 0, 100, 100);
    setColor(COLOR_BLUE);
    drawCircle(100, 100, 50);
    return 0;
}
