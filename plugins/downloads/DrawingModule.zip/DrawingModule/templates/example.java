/*
 * Class _className_
 * Created by _author_ on _date_
 */

import codelab.drawingmodule.Canvas;

class _className_ extends Canvas {

    private void run() {
        clearScreen();
        setColor(COLOR_RED);
        drawLine(0, 0, 100, 100);
        setColor(COLOR_BLUE);
        drawCircle(100, 100, 50);
    }

    public static void main(String args[]) {
        new _className_().run();
    }
}
