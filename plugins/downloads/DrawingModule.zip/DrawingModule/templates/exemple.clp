;; Program _fileName_
;; Created by _author_ on _date_

#requires codelab.drawingmodule.Canvas

(defrule only-rule
	=>
	(clearScreen)
	(setColor ?*COLOR_RED*)
	(drawLine 0 0 100 100)
	(setColor ?*COLOR_BLUE*)
	(drawCircle 100 100 50))
