;; Exploration du Donjon en CLIPS
;; Auteur : CodeLab

#requires codelab.dungeonmodule.DungeonModuleAPI

(defrule init-dungeon
	=>
	(setDelay 100)
	(loadMap 1)
	(printout t "Exploration CLIPS démarrée" crlf)
	(assert (explorer step))
)

(defrule check-treasure
	?f <- (explorer step)
	(test (= (isTreasureReached) 1))
	=>
	(retract ?f)
	(printout t "Victoire ! Trésor atteint !" crlf)
)

(defrule open-door-rule
	(explorer step)
	(test (= (isTreasureReached) 0))
	(test (= (lookAhead) 3)) ;; TILE_DOOR = 3
	(test (= (hasKey) 1))
	=>
	(printout t "Ouverture de la porte !" crlf)
	(openDoor)
)

(defrule move-forward-rule
	(explorer step)
	(test (= (isTreasureReached) 0))
	(test (= (canMoveForward) 1))
	=>
	(stepForward)
)

(defrule turn-rule
	(explorer step)
	(test (= (isTreasureReached) 0))
	(test (= (canMoveForward) 0))
	=>
	(turnRight)
)
