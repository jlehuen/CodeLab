/*
 * Exploration du Donjon Algorithmique en C
 * Auteur : CodeLab
 */

#include <stdio.h>
#include "codelab/dungeonmodule/DungeonModuleAPI.c"

void main() {
	setDelay(100);
	loadMap(1);
	printf("Départ de l'exploration...\n");

	while (!isTreasureReached()) {
		int ahead = lookAhead();

		if (ahead == TILE_DOOR) {
			if (hasKey()) {
				printf("Ouverture de la porte !\n");
				openDoor();
			} else {
				printf("Porte bloquée sans clé !\n");
				break;
			}
		} else if (canMoveForward()) {
			stepForward();
		} else {
			turnRight();
		}
	}

	if (isTreasureReached()) {
		printf("Trésor atteint en %d pas !\n", getStepsCount());
		printf("Gemmes collectées : %d\n", getGemsCount());
	}
}
