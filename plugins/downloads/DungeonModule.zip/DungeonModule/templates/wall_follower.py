## Résolution de labyrinthe par la règle de la main droite
## Auteur : CodeLab

from codelab.dungeonmodule.DungeonModuleAPI import *

setDelay(60)
loadMap(2)

print("Lancement du suivi de mur (règle de la main droite)...")

# Stratégie de la main droite :
# 1. Tenter d'aller à droite
# 2. Si mur à droite, tenter tout droit
# 3. Si mur devant, tourner à gauche
# 4. Si bloqué, faire demi-tour

while not isTreasureReached():
    # Tenter de tourner à droite
    turnRight()
    
    if lookAhead() == TILE_DOOR and hasKey():
        openDoor()
        stepForward()
    elif canMoveForward():
        stepForward()
    else:
        # Revenir en face
        turnLeft()
        if lookAhead() == TILE_DOOR and hasKey():
            openDoor()
            stepForward()
        elif canMoveForward():
            stepForward()
        else:
            # Tourner à gauche
            turnLeft()
            if lookAhead() == TILE_DOOR and hasKey():
                openDoor()
                stepForward()
            elif canMoveForward():
                stepForward()
            else:
                turnLeft() # Demi-tour

print(f"Victoire ! Trésor atteint en {getStepsCount()} pas !")
print(f"Gemmes : {getGemsCount()} / Clés restantes : {hasKey()}")
