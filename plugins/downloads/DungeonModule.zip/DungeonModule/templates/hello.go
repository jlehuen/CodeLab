// Exploration du Donjon en Go
// Auteur : CodeLab

package main

import (
	"fmt"
	dungeonmodule "codelab/dungeonmodule/DungeonModuleAPI"
)

func main() {
	dungeonmodule.SetDelay(100)
	dungeonmodule.LoadMap(1)
	fmt.Println("Départ de l'exploration Go...")

	for dungeonmodule.IsTreasureReached() == 0 {
		ahead := dungeonmodule.LookAhead()

		if ahead == dungeonmodule.TILE_DOOR {
			if dungeonmodule.HasKey() == 1 {
				fmt.Println("Ouverture de la porte !")
				dungeonmodule.OpenDoor()
			} else {
				fmt.Println("Porte fermée sans clé !")
				break
			}
		} else if dungeonmodule.CanMoveForward() == 1 {
			dungeonmodule.StepForward()
		} else {
			dungeonmodule.TurnRight()
		}
	}

	if dungeonmodule.IsTreasureReached() == 1 {
		fmt.Printf("Trésor atteint en %d pas !\n", dungeonmodule.GetStepsCount())
		fmt.Printf("Gemmes collectées : %d\n", dungeonmodule.GetGemsCount())
	}
}
