/*
 * Exploration du Donjon Algorithmique en Java
 * Auteur : CodeLab
 */

import codelab.dungeonmodule.DungeonModuleAPI;

class _className_ extends DungeonModuleAPI {

	private void run() {
		setDelay(100);
		loadMap(1);
		System.out.println("Départ de l'exploration Java...");

		while (isTreasureReached() == 0) {
			int ahead = lookAhead();

			if (ahead == TILE_DOOR) {
				if (hasKey() == 1) {
					System.out.println("Ouverture de la porte !");
					openDoor();
				} else {
					System.out.println("Porte verrouillée sans clé !");
					break;
				}
			} else if (canMoveForward() == 1) {
				stepForward();
			} else {
				turnRight();
			}
		}

		if (isTreasureReached() == 1) {
			System.out.println("Trésor atteint en " + getStepsCount() + " pas !");
			System.out.println("Gemmes récoltées : " + getGemsCount());
		}
	}

	public static void main(String args[]) {
		new _className_().run();
	}
}
