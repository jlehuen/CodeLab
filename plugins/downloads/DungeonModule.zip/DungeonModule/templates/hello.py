## Programme de découverte du Donjon Algorithmique
## Auteur : CodeLab

from codelab.dungeonmodule.DungeonModuleAPI import *

setDelay(100)
loadMap(1)

print("Départ de l'exploration du donjon...")

# Exploration simple : avancer jusqu'au trésor
while not isTreasureReached():
    ahead = lookAhead()
    
    # Si une porte verrouillée se présente et qu'on a la clé
    if ahead == TILE_DOOR:
        if hasKey():
            print("Porte verrouillée détectée : ouverture avec la clé !")
            openDoor()
        else:
            print("Porte verrouillée sans clé !")
            break
            
    # Si la voie est libre, avancer
    elif canMoveForward():
        stepForward()
        
    # Sinon, tourner à droite pour trouver le couloir
    else:
        turnRight()

if isTreasureReached():
    print(f"Trésor atteint avec succès en {getStepsCount()} pas !")
    print(f"Gemmes récoltées : {getGemsCount()}")
