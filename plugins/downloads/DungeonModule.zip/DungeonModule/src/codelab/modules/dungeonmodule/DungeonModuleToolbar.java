package codelab.modules.dungeonmodule;

import codelab.AbstractToolbar;
import codelab.ToolButton;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class DungeonModuleToolbar extends AbstractToolbar {

	private ImageIcon icon_reset = loadImageIcon("icon_reset.png");
	private ImageIcon icon_magic = loadImageIcon("icon_magic.png");
	private ImageIcon icon_toggle_on = loadImageIcon("icon_toggle_on.png");
	private ImageIcon icon_toggle_off = loadImageIcon("icon_toggle_off.png");

	private ToolButton fogButton;
	private JComboBox<String> mapSelector;
	private JSlider speedSlider;

	public DungeonModuleToolbar(DungeonModule module) {
		super(module);
		addSeparator();

		// Bouton Réinitialiser
		add(new ToolButton("RESET",
			getLangProperty("btn_reset"),
			getLangProperty("btn_reset_tooltip"),
			icon_reset, this));

		// Bouton Nouveau Labyrinthe aléatoire
		add(new ToolButton("RANDOM",
			getLangProperty("btn_random"),
			getLangProperty("btn_random_tooltip"),
			icon_magic, this));

		addSeparator();

		// Sélecteur de carte
		mapSelector = new JComboBox<>(new String[]{
			"1: Entraînement",
			"2: Labyrinthe classique",
			"3: Donjon Clés & Pièges",
			"4: Aléatoire (DFS)"
		});
		mapSelector.setPreferredSize(new Dimension(175, 26));
		mapSelector.setMaximumSize(new Dimension(175, 26));
		mapSelector.setToolTipText("Sélectionner une carte du donjon");
		mapSelector.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int idx = mapSelector.getSelectedIndex() + 1;
				((DungeonModule) module).getPanel().loadMap(idx);
			}
		});
		add(mapSelector);

		addSeparator();

		// Toggle Brouillard de guerre
		add(fogButton = new ToolButton("FOG",
			getLangProperty("btn_fog"),
			getLangProperty("btn_fog_tooltip"),
			icon_toggle_off, this));

		addSeparator();

		// Vitesse / temporisation
		JLabel speedLabel = new JLabel(" Pause : ");
		add(speedLabel);

		speedSlider = new JSlider(JSlider.HORIZONTAL, 0, 300, 80);
		speedSlider.setPreferredSize(new Dimension(100, 24));
		speedSlider.setMaximumSize(new Dimension(100, 24));
		speedSlider.setToolTipText("Temporisation par action (ms)");
		speedSlider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				((DungeonModule) module).getPanel().setDelay(speedSlider.getValue());
			}
		});
		add(speedSlider);

		addSeparatorflex();
		endToolbar();
	}

	public void setMapSelection(int mapId) {
		if (mapId >= 1 && mapId <= 4) {
			mapSelector.setSelectedIndex(mapId - 1);
		}
	}

	@Override
	public void action(String ident) {
		DungeonModule dModule = (DungeonModule) module;
		DungeonPanel panel = dModule.getPanel();

		switch (ident) {
			case "RESET":
				panel.resetDungeon();
				break;

			case "RANDOM":
				mapSelector.setSelectedIndex(3);
				panel.loadMap(4);
				break;

			case "FOG":
				boolean nextFog = !panel.isFogOfWar();
				panel.setFogOfWar(nextFog);
				fogButton.setIcon(nextFog ? icon_toggle_on : icon_toggle_off);
				break;

			default:
				super.action(ident);
				break;
		}
	}
}
