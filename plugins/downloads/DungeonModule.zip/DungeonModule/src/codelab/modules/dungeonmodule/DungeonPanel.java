package codelab.modules.dungeonmodule;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import javax.swing.JPanel;

public class DungeonPanel extends JPanel {

	// Types de tuiles
	public static final int TILE_EMPTY = 0;
	public static final int TILE_WALL = 1;
	public static final int TILE_KEY = 2;
	public static final int TILE_DOOR = 3;
	public static final int TILE_TREASURE = 4;
	public static final int TILE_GEM = 5;
	public static final int TILE_TRAP = 6;

	// Directions
	public static final int DIR_NORTH = 0;
	public static final int DIR_EAST = 1;
	public static final int DIR_SOUTH = 2;
	public static final int DIR_WEST = 3;

	// Couleurs
	private static final Color BG_DARK = new Color(20, 22, 28);
	private static final Color HUD_BG = new Color(28, 32, 42);
	private static final Color FLOOR_LIGHT = new Color(50, 54, 65);
	private static final Color FLOOR_DARK = new Color(44, 48, 58);
	private static final Color WALL_TOP = new Color(88, 96, 112);
	private static final Color WALL_BODY = new Color(62, 68, 80);
	private static final Color WALL_SHADOW = new Color(32, 35, 42);
	private static final Color FOG_COLOR = new Color(14, 15, 19);

	// Grille courante
	private int width = 11;
	private int height = 11;
	private int[][] grid;
	private int[][] initialGrid;
	private boolean[][] visited;
	private List<Point> trail = new ArrayList<>();

	// État du héros
	private int heroX = 1;
	private int heroY = 1;
	private int heroDir = DIR_EAST;
	private int startX = 1;
	private int startY = 1;
	private int startDir = DIR_EAST;

	private int keysCount = 0;
	private int gemsCount = 0;
	private int stepsCount = 0;
	private boolean isAlive = true;
	private boolean hasWon = false;

	// Options
	private boolean fogOfWar = false;
	private int delayMs = 80;
	private int currentMapId = 1;

	public DungeonPanel() {
		setBackground(BG_DARK);
		loadMap(1);
	}

	///////////////////////////////////////////////////
	// Chargement des cartes
	///////////////////////////////////////////////////

	public synchronized int loadMap(int id) {
		currentMapId = id;
		switch (id) {
			case 1:
				setupMap1();
				break;
			case 2:
				setupMap2();
				break;
			case 3:
				setupMap3();
				break;
			case 4:
			default:
				setupMapRandom();
				break;
		}
		resetDungeon();
		return 1;
	}

	// Carte 1 : Couloir d'entraînement (11x11)
	private void setupMap1() {
		width = 11;
		height = 11;
		grid = new int[height][width];
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				grid[y][x] = TILE_WALL;
			}
		}
		// Couloir principal
		for (int x = 1; x <= 5; x++) grid[1][x] = TILE_EMPTY;
		for (int y = 1; y <= 5; y++) grid[y][5] = TILE_EMPTY;
		for (int x = 5; x <= 9; x++) grid[5][x] = TILE_EMPTY;
		for (int y = 5; y <= 9; y++) grid[y][9] = TILE_EMPTY;

		// Objets
		grid[3][5] = TILE_KEY;       // Clé sur le chemin
		grid[5][7] = TILE_DOOR;      // Porte verrouillée
		grid[7][9] = TILE_GEM;       // Gemme bonus
		grid[9][9] = TILE_TREASURE;  // Trésor au bout

		startX = 1;
		startY = 1;
		startDir = DIR_EAST;
		saveInitialGrid();
	}

	// Carte 2 : Labyrinthe classique (13x13)
	private void setupMap2() {
		width = 13;
		height = 13;
		grid = new int[height][width];
		// Initialiser avec des murs
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				grid[y][x] = TILE_WALL;
			}
		}

		// Chemins ouverts
		int[][] paths = {
			{1,1},{1,2},{1,3},{2,3},{3,3},{3,2},{3,1},{4,1},{5,1},{5,2},{5,3},{5,4},{5,5},
			{1,5},{2,5},{3,5},{1,7},{2,7},{3,7},{4,7},{5,7},{6,7},{7,7},
			{7,1},{7,2},{7,3},{7,4},{7,5},{8,5},{9,5},{9,4},{9,3},{9,2},{9,1},{10,1},{11,1},
			{11,2},{11,3},{11,4},{11,5},{11,6},{11,7},{11,8},{11,9},{11,10},{11,11},
			{9,7},{9,8},{9,9},{9,10},{9,11},{7,9},{7,10},{7,11},{5,9},{5,10},{5,11},
			{3,9},{3,10},{3,11},{1,9},{1,10},{1,11}
		};
		for (int[] p : paths) {
			if (p[1] < height && p[0] < width) grid[p[1]][p[0]] = TILE_EMPTY;
		}

		// Clé, porte, gemmes et trésor
		grid[1][11] = TILE_KEY;
		grid[11][8] = TILE_DOOR;
		grid[11][1] = TILE_GEM;
		grid[7][3] = TILE_GEM;
		grid[3][11] = TILE_GEM;
		grid[11][11] = TILE_TREASURE;

		startX = 1;
		startY = 1;
		startDir = DIR_SOUTH;
		saveInitialGrid();
	}

	// Carte 3 : Le Donjon des Clés & Pièges (15x15)
	private void setupMap3() {
		width = 15;
		height = 15;
		grid = new int[height][width];
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				grid[y][x] = TILE_WALL;
			}
		}

		// Salles et couloirs
		// Salle 1 (Départ) : (1,1) à (3,3)
		for (int y = 1; y <= 3; y++) {
			for (int x = 1; x <= 3; x++) grid[y][x] = TILE_EMPTY;
		}
		// Couloir Est
		for (int x = 3; x <= 7; x++) grid[2][x] = TILE_EMPTY;

		// Salle 2 (Centrale) : (7,1) à (11,5)
		for (int y = 1; y <= 5; y++) {
			for (int x = 7; x <= 11; x++) grid[y][x] = TILE_EMPTY;
		}

		// Couloir Sud
		for (int y = 5; y <= 9; y++) grid[y][9] = TILE_EMPTY;

		// Salle 3 (Ouest) : (1,8) à (5,12)
		for (int y = 8; y <= 12; y++) {
			for (int x = 1; x <= 5; x++) grid[y][x] = TILE_EMPTY;
		}
		// Jonction vers salle 3
		for (int x = 5; x <= 9; x++) grid[9][x] = TILE_EMPTY;

		// Couloir vers la crypte du trésor
		for (int y = 9; y <= 13; y++) grid[y][13] = TILE_EMPTY;
		for (int x = 9; x <= 13; x++) grid[13][x] = TILE_EMPTY;

		// Clés, Portes, Gemmes et Pièges
		grid[2][11] = TILE_KEY;        // Clé 1
		grid[9][7] = TILE_DOOR;        // Porte 1
		grid[10][3] = TILE_KEY;        // Clé 2
		grid[13][11] = TILE_DOOR;      // Porte 2 (sanctuaire)
		grid[13][13] = TILE_TREASURE;  // Trésor

		// Gemmes
		grid[1][1] = TILE_GEM;
		grid[5][11] = TILE_GEM;
		grid[8][1] = TILE_GEM;
		grid[12][5] = TILE_GEM;

		// Pièges
		grid[3][9] = TILE_TRAP;
		grid[11][3] = TILE_TRAP;

		startX = 2;
		startY = 2;
		startDir = DIR_EAST;
		saveInitialGrid();
	}

	// Carte 4 : Labyrinthe aléatoire parfait (15x15) par DFS
	private void setupMapRandom() {
		width = 15;
		height = 15;
		grid = new int[height][width];
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				grid[y][x] = TILE_WALL;
			}
		}

		// Creusement par DFS à partir de (1,1)
		Random rand = new Random();
		boolean[][] visitedDfs = new boolean[height][width];
		dfsCarve(1, 1, visitedDfs, rand);

		// Placer trésor au point accessible le plus éloigné
		int maxDist = -1;
		int treasureX = 1;
		int treasureY = 1;

		// Calcul de distance par BFS simple
		int[][] dist = new int[height][width];
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) dist[y][x] = -1;
		}
		List<Point> queue = new ArrayList<>();
		queue.add(new Point(1, 1));
		dist[1][1] = 0;

		int[] dx = {0, 1, 0, -1};
		int[] dy = {-1, 0, 1, 0};

		while (!queue.isEmpty()) {
			Point p = queue.remove(0);
			if (dist[p.y][p.x] > maxDist) {
				maxDist = dist[p.y][p.x];
				treasureX = p.x;
				treasureY = p.y;
			}
			for (int i = 0; i < 4; i++) {
				int nx = p.x + dx[i];
				int ny = p.y + dy[i];
				if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
					if (grid[ny][nx] == TILE_EMPTY && dist[ny][nx] == -1) {
						dist[ny][nx] = dist[p.y][p.x] + 1;
						queue.add(new Point(nx, ny));
					}
				}
			}
		}

		grid[treasureY][treasureX] = TILE_TREASURE;

		// Ajouter quelques gemmes et une clé/porte si possible
		List<Point> openCells = new ArrayList<>();
		for (int y = 1; y < height - 1; y++) {
			for (int x = 1; x < width - 1; x++) {
				if (grid[y][x] == TILE_EMPTY && (x != 1 || y != 1)) {
					openCells.add(new Point(x, y));
				}
			}
		}
		Collections.shuffle(openCells, rand);

		int gemsPlaced = 0;
		for (Point p : openCells) {
			if (gemsPlaced < 3 && dist[p.y][p.x] > 4) {
				grid[p.y][p.x] = TILE_GEM;
				gemsPlaced++;
			}
		}

		startX = 1;
		startY = 1;
		startDir = DIR_EAST;
		saveInitialGrid();
	}

	private void dfsCarve(int x, int y, boolean[][] visitedDfs, Random rand) {
		visitedDfs[y][x] = true;
		grid[y][x] = TILE_EMPTY;

		int[] dirs = {0, 1, 2, 3};
		// Mélanger les directions
		for (int i = 0; i < 4; i++) {
			int r = rand.nextInt(4);
			int tmp = dirs[i];
			dirs[i] = dirs[r];
			dirs[r] = tmp;
		}

		int[] dx = {0, 2, 0, -2};
		int[] dy = {-2, 0, 2, 0};

		for (int d : dirs) {
			int nx = x + dx[d];
			int ny = y + dy[d];
			if (nx > 0 && nx < width - 1 && ny > 0 && ny < height - 1 && !visitedDfs[ny][nx]) {
				grid[y + dy[d] / 2][x + dx[d] / 2] = TILE_EMPTY;
				dfsCarve(nx, ny, visitedDfs, rand);
			}
		}
	}

	private void saveInitialGrid() {
		initialGrid = new int[height][width];
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				initialGrid[y][x] = grid[y][x];
			}
		}
	}

	///////////////////////////////////////////////////
	// Réinitialisation
	///////////////////////////////////////////////////

	public synchronized int resetDungeon() {
		grid = new int[height][width];
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				grid[y][x] = initialGrid[y][x];
			}
		}
		heroX = startX;
		heroY = startY;
		heroDir = startDir;
		keysCount = 0;
		gemsCount = 0;
		stepsCount = 0;
		isAlive = true;
		hasWon = false;

		visited = new boolean[height][width];
		trail.clear();
		trail.add(new Point(heroX, heroY));

		updateVisibility();
		repaint();
		return 1;
	}

	private void updateVisibility() {
		if (visited == null) visited = new boolean[height][width];
		visited[heroY][heroX] = true;
		// Révéler le voisinage immédiat (rayon 1)
		for (int dy = -1; dy <= 1; dy++) {
			for (int dx = -1; dx <= 1; dx++) {
				int nx = heroX + dx;
				int ny = heroY + dy;
				if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
					visited[ny][nx] = true;
				}
			}
		}
	}

	///////////////////////////////////////////////////
	// Méthodes de l'API
	///////////////////////////////////////////////////

	public synchronized int stepForward() {
		if (!isAlive || hasWon) return 0;

		int nx = heroX;
		int ny = heroY;
		switch (heroDir) {
			case DIR_NORTH: ny--; break;
			case DIR_EAST:  nx++; break;
			case DIR_SOUTH: ny++; break;
			case DIR_WEST:  nx--; break;
		}

		if (nx < 0 || nx >= width || ny < 0 || ny >= height) return 0;

		int targetTile = grid[ny][nx];
		if (targetTile == TILE_WALL || targetTile == TILE_DOOR) {
			return 0; // Bloqué
		}

		// Déplacement accepté
		heroX = nx;
		heroY = ny;
		stepsCount++;
		trail.add(new Point(heroX, heroY));

		if (targetTile == TILE_TRAP) {
			isAlive = false;
			updateVisibility();
			repaint();
			sleepDelay();
			return -1; // Piégé !
		}

		if (targetTile == TILE_KEY) {
			keysCount++;
			grid[ny][nx] = TILE_EMPTY;
		} else if (targetTile == TILE_GEM) {
			gemsCount++;
			grid[ny][nx] = TILE_EMPTY;
		} else if (targetTile == TILE_TREASURE) {
			hasWon = true;
		}

		updateVisibility();
		repaint();
		sleepDelay();
		return 1;
	}

	public synchronized int turnLeft() {
		heroDir = (heroDir + 3) % 4;
		updateVisibility();
		repaint();
		sleepDelay();
		return heroDir;
	}

	public synchronized int turnRight() {
		heroDir = (heroDir + 1) % 4;
		updateVisibility();
		repaint();
		sleepDelay();
		return heroDir;
	}

	public synchronized int turnBack() {
		heroDir = (heroDir + 2) % 4;
		updateVisibility();
		repaint();
		sleepDelay();
		return heroDir;
	}

	public synchronized int lookAhead() {
		int nx = heroX;
		int ny = heroY;
		switch (heroDir) {
			case DIR_NORTH: ny--; break;
			case DIR_EAST:  nx++; break;
			case DIR_SOUTH: ny++; break;
			case DIR_WEST:  nx--; break;
		}
		if (nx < 0 || nx >= width || ny < 0 || ny >= height) return TILE_WALL;
		return grid[ny][nx];
	}

	public synchronized int canMoveForward() {
		int tile = lookAhead();
		return (tile != TILE_WALL && tile != TILE_DOOR && isAlive && !hasWon) ? 1 : 0;
	}

	public synchronized int openDoor() {
		if (keysCount <= 0) return 0;
		int nx = heroX;
		int ny = heroY;
		switch (heroDir) {
			case DIR_NORTH: ny--; break;
			case DIR_EAST:  nx++; break;
			case DIR_SOUTH: ny++; break;
			case DIR_WEST:  nx--; break;
		}
		if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
			if (grid[ny][nx] == TILE_DOOR) {
				keysCount--;
				grid[ny][nx] = TILE_EMPTY;
				updateVisibility();
				repaint();
				sleepDelay();
				return 1;
			}
		}
		return 0;
	}

	public synchronized int pickItem() {
		int tile = grid[heroY][heroX];
		if (tile == TILE_KEY) {
			keysCount++;
			grid[heroY][heroX] = TILE_EMPTY;
			repaint();
			return 1;
		} else if (tile == TILE_GEM) {
			gemsCount++;
			grid[heroY][heroX] = TILE_EMPTY;
			repaint();
			return 1;
		}
		return 0;
	}

	public int getDirection() { return heroDir; }
	public int getHeroX() { return heroX; }
	public int getHeroY() { return heroY; }
	public int hasKey() { return keysCount > 0 ? 1 : 0; }
	public int getGemsCount() { return gemsCount; }
	public int getStepsCount() { return stepsCount; }
	public int isTreasureReached() { return hasWon ? 1 : 0; }
	public int getMapWidth() { return width; }
	public int getMapHeight() { return height; }
	public int getCurrentMapId() { return currentMapId; }

	public synchronized int getCell(int x, int y) {
		if (x < 0 || x >= width || y < 0 || y >= height) return TILE_WALL;
		return grid[y][x];
	}

	public synchronized int setFogOfWar(boolean enabled) {
		this.fogOfWar = enabled;
		repaint();
		return 1;
	}

	public boolean isFogOfWar() { return fogOfWar; }

	public synchronized int setDelay(int ms) {
		this.delayMs = Math.max(0, ms);
		return 1;
	}

	public int getDelay() { return delayMs; }

	private void sleepDelay() {
		if (delayMs > 0) {
			try {
				Thread.sleep(delayMs);
			} catch (InterruptedException ignored) {}
		}
	}

	///////////////////////////////////////////////////
	// Rendu Graphique (Swing paintComponent)
	///////////////////////////////////////////////////

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g.create();
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

		int panelW = getWidth();
		int panelH = getHeight();

		// Rendu du HUD supérieur
		int hudH = 46;
		drawHUD(g2, panelW, hudH);

		// Calcul de la taille et du centrage des cellules
		int availW = panelW - 30;
		int availH = panelH - hudH - 30;
		int cellSize = Math.min(availW / width, availH / height);
		cellSize = Math.max(18, Math.min(64, cellSize));

		int startDrawX = (panelW - width * cellSize) / 2;
		int startDrawY = hudH + (panelH - hudH - height * cellSize) / 2;

		// Rendu des tuiles
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				int px = startDrawX + x * cellSize;
				int py = startDrawY + y * cellSize;

				boolean isCellVisible = !fogOfWar || (visited != null && visited[y][x]);
				if (!isCellVisible) {
					drawFogTile(g2, px, py, cellSize);
				} else {
					drawFloorTile(g2, px, py, cellSize, (x + y) % 2 == 0);
					drawTrail(g2, x, y, px, py, cellSize);
					drawTileContent(g2, grid[y][x], px, py, cellSize);
				}
			}
		}

		// Rendu du héros
		if (!fogOfWar || (visited != null && visited[heroY][heroX])) {
			int hpx = startDrawX + heroX * cellSize;
			int hpy = startDrawY + heroY * cellSize;
			drawHero(g2, hpx, hpy, cellSize);
		}

		g2.dispose();
	}

	private void drawHUD(Graphics2D g2, int w, int h) {
		g2.setColor(HUD_BG);
		g2.fillRect(0, 0, w, h);
		g2.setColor(new Color(45, 52, 68));
		g2.drawLine(0, h - 1, w, h - 1);

		// Badge de statut
		int badgeX = 14;
		int badgeY = 9;
		int badgeH = 28;
		String statusText;
		Color badgeBg;
		Color badgeFg = Color.WHITE;

		if (hasWon) {
			statusText = "★ VICTOIRE ! Trésor atteint en " + stepsCount + " pas";
			badgeBg = new Color(39, 174, 96);
		} else if (!isAlive) {
			statusText = "💀 GAME OVER ! Piège déclenché";
			badgeBg = new Color(192, 57, 43);
		} else {
			statusText = "🧭 En exploration...";
			badgeBg = new Color(41, 128, 185);
		}

		g2.setFont(new Font("SansSerif", Font.BOLD, 13));
		FontMetrics fm = g2.getFontMetrics();
		int badgeW = fm.stringWidth(statusText) + 20;

		g2.setColor(badgeBg);
		g2.fill(new RoundRectangle2D.Float(badgeX, badgeY, badgeW, badgeH, 12, 12));
		g2.setColor(badgeFg);
		g2.drawString(statusText, badgeX + 10, badgeY + 19);

		// Compteurs d'inventaire
		int statX = badgeX + badgeW + 24;
		String dirStr = new String[]{"NORD", "EST", "SUD", "OUEST"}[heroDir];
		String info = String.format("🗝 Clés : %d    💎 Gemmes : %d    👣 Pas : %d    🧭 Cap : %s",
			keysCount, gemsCount, stepsCount, dirStr);

		g2.setColor(new Color(200, 210, 225));
		g2.setFont(new Font("SansSerif", Font.PLAIN, 13));
		g2.drawString(info, statX, badgeY + 19);
	}

	private void drawFogTile(Graphics2D g2, int px, int py, int s) {
		g2.setColor(FOG_COLOR);
		g2.fillRect(px, py, s, s);
		g2.setColor(new Color(26, 28, 36));
		g2.drawRect(px, py, s, s);
	}

	private void drawFloorTile(Graphics2D g2, int px, int py, int s, boolean alt) {
		g2.setColor(alt ? FLOOR_LIGHT : FLOOR_DARK);
		g2.fillRect(px, py, s, s);
		g2.setColor(new Color(36, 40, 50));
		g2.drawRect(px, py, s, s);
	}

	private void drawTrail(Graphics2D g2, int gx, int gy, int px, int py, int s) {
		if (trail.contains(new Point(gx, gy)) && (gx != heroX || gy != heroY)) {
			g2.setColor(new Color(241, 196, 15, 75));
			int dotR = Math.max(3, s / 7);
			g2.fillOval(px + s / 2 - dotR / 2, py + s / 2 - dotR / 2, dotR, dotR);
		}
	}

	private void drawTileContent(Graphics2D g2, int tile, int px, int py, int s) {
		switch (tile) {
			case TILE_WALL:
				drawWall(g2, px, py, s);
				break;
			case TILE_KEY:
				drawKey(g2, px, py, s);
				break;
			case TILE_DOOR:
				drawDoor(g2, px, py, s);
				break;
			case TILE_TREASURE:
				drawTreasure(g2, px, py, s);
				break;
			case TILE_GEM:
				drawGem(g2, px, py, s);
				break;
			case TILE_TRAP:
				drawTrap(g2, px, py, s);
				break;
		}
	}

	private void drawWall(Graphics2D g2, int px, int py, int s) {
		g2.setColor(WALL_BODY);
		g2.fillRect(px, py, s, s);

		// Relief biseauté
		g2.setColor(WALL_TOP);
		g2.fillRect(px, py, s, 3);
		g2.fillRect(px, py, 3, s);

		g2.setColor(WALL_SHADOW);
		g2.fillRect(px, py + s - 3, s, 3);
		g2.fillRect(px + s - 3, py, 3, s);

		// Dessin des briques de pierre
		g2.setColor(WALL_SHADOW);
		int midY = py + s / 2;
		g2.drawLine(px + 2, midY, px + s - 2, midY);
		g2.drawLine(px + s / 2, py + 2, px + s / 2, midY);
		g2.drawLine(px + s / 4, midY, px + s / 4, py + s - 2);
		g2.drawLine(px + 3 * s / 4, midY, px + 3 * s / 4, py + s - 2);
	}

	private void drawKey(Graphics2D g2, int px, int py, int s) {
		int cx = px + s / 2;
		int cy = py + s / 2;
		int r = Math.max(3, s / 6);

		g2.setColor(new Color(255, 215, 0));
		g2.setStroke(new BasicStroke(Math.max(2, s / 12)));
		// Anneau
		g2.drawOval(cx - r - r / 2, cy - r, 2 * r, 2 * r);
		// Tige
		g2.drawLine(cx - r / 2, cy, cx + r + r / 2, cy);
		// Dents
		g2.drawLine(cx + r, cy, cx + r, cy + r);
		g2.drawLine(cx + r + r / 2, cy, cx + r + r / 2, cy + r);
	}

	private void drawDoor(Graphics2D g2, int px, int py, int s) {
		// Porte en chêne avec renforts en fer
		int m = Math.max(2, s / 10);
		g2.setColor(new Color(120, 60, 20));
		g2.fillRoundRect(px + m, py + m, s - 2 * m, s - 2 * m, 6, 6);

		// Renforts en fer
		g2.setColor(new Color(75, 80, 90));
		g2.fillRect(px + m, py + s / 4, s - 2 * m, Math.max(2, s / 10));
		g2.fillRect(px + m, py + 3 * s / 4, s - 2 * m, Math.max(2, s / 10));

		// Serrure dorée
		g2.setColor(new Color(255, 215, 0));
		int lockR = Math.max(2, s / 12);
		g2.fillOval(px + s / 2 - lockR, py + s / 2 - lockR, 2 * lockR, 2 * lockR);
		g2.fillRect(px + s / 2 - lockR / 2, py + s / 2, lockR, lockR * 2);
	}

	private void drawTreasure(Graphics2D g2, int px, int py, int s) {
		int m = Math.max(3, s / 8);
		int cx = px + m;
		int cy = py + m;
		int cw = s - 2 * m;
		int ch = s - 2 * m;

		// Coffre
		g2.setColor(new Color(180, 100, 30));
		g2.fillRoundRect(cx, cy + ch / 3, cw, 2 * ch / 3, 6, 6);

		// Couvercle
		g2.setColor(hasWon ? new Color(241, 196, 15) : new Color(150, 80, 20));
		g2.fillRoundRect(cx, cy, cw, ch / 2, 8, 8);

		// Cerclages dorés
		g2.setColor(new Color(255, 215, 0));
		g2.fillRect(cx + cw / 4, cy, Math.max(2, cw / 8), ch);
		g2.fillRect(cx + 3 * cw / 4 - Math.max(2, cw / 8), cy, Math.max(2, cw / 8), ch);

		// Serrure
		g2.setColor(Color.WHITE);
		g2.fillOval(cx + cw / 2 - 3, cy + ch / 2 - 2, 6, 6);

		// Scintillement si gagné
		if (hasWon) {
			g2.setColor(new Color(255, 240, 100, 180));
			g2.fillOval(px + s / 2 - s / 3, py + s / 2 - s / 3, 2 * s / 3, 2 * s / 3);
		}
	}

	private void drawGem(Graphics2D g2, int px, int py, int s) {
		int cx = px + s / 2;
		int cy = py + s / 2;
		int r = Math.max(4, s / 4);

		Polygon poly = new Polygon();
		poly.addPoint(cx, cy - r);
		poly.addPoint(cx + r, cy);
		poly.addPoint(cx, cy + r);
		poly.addPoint(cx - r, cy);

		g2.setColor(new Color(46, 204, 113));
		g2.fillPolygon(poly);
		g2.setColor(new Color(230, 255, 240));
		g2.drawPolygon(poly);

		// Reflet spéculaire
		g2.setColor(Color.WHITE);
		g2.fillOval(cx - r / 3, cy - r / 2, Math.max(2, r / 3), Math.max(2, r / 3));
	}

	private void drawTrap(Graphics2D g2, int px, int py, int s) {
		int m = Math.max(2, s / 8);
		g2.setColor(new Color(25, 25, 25));
		g2.fillRect(px + m, py + m, s - 2 * m, s - 2 * m);

		// Piques métalliques acérées
		g2.setColor(new Color(192, 57, 43));
		g2.drawRect(px + m, py + m, s - 2 * m, s - 2 * m);
		g2.setColor(new Color(180, 180, 190));
		int cx = px + s / 2;
		int cy = py + s / 2;
		g2.drawLine(px + m + 2, py + m + 2, px + s - m - 2, py + s - m - 2);
		g2.drawLine(px + s - m - 2, py + m + 2, px + m + 2, py + s - m - 2);
		g2.fillOval(cx - 3, cy - 3, 6, 6);
	}

	private void drawHero(Graphics2D g2, int px, int py, int s) {
		int cx = px + s / 2;
		int cy = py + s / 2;
		int r = Math.max(6, s / 3);

		// Halo si victorieux
		if (hasWon) {
			g2.setColor(new Color(241, 196, 15, 120));
			g2.fillOval(cx - r - 4, cy - r - 4, 2 * r + 8, 2 * r + 8);
		}

		// Corps / armure de l'aventurier
		g2.setColor(isAlive ? new Color(41, 128, 185) : new Color(127, 140, 141));
		g2.fillOval(cx - r, cy - r, 2 * r, 2 * r);
		g2.setColor(Color.WHITE);
		g2.setStroke(new BasicStroke(Math.max(1, s / 20)));
		g2.drawOval(cx - r, cy - r, 2 * r, 2 * r);

		if (!isAlive) {
			// Croix de défaite
			g2.setColor(new Color(231, 76, 60));
			g2.setStroke(new BasicStroke(Math.max(2, s / 10)));
			g2.drawLine(cx - r / 2, cy - r / 2, cx + r / 2, cy + r / 2);
			g2.drawLine(cx + r / 2, cy - r / 2, cx - r / 2, cy + r / 2);
			return;
		}

		// Flèche / pointeur d'orientation
		int tipX = cx;
		int tipY = cy;
		int tipLen = r + Math.max(3, s / 8);
		Polygon arrow = new Polygon();

		switch (heroDir) {
			case DIR_NORTH:
				arrow.addPoint(cx, cy - tipLen);
				arrow.addPoint(cx - r / 2, cy - r / 3);
				arrow.addPoint(cx + r / 2, cy - r / 3);
				break;
			case DIR_EAST:
				arrow.addPoint(cx + tipLen, cy);
				arrow.addPoint(cx + r / 3, cy - r / 2);
				arrow.addPoint(cx + r / 3, cy + r / 2);
				break;
			case DIR_SOUTH:
				arrow.addPoint(cx, cy + tipLen);
				arrow.addPoint(cx - r / 2, cy + r / 3);
				arrow.addPoint(cx + r / 2, cy + r / 3);
				break;
			case DIR_WEST:
				arrow.addPoint(cx - tipLen, cy);
				arrow.addPoint(cx - r / 3, cy - r / 2);
				arrow.addPoint(cx - r / 3, cy + r / 2);
				break;
		}

		g2.setColor(new Color(241, 196, 15));
		g2.fillPolygon(arrow);
		g2.setColor(new Color(211, 84, 0));
		g2.drawPolygon(arrow);
	}
}
