package codelab.modules.dungeonmodule;

import codelab.AbstractModule;
import codelab.CodeLab;
import java.util.Map;

public class DungeonModule extends AbstractModule {

	private DungeonPanel panel;
	private DungeonModuleToolbar toolbar;

	///////////////////////////////////////////////////
	// Constructeur
	///////////////////////////////////////////////////

	public DungeonModule(CodeLab codelab) {
		super(codelab);
		loadProperties("lang.properties");
		setTitle(getLangProperty("title"));

		panel = new DungeonPanel();
		toolbar = new DungeonModuleToolbar(this);

		setToolbar(toolbar);
		setComponent(panel);
	}

	public DungeonPanel getPanel() {
		return panel;
	}

	public DungeonModuleToolbar getDungeonToolbar() {
		return toolbar;
	}

	///////////////////////////////////////////////////
	// Méthodes du cycle de vie CodeLab
	///////////////////////////////////////////////////

	@Override
	public void init() {
	}

	@Override
	public void exit() {
	}

	@Override
	public void start() {
		panel.resetDungeon();
	}

	@Override
	public void stop() {
	}

	@Override
	public void reset() {
		panel.resetDungeon();
	}

	///////////////////////////////////////////////////
	// Gestionnaire des requêtes API
	///////////////////////////////////////////////////

	@Override
	public String handleRequest(Map<String, String> params) {
		String cmd = params.get("cmd");
		if (cmd == null) return unknownCommandError("null");

		switch (cmd) {
			case "stepForward":
				return String.valueOf(panel.stepForward());

			case "turnLeft":
				return String.valueOf(panel.turnLeft());

			case "turnRight":
				return String.valueOf(panel.turnRight());

			case "turnBack":
				return String.valueOf(panel.turnBack());

			case "lookAhead":
				return String.valueOf(panel.lookAhead());

			case "canMoveForward":
				return String.valueOf(panel.canMoveForward());

			case "getDirection":
				return String.valueOf(panel.getDirection());

			case "getX":
				return String.valueOf(panel.getHeroX());

			case "getY":
				return String.valueOf(panel.getHeroY());

			case "hasKey":
				return String.valueOf(panel.hasKey());

			case "getGemsCount":
				return String.valueOf(panel.getGemsCount());

			case "getStepsCount":
				return String.valueOf(panel.getStepsCount());

			case "isTreasureReached":
				return String.valueOf(panel.isTreasureReached());

			case "openDoor":
				return String.valueOf(panel.openDoor());

			case "pickItem":
				return String.valueOf(panel.pickItem());

			case "loadMap":
				int mapId = Integer.valueOf(params.get("id"));
				toolbar.setMapSelection(mapId);
				return String.valueOf(panel.loadMap(mapId));

			case "resetDungeon":
				return String.valueOf(panel.resetDungeon());

			case "setFogOfWar":
				int fog = Integer.valueOf(params.get("enabled"));
				return String.valueOf(panel.setFogOfWar(fog == 1));

			case "setDelay":
				int delay = Integer.valueOf(params.get("ms"));
				return String.valueOf(panel.setDelay(delay));

			case "getMapWidth":
				return String.valueOf(panel.getMapWidth());

			case "getMapHeight":
				return String.valueOf(panel.getMapHeight());

			case "getCell":
				int x = Integer.valueOf(params.get("x"));
				int y = Integer.valueOf(params.get("y"));
				return String.valueOf(panel.getCell(x, y));

			default:
				return unknownCommandError(cmd);
		}
	}
}
