#!/bin/bash
#####################################################################
## This file is part of the software CodeLab IDE and Simulators    ##
## For any question about CodeLab e-mail to codelab@univ-lemans.fr ##
#####################################################################

## DO NOT DELETE OR MODIFY THIS SCRIPT !!

cd "$(dirname "$0")"
BASE=$(pwd)
MODULE=$(basename "$BASE")

rm -rf class/*
rm -f includes/*.c
rm -f includes/*.go
rm -f includes/*.py
rm -f includes/*.clp
rm -f includes/*.java
rm -f includes/*.html

cd ..

echo "Suppression des fichiers cachés..."
find $MODULE -type f -name '__MACOSX' -delete 2>/dev/null
find $MODULE -type f -name '.DS_Store' -delete 2>/dev/null
find $MODULE -type f -name '._*' -delete 2>/dev/null

echo "Compression du dossier..."
zip -qr $MODULE.zip $MODULE
echo "Archive $MODULE.zip générée."
