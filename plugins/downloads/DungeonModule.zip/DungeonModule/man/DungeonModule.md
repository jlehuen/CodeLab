<style>
img[alt=center] {
	display: block;
	margin: 0 auto;
}
</style>

# Le Donjon Algorithmique (`DungeonModule`)

Le module **DungeonModule** transforme CodeLab en un laboratoire d'exploration 2D interactif. Aux commandes d'un aventurier virtuel dans un dédale médiéval, l'étudiant apprend à formuler des algorithmes de déplacement, de perception, de prise de décision et de recherche de chemin.

![center](dungeon.png)

## Sommaire

1. [Objectifs Pédagogiques](#1-objectifs-pédagogiques)
2. [Interface Graphique & Éléments du Donjon](#2-interface-graphique--éléments-du-donjon)
3. [Les 4 Cartes Intégrées](#3-les-4-cartes-intégrées)
4. [Référence Complète de l'API](#4-référence-complète-de-lapi)
5. [Exemples Didactiques Progressifs](#5-exemples-didactiques-progressifs)
   - [Exemple 1 : Premiers pas et conditionnelles (Python)](#exemple-1--premiers-pas-et-conditionnelles-python)
   - [Exemple 2 : Algorithme de la main droite (C)](#exemple-2--algorithme-de-la-main-droite-c)
   - [Exemple 3 : Programmation Objet & Brouillard de guerre (Java)](#exemple-3--programmation-objet--brouillard-de-guerre-java)
   - [Exemple 4 : Système Expert à base de règles (CLIPS)](#exemple-4--système-expert-à-base-de-règles-clips)
   - [Exemple 5 (Avancé) : Plus court chemin par parcours en largeur BFS (Python)](#exemple-5-avancé--plus-court-chemin-par-parcours-en-largeur-bfs-python)
6. [Défis & Sujets d'Exercices](#6-défis--sujets-dexercices)

---

## 1. Objectifs Pédagogiques

Le module est conçu pour couvrir un large spectre de compétences informatiques :

* **Niveau Débutant (L1 / Lycée)** :
  * Assimiler la séquence d'instructions et la boucle d'exécution (`while`).
  * Manipuler les structures alternatives (`if / elif / else`).
  * Comprendre le cycle perception-action : *regarder devant soi &rarr; décider &rarr; agir*.
* **Niveau Intermédiaire (L2 / IUT)** :
  * Concevoir des automates à états finis (navigation dans un labyrinthe).
  * Implémenter l'algorithme de suivi de mur (*règle de la main droite / main gauche*).
  * Gérer un inventaire d'état (clés, gemmes, score, compteur de pas).
  * Travailler avec des coordonnées cartésiennes et des matrices 2D.
* **Niveau Avancé (L3 / Master)** :
  * Recherche opérationnelle et parcours de graphes : parcours en profondeur (**DFS**), parcours en largeur (**BFS**), algorithme **A\*** avec heuristique de Manhattan.
  * Exploration sous incertitude avec le mode **Brouillard de guerre** (*Fog of War*).
  * Systèmes experts en **CLIPS** : déduction logique et chaînage avant pour la navigation autonome.

---

## 2. Interface Graphique & Éléments du Donjon

L'interface graphique Swing se divise en trois parties :

1. **Le Bandeau Tête Haute (HUD)** supérieur :
   * **Badge d'état** : indique en temps réel si l'aventurier est *En exploration* (bleu), s'il a remporté la *Victoire* (vert) ou s'il a déclenché un piège mortel *Game Over* (rouge).
   * **Compteurs** : nombre de clés disponibles (🗝), gemmes ramassées (💎), pas totaux (👣) et cap courant (🧭 NORD, EST, SUD, OUEST).
2. **Le Plateau de Jeu 2D** :
   * Grille texturée en dalles de pierre avec centrage dynamique et antialiasing.
   * L'aventurier est représenté avec son cap visible (flèche dorée pointant dans la direction du regard).
   * Les empreintes de pas (*trail*) restent visibles sous forme de points dorés pour visualiser le chemin et le retour sur trace (*backtracking*).
3. **La Barre d'Outils** :
   * **Réinitialiser** : replace le héros au point de départ et restaure les objets.
   * **Nouveau labyrinthe** : génère instantanément un dédale procédural aléatoire.
   * **Sélecteur de carte** : menu déroulant des 4 environnements préconfigurés.
   * **Brouillard de guerre** : active/désactive le masquage des cases non explorées.
   * **Curseur de pause** : règle la vitesse de temporisation (de 0 ms instantané à 300 ms) pour observer l'exécution pas à pas.
   * **Manuel de l'atelier (HTML)** : ouvre directement le manuel de référence dans le navigateur web par défaut.

### Types de Tuiles

| Symbole | Constante | Code | Rôle dans le donjon |
| :---: | :--- | :---: | :--- |
| ⬛ | `TILE_EMPTY` | `0` | Sol en dalles de pierre, case libre et circulable. |
| 🧱 | `TILE_WALL` | `1` | Mur de pierre 3D infranchissable. |
| 🗝 | `TILE_KEY` | `2` | Clé dorée. Ramassée automatiquement en marchant dessus. |
| 🚪 | `TILE_DOOR` | `3` | Porte en chêne renforcée. Bloque le passage jusqu'à l'appel à `openDoor()`. |
| 🏆 | `TILE_TREASURE` | `4` | Coffre au trésor. L'atteindre valide la victoire immédiate ! |
| 💎 | `TILE_GEM` | `5` | Gemme émeraude taillée. Bonus collectable pour améliorer son score. |
| 💀 | `TILE_TRAP` | `6` | Dalle piégée munie de pointes métalliques. Mortelle : provoque le Game Over. |

---

## 3. Les 4 Cartes Intégrées

1. **Carte 1 : Entraînement (11 &times; 11)**  
   Un couloir coudé sans embranchement complexe. Comprend une clé à récupérer, une porte verrouillée à ouvrir, une gemme et le coffre final. Idéale pour le premier programme d'initiation.
2. **Carte 2 : Labyrinthe classique (13 &times; 13)**  
   Un dédale traditionnel comportant des impasses, des carrefours et des gemmes disséminées. Parfait pour expérimenter la règle de la main droite.
3. **Carte 3 : Donjon Clés & Pièges (15 &times; 15)**  
   Un donjon riche composé de plusieurs salles connectées : 2 clés obligatoires, 2 portes distinctes, 4 gemmes et des dalles piégées mortelles à contourner.
4. **Carte 4 : Aléatoire DFS (15 &times; 15)**  
   Généré dynamiquement par un algorithme de creusement récursif (*Depth-First Search*). Un nouveau labyrinthe parfait (sans cycle) est produit à chaque appel, garantissant un chemin unique vers le trésor situé au point le plus éloigné.

---

## 4. Référence Complète de l'API

Tous les ponts d'appel sont disponibles à l'identique dans chaque langage via la bibliothèque `DungeonModuleAPI`.

### Constantes d'Orientation

```python
DIR_NORTH = 0  # Vers le haut (Y décroissant)
DIR_EAST  = 1  # Vers la droite (X croissant)
DIR_SOUTH = 2  # Vers le bas (Y croissant)
DIR_WEST  = 3  # Vers la gauche (X décroissant)
```

### Fonctions d'Action et de Déplacement

| Fonction | Retour | Description |
| :--- | :---: | :--- |
| `stepForward()` | `int` | Avance d'une case dans la direction courante. Renvoie `1` si le déplacement réussit, `0` si bloqué (mur ou porte), `-1` si le héros marche sur un piège mortel. |
| `turnLeft()` | `int` | Pivote de 90° vers la gauche (sens anti-horaire). Renvoie le nouveau cap. |
| `turnRight()` | `int` | Pivote de 90° vers la droite (sens horaire). Renvoie le nouveau cap. |
| `turnBack()` | `int` | Effectue un demi-tour à 180°. Renvoie le nouveau cap. |
| `openDoor()` | `int` | Déverrouille et retire la porte située immédiatement devant si le héros possède au moins une clé. Consomme une clé. Renvoie `1` en cas de succès, `0` sinon. |
| `pickItem()` | `int` | Ramasse manuellement un objet sur la case courante (clé ou gemme). |

### Fonctions de Perception et Capteurs

| Fonction | Retour | Description |
| :--- | :---: | :--- |
| `lookAhead()` | `int` | Renvoie la constante de tuile (`TILE_*`) située immédiatement devant l'aventurier. |
| `canMoveForward()` | `int` | Renvoie `1` si la case devant est libre (sol, clé, gemme ou trésor), `0` si bloquée par un mur ou une porte. |
| `getDirection()` | `int` | Renvoie la direction courante (`DIR_NORTH`, `DIR_EAST`, `DIR_SOUTH`, `DIR_WEST`). |
| `getX()` / `getY()` | `int` | Renvoie la colonne `X` ou la ligne `Y` courante du joueur (base 0). |
| `getCell(x, y)` | `int` | Inspecte le type de tuile (`TILE_*`) à n'importe quelle coordonnée de la grille. |

### Fonctions d'État et Inventaire

| Fonction | Retour | Description |
| :--- | :---: | :--- |
| `hasKey()` | `int` | Renvoie `1` si le joueur possède au moins une clé, `0` sinon. |
| `getGemsCount()` | `int` | Renvoie le nombre total de gemmes précieuses collectées. |
| `getStepsCount()` | `int` | Renvoie le nombre total de déplacements effectués. |
| `isTreasureReached()` | `int` | Renvoie `1` dès que l'aventurier a posé le pied sur le coffre au trésor. |

### Fonctions de Configuration et Contrôle

| Fonction | Arguments | Description |
| :--- | :---: | :--- |
| `loadMap(id)` | `id` : 1 à 4 | Charge la carte spécifiée et repositionne le héros au départ. |
| `resetDungeon()` | - | Réinitialise la carte active à son état initial. |
| `setFogOfWar(enabled)` | `1` ou `0` | Active ou désactive le mode brouillard de guerre. |
| `setDelay(ms)` | `ms` : délai | Règle la pause entre chaque mouvement (en millisecondes). |
| `getMapWidth()` / `getMapHeight()` | - | Dimensions en nombre de tuiles de la carte active. |

---

## 5. Exemples Didactiques Progressifs

### Exemple 1 : Premiers pas et conditionnelles (Python)

Ce premier programme apprend à l'étudiant à piloter le héros sur la **Carte 1**. Il montre comment observer devant soi avec `lookAhead()`, réagir face à une porte verrouillée, et s'arrêter dès que le trésor est atteint.

```python
## Exploration guidée de la Carte 1
from codelab.dungeonmodule.DungeonModuleAPI import *

# 1. Configuration
setDelay(100)      # Pause de 100 ms par action pour observer le déplacement
loadMap(1)         # Charger la carte d'entraînement

print("Départ de l'aventure !")

# 2. Boucle principale d'exploration
while not isTreasureReached():
    ahead = lookAhead()
    
    # Cas 1 : Une porte fermée nous barre la route
    if ahead == TILE_DOOR:
        if hasKey():
            print("Clé trouvée : ouverture de la porte !")
            openDoor()
        else:
            print("Porte verrouillée mais pas de clé ! Arrêt.")
            break
            
    # Cas 2 : La voie est dégagée
    elif canMoveForward():
        stepForward()
        
    # Cas 3 : Face à un mur, tourner à droite
    else:
        turnRight()

# 3. Bilan de la quête
if isTreasureReached():
    print(f"Victoire ! Trésor atteint en {getStepsCount()} pas.")
    print(f"Nombre de gemmes récoltées : {getGemsCount()}")
```

---

### Exemple 2 : Algorithme de la main droite (C)

L'algorithme de la **main droite** (*Right-Hand Rule*) est la méthode canonique pour résoudre un labyrinthe : en gardant continuellement la main droite en contact avec le mur, on explore méthodiquement les coursives sans jamais tourner en rond dans un labyrinthe connexe.

```c
/*
 * Résolution du labyrinthe (Carte 2) par la règle de la main droite en C
 */
#include <stdio.h>
#include "codelab/dungeonmodule/DungeonModuleAPI.c"

void main() {
    setDelay(60);   // Animation fluide
    loadMap(2);     // Charger le labyrinthe classique
    printf("Lancement du suivi de mur en C...\n");

    while (!isTreasureReached()) {
        // 1. Priorité 1 : Tourner à droite pour longer le mur droit
        turnRight();

        // 2. Tenter d'avancer à droite
        if (lookAhead() == TILE_DOOR && hasKey()) {
            openDoor();
            stepForward();
        } else if (canMoveForward()) {
            stepForward();
        } else {
            // 3. Mur à droite : regarder tout droit
            turnLeft();
            if (lookAhead() == TILE_DOOR && hasKey()) {
                openDoor();
                stepForward();
            } else if (canMoveForward()) {
                stepForward();
            } else {
                // 4. Mur devant : regarder à gauche
                turnLeft();
                if (lookAhead() == TILE_DOOR && hasKey()) {
                    openDoor();
                    stepForward();
                } else if (canMoveForward()) {
                    stepForward();
                } else {
                    // 5. Cul-de-sac : faire demi-tour
                    turnLeft();
                }
            }
        }
    }

    printf("Félicitations ! Trésor atteint en %d pas !\n", getStepsCount());
    printf("Gemmes récoltées : %d\n", getGemsCount());
}
```

---

### Exemple 3 : Programmation Objet & Brouillard de guerre (Java)

Cet exemple en Java active le mode **Brouillard de guerre**. Le héros avance dans l'obscurité totale et ne découvre son environnement qu'au fur et à mesure de ses pas.

```java
/*
 * Exploration en Java avec brouillard de guerre activé
 */
import codelab.dungeonmodule.DungeonModuleAPI;

class DungeonExplorer extends DungeonModuleAPI {

    public void run() {
        setDelay(80);
        loadMap(3);          // Carte 3 : Donjon complexe avec pièges
        setFogOfWar(1);      // Activation du brouillard de guerre !

        System.out.println("Exploration dans la pénombre...");

        while (isTreasureReached() == 0) {
            int ahead = lookAhead();

            // Évitement absolu des pièges mortels
            if (ahead == TILE_TRAP) {
                System.out.println("Attention : piège détecté devant ! Évitement.");
                turnLeft();
                continue;
            }

            // Gestion des portes
            if (ahead == TILE_DOOR) {
                if (hasKey() == 1) {
                    System.out.println("Porte ouverte avec succès !");
                    openDoor();
                } else {
                    System.out.println("Recherche d'une clé alternative...");
                    turnRight();
                    continue;
                }
            }

            // Mouvement
            if (canMoveForward() == 1) {
                stepForward();
            } else {
                turnRight();
            }
        }

        System.out.println("Victoire héroïque en " + getStepsCount() + " pas !");
    }

    public static void main(String[] args) {
        new DungeonExplorer().run();
    }
}
```

---

### Exemple 4 : Système Expert à base de règles (CLIPS)

CodeLab prend en charge nativement le moteur d'inférence **CLIPS**. Cet exemple montre la puissance de la programmation déclarative : au lieu d'une boucle impérative, un ensemble de **règles expertes** réagit automatiquement aux faits observés.

```lisp
;; Système expert d'exploration du Donjon en CLIPS
#requires codelab.dungeonmodule.DungeonModuleAPI

(defrule initialisation
    =>
    (setDelay 90)
    (loadMap 1)
    (printout t "Initialisation du moteur expert CLIPS..." crlf)
    (assert (action explorer))
)

;; Règle 1 : Détecter la victoire
(defrule victoire
    ?f <- (action explorer)
    (test (= (isTreasureReached) 1))
    =>
    (retract ?f)
    (printout t "Victoire ! Le trésor a été trouvé par le système expert." crlf)
)

;; Règle 2 : Ouvrir une porte si on a la clé
(defrule ouvrir-porte
    (action explorer)
    (test (= (isTreasureReached) 0))
    (test (= (lookAhead) 3))   ;; TILE_DOOR = 3
    (test (= (hasKey) 1))
    =>
    (printout t "Règle activée : ouverture de porte !" crlf)
    (openDoor)
)

;; Règle 3 : Avancer si la voie est libre
(defrule avancer
    (action explorer)
    (test (= (isTreasureReached) 0))
    (test (= (canMoveForward) 1))
    =>
    (stepForward)
)

;; Règle 4 : Tourner si obstacle
(defrule contourner-obstacle
    (action explorer)
    (test (= (isTreasureReached) 0))
    (test (= (canMoveForward) 0))
    =>
    (turnRight)
)
```

---

### Exemple 5 (Avancé) : Plus court chemin par parcours en largeur BFS (Python)

Pour les étudiants de L3 / Master, l'API fournit `getCell(x, y)` et les dimensions de la grille. L'étudiant peut ainsi modéliser le labyrinthe sous forme de graphe et calculer la trajectoire optimale au moyen d'un **parcours en largeur (Breadth-First Search)**.

```python
## Résolution optimale du labyrinthe par parcours en largeur (BFS)
from collections import deque
from codelab.dungeonmodule.DungeonModuleAPI import *

setDelay(50)
loadMap(2)

w = getMapWidth()
h = getMapHeight()
startX, startY = getX(), getY()

# 1. Localiser le trésor sur la grille
targetX, targetY = -1, -1
for y in range(h):
    for x in range(w):
        if getCell(x, y) == TILE_TREASURE:
            targetX, targetY = x, y
            break

print(f"Départ : ({startX}, {startY}) | Trésor détecté en : ({targetX}, {targetY})")

# 2. Algorithme BFS pour trouver la séquence de cellules
queue = deque([(startX, startY, [])])
visited = set([(startX, startY)])
best_path = None

directions = [(0, -1), (1, 0), (0, 1), (-1, 0)] # N, E, S, O

while queue:
    cx, cy, path = queue.popleft()
    if (cx, cy) == (targetX, targetY):
        best_path = path
        break
        
    for dx, dy in directions:
        nx, ny = cx + dx, cy + dy
        if 0 <= nx < w and 0 <= ny < h and (nx, ny) not in visited:
            cell = getCell(nx, ny)
            if cell != TILE_WALL: # Franchissable
                visited.add((nx, ny))
                queue.append((nx, ny, path + [(nx, ny)]))

print(f"Plus court chemin calculé : {len(best_path)} cases.")

# 3. Exécuter le déplacement physique
for nextX, nextY in best_path:
    # Calculer l'orientation requise
    curX, curY = getX(), getY()
    dx = nextX - curX
    dy = nextY - curY
    
    desiredDir = 0
    if dy == -1: desiredDir = DIR_NORTH
    elif dx == 1: desiredDir = DIR_EAST
    elif dy == 1: desiredDir = DIR_SOUTH
    elif dx == -1: desiredDir = DIR_WEST
    
    # Aligner le héros
    while getDirection() != desiredDir:
        turnRight()
        
    # Ouvrir la porte si nécessaire
    if lookAhead() == TILE_DOOR and hasKey():
        openDoor()
        
    stepForward()

print("Objectif atteint avec le nombre minimal absolu de mouvements !")
```

---

## 6. Défis & Sujets d'Exercices

Voici des énoncés de travaux pratiques prêts à l'emploi :

1. **Défi 1 &mdash; "Le Chasseur de Trésor Économe"** :  
   Sur la Carte 2 ou la Carte 4 (aléatoire), concevoir un programme qui rejoint le trésor en limitant au maximum le gaspillage de pas (comparer le score obtenu avec la règle de la main droite vs le BFS).
2. **Défi 2 &mdash; "Le Grand Chelem des Gemmes"** :  
   Sur la Carte 3, collecter **l'intégralité des 4 gemmes** disséminées dans les coursives secrètes avant de déverrouiller la salle du trésor final.
3. **Défi 3 &mdash; "Le Démineur Aveugle"** :  
   Sur la Carte 3 avec le mode brouillard de guerre activé, écrire un algorithme d'exploration prudente qui ne déclenche aucun piège (`TILE_TRAP`), même si ceux-ci ne sont visibles qu'au moment d'arriver sur la case contiguë.
4. **Défi 4 &mdash; "Système Expert Robuste en CLIPS"** :  
   Enrichir les règles CLIPS pour gérer les demi-tours, l'évitement des pièges et la priorité de collecte des clés dès qu'elles sont aperçues.
