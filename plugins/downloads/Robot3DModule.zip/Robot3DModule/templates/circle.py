## Program _fileName_
## Created by _author_ on _date_

from codelab.robot3dmodule.robotCoretech import *
from codelab.utils import *

FAST = 1

drawOn()
setColor(255, 0, 0)

theta = getRotation(MOTOR_BASE)
if theta == 0: theta = 360
print(theta)

motorOn(MOTOR_BASE, FAST)
waitFor(100)
while getRotation(MOTOR_BASE) > theta: pass
while getRotation(MOTOR_BASE) < theta: pass
motorOff(MOTOR_BASE)
