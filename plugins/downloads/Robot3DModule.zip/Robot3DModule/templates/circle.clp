;; Program _fileName_
;; Created by _author_ on _date_

#requires codelab.robot3dmodule.robotCoretech
#requires codelab.utils

(defglobal ?*FAST* = 1)

(defrule only-rule
	=>
	(drawOn)
	(setColor 255 0 0)
	
	(bind ?theta (getRotation ?*MOTOR_BASE*))
	(if (= ?theta 0) then (bind ?theta 360))
	(printout t ?theta)
	
	(motorOn ?*MOTOR_BASE* ?*FAST*)
	(waitFor 100)
	(while (> (getRotation ?*MOTOR_BASE*) ?theta) do)
	(while (< (getRotation ?*MOTOR_BASE*) ?theta) do)
	(motorOff ?*MOTOR_BASE*))
