/**
 * Class _className_
 * Created by _author_ on _date_
 */

import codelab.robot3dmodule.RobotCoretech;

class Threads extends RobotCoretech {

	private void run() {
		drawOn();
		setColor(0, 255, 0);
		
		removeAllThreads();
		defineThread(MOTOR_BASE, 0, -1f);
		defineThread(MOTOR_UPPERARM, 0, -0.5f);
		defineThread(MOTOR_LOWERARM, 0, -0.5f);
		defineThread(MOTOR_HAND, 0, -0.5f);
		startAllThreads();
	}

	public static void main(String args[]) {
		new Threads().run();
	}
}
