/*
 * Program _fileName_
 * Created by _author_ on _date_
 */

package main

import (robot "codelab/robot3dmodule/robotCoretech")

func main() {
	robot.DrawOn()
	robot.SetColor(0, 255, 0)
	
	robot.RemoveAllThreads()
	robot.DefineThread(robot.MOTOR_BASE, 0, -1)
	robot.DefineThread(robot.MOTOR_UPPERARM, 0, -0.5)
	robot.DefineThread(robot.MOTOR_LOWERARM, 0, -0.5)
	robot.DefineThread(robot.MOTOR_HAND, 0, -0.5)
	robot.StartAllThreads()
}
