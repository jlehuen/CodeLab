/*
 * Program _fileName_
 * Created by _author_ on _date_
 */

#include "codelab/robot3dmodule/robotCoretech.c"
#include "codelab/utils.c"

const float FAST = 1;


void main() {
	drawOn();
	setColor(255, 0, 0);

	float theta = getRotation(MOTOR_BASE);
	if (theta == 0.0) theta = 360;
	printf("%f", theta);
	
	motorOn(MOTOR_BASE, FAST);
	waitFor(100);
	while (getRotation(MOTOR_BASE) > theta);
	while (getRotation(MOTOR_BASE) < theta);
	motorOff(MOTOR_BASE);
}
