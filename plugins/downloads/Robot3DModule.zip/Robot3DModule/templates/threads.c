/*
 * Program _fileName_
 * Created by _author_ on _date_
 */

#include "codelab/robot3dmodule/robotCoretech.c"

void main() {
	drawOn();
	setColor(0, 255, 0);
		
	removeAllThreads();
	defineThread(MOTOR_BASE, 0, -1);
	defineThread(MOTOR_UPPERARM, 0, -0.5);
	defineThread(MOTOR_LOWERARM, 0, -0.5);
	defineThread(MOTOR_HAND, 0, -0.5);
	startAllThreads();
}
