/**
 * Class _className_
 * Created by _author_ on _date_
 */

import codelab.robot3dmodule.RobotCoretech;
import codelab.Utils;

class _className_ extends RobotCoretech {

	private final float FAST = 1;

	_className_() {
		drawOn();
		setColor(255, 0, 0);
	}

	private void run() {
	
		float theta = getRotation(MOTOR_BASE);
		if (theta == 0.0f) theta = 360;
		System.out.println(theta);
		
		motorOn(MOTOR_BASE, FAST);
		Utils.waitFor(100);
		while (getRotation(MOTOR_BASE) > theta);
		while (getRotation(MOTOR_BASE) < theta);
		motorOff(MOTOR_BASE);
	}

	public static void main(String args[]) {
		new _className_().run();
	}
}
