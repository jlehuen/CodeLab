/*
 * Program _fileName_
 * Created by _author_ on _date_
 */

package main

import (robot "codelab/robot3dmodule/robotCoretech")
import "time"
import "fmt"

func main() {

	const FAST float64 = 1.0

	robot.DrawOn()
	robot.SetColor(255, 0, 0)
	
	var theta = robot.GetRotation(robot.MOTOR_BASE)
	if theta == 0 { theta = 360 }
	fmt.Printf("%f", theta)
	
	robot.MotorOn(robot.MOTOR_BASE, FAST)
	time.Sleep(100 * time.Millisecond)
	for robot.GetRotation(robot.MOTOR_BASE) > theta {}
	for robot.GetRotation(robot.MOTOR_BASE) < theta {}
	robot.MotorOff(robot.MOTOR_BASE)
}
