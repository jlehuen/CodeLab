package codelab.modules.robot3dmodule;

import java.util.Map;

import codelab.CodeLab;
import codelab.AbstractModule;
import codelab.helper.AudioPlayer;
import codelab.modules.robot3dmodule.coretech.RobotCoreTech;

/**
*	Classe du module simulateur robotique 3D
*	@author Jérôme Lehuen
*	@version 09/04/23
*/

public class Robot3DModule extends AbstractModule {

	public static Robot3DModule INSTANCE;

	private Simulator3D simulator;

	///////////////////////////////////////////////////
	// Constructor
	///////////////////////////////////////////////////

	public Robot3DModule(CodeLab codelab) {
		super(codelab);
		INSTANCE = this;
		loadProperties("lang.properties");
		simulator = new Simulator3D(this);
		setToolbar(new ToolbarSim3D(this));
		setSystem(simulator.getRobot());
		setComponent(simulator);
		setTitle("Robot3DModule");
	}
	
	///////////////////////////////////////////////////
	// Getters et Setters
	///////////////////////////////////////////////////

	public Simulator3D getSimulator() {
		return simulator;
	}
	
	public String LABEL(String label) {
		return getLangProperty(label);
	}
	
	///////////////////////////////////////////////////
	// Méthodes publiques
	///////////////////////////////////////////////////
	
	public static void playAudio(String filename) {
		AudioPlayer player = new AudioPlayer(INSTANCE, filename);
		player.play();
	}

	///////////////////////////////////////////////////
	// AbstractModule methods to be implemented
	///////////////////////////////////////////////////

	public void init() {
	}
	
	public void exit() {
	}
	
	public void start() {
		simulator.start();
	}
	
	public void stop() {
		simulator.stop();
	}
	
	public void reset() {
		simulator.stop();
		simulator.reset();
		((ToolbarSim3D)toolbar).debug_off();
	}

	///////////////////////////////////////////////////
	// Instruction handler
	///////////////////////////////////////////////////

	public String handleRequest(Map<String, String> params) {
		String cmd = params.get("cmd");
		int motor, sensor, steps, code, r, g, b;
		float speed0, speed1, speed2, speed3;
		float speed, angle, x, y, z;

		switch (cmd) {
			case "motorOn":
				motor = Integer.valueOf(params.get("motor"));
				speed = Float.valueOf(params.get("speed").replace(",","."));
				return String.valueOf(simulator.getRobot().motorOn(motor, speed));

			case "motorOff":
				motor = Integer.valueOf(params.get("motor"));
				return String.valueOf(simulator.getRobot().motorOff(motor));

			case "motorOnMulti":
				speed0 = Float.valueOf(params.get("speed0").replace(",","."));
				speed1 = Float.valueOf(params.get("speed1").replace(",","."));
				speed2 = Float.valueOf(params.get("speed2").replace(",","."));
				speed3 = Float.valueOf(params.get("speed3").replace(",","."));
				return String.valueOf(simulator.getRobot().motorOnMulti(speed0, speed1, speed2, speed3));

			case "motorOffMulti":
				code = Integer.valueOf(params.get("code"));
				return String.valueOf(simulator.getRobot().motorOffMulti(code));

			case "motorStep":
				motor = Integer.valueOf(params.get("motor"));
				steps = Integer.valueOf(params.get("steps"));
				return String.valueOf(simulator.getRobot().motorStep(motor, steps));

			case "defineThread":
				motor = Integer.valueOf(params.get("motor"));
				angle = Float.valueOf(params.get("angle").replace(",","."));
				speed = Float.valueOf(params.get("speed").replace(",","."));
				return String.valueOf(simulator.getRobot().defineThread(motor, angle, speed));

			case "removeAllThreads": return String.valueOf(simulator.getRobot().removeAllThreads());
			case "startAllThreads": return String.valueOf(simulator.getRobot().startAllThreads());

			case "getRotation":
				motor = Integer.valueOf(params.get("motor"));
				return String.valueOf(simulator.getRobot().getRotation(motor));

			case "setRotation":
				motor = Integer.valueOf(params.get("motor"));
				angle = Float.valueOf(params.get("angle").replace(",","."));
				return String.valueOf(simulator.getRobot().setRotation(motor, angle));

			case "getSensorValue":
				sensor = Integer.valueOf(params.get("sensor"));
				return simulator.getRobot().getSensorValue(sensor);

			case "getX": return String.valueOf(simulator.getRobot().getX());
			case "getY": return String.valueOf(simulator.getRobot().getY());
			case "getZ": return String.valueOf(simulator.getRobot().getZ());

			case "grab": return String.valueOf(simulator.getRobot().grab());
			case "drop": return String.valueOf(simulator.getRobot().drop());
			case "plot": return String.valueOf(simulator.getRobot().plot());

			case "drawOn": return String.valueOf(simulator.getRobot().drawOn());
			case "drawOff": return String.valueOf(simulator.getRobot().drawOff());
			case "clearAll": return String.valueOf(simulator.getRobot().clearAll());

			case "setColor":
				r = Integer.valueOf(params.get("r"));
				g = Integer.valueOf(params.get("g"));
				b = Integer.valueOf(params.get("b"));
				return String.valueOf(simulator.getRobot().setColor(r, g, b));

			case "putBall":
				x = Float.valueOf(params.get("x").replace(",","."));
				y = Float.valueOf(params.get("y").replace(",","."));
				z = Float.valueOf(params.get("z").replace(",","."));
				r = Integer.valueOf(params.get("r"));
				g = Integer.valueOf(params.get("g"));
				b = Integer.valueOf(params.get("b"));
				String descr = params.get("descr");
				return simulator.getRobot().putBall(x, y, z, r, g, b, descr); // Retourne une chaîne

			case "getObjectPosition":
				String uid = params.get("uid");
				return simulator.getRobot().getObjectPosition(uid); // Retourne une chaîne

			case "getPencilPosition":
				return simulator.getRobot().getPencilPosition(); // Retourne une chaîne

			default:
				return unknownCommandError(cmd);
		}
	}
}
