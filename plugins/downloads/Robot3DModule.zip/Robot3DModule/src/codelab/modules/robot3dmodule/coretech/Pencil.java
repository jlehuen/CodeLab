package codelab.modules.robot3dmodule.coretech;

import org.jogamp.java3d.BranchGroup;
import org.jogamp.java3d.Shape3D;
import org.jogamp.java3d.Transform3D;
import org.jogamp.java3d.TransformGroup;
import org.jogamp.java3d.utils.geometry.Cylinder;
import org.jogamp.java3d.utils.geometry.Sphere;
import org.jogamp.vecmath.Point3d;
import org.jogamp.vecmath.Tuple3f;
import org.jogamp.vecmath.Vector3f;

import codelab.modules.robot3dmodule.AbstractRobotPart;
import codelab.modules.robot3dmodule.Constants;
import codelab.modules.robot3dmodule.Utils3D;

/**
*	Classe du pencil du robot CoreTech
*	@author Jérôme Lehuen
*	@version 02/02/21
*/

public class Pencil extends AbstractRobotPart {

	private static final String IDENT = "the pencil";
	private static final String FILENAME = null;

	private TransformGroup point; // Extrémité du pencil

	public Point3d getDrawingPoint() {
		// Calculer ses coordonées dans le repère du robot
		Vector3f vector = Utils3D.getGlobalCoordinates(point);
		return new Point3d((Tuple3f)vector);
	}

	///////////////////////////////////////////////////
	// Constructeur
	///////////////////////////////////////////////////

	Pencil(RobotCoreTech robot) {
		super(robot, IDENT, FILENAME);
		setCollidable(false); // Seul l'axe est collidable

		// Dessin du pencil
		Cylinder cylinder = new Cylinder(0.8f, 8, Constants.STEEL);
		Sphere sphere = new Sphere(5, Sphere.GENERATE_NORMALS, 120, Constants.STEEL);
		loadedBG = new BranchGroup();
		loadedBG.addChild(sphere);
		loadedBG.addChild(Utils3D.translate(cylinder, 0, 9, 0)); // 9 = (rayon sphère) + (longueur cylindre) / 2
		loadedBG.setCapability(BranchGroup.ALLOW_DETACH);
		loadedBG.setCollidable(false);
		Utils3D.recursiveSetUserData(loadedBG, ident);
		root.addChild(loadedBG);

		// Axe (capteur de contact)
		Shape3D axe = Utils3D.createLine3D(new Point3d(0, 8, 0), new Point3d(0, 13, 0), Constants.REDPOLYGON);
		addCollidableShape(this, axe, true); // True = mode capteur
		root.addChild(axe);

		// Extrémité non visible
		point = new TransformGroup();
		root.addChild(Utils3D.translate(point, 0, 13, 0)); // 13 = (rayon sphère) + (longueur cylindre)
	}

	///////////////////////////////////////////////////
	// Transformation initiale
	///////////////////////////////////////////////////

	protected Transform3D getT3DInit() {
		Transform3D t3D = new Transform3D();
		t3D.set(new Vector3f(0, 12, 0));
		return t3D;
	}

	///////////////////////////////////////////////////
	// Rotation de l'élément
	///////////////////////////////////////////////////

	public void rotate(float delta) {}
	public float getRotation() { return 0; }
	public void setRotation(float alpha) {}
	public void reset() {}

	///////////////////////////////////////////////////
	// Instruction getContactValue
	///////////////////////////////////////////////////

	public String getContactValue() {
		return (collidedObjectIdent == null) ? "" : "1";
	}
}
