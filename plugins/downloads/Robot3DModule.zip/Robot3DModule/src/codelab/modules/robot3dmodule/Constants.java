package codelab.modules.robot3dmodule;

import java.awt.Dimension;
import java.awt.Toolkit;

import org.jogamp.java3d.Appearance;
import org.jogamp.java3d.BoundingSphere;
import org.jogamp.java3d.ColoringAttributes;
import org.jogamp.java3d.PointAttributes;
import org.jogamp.java3d.PolygonAttributes;
import org.jogamp.java3d.RenderingAttributes;
import org.jogamp.vecmath.Color3f;
import org.jogamp.vecmath.Point3d;

public class Constants {

	public static final Color3f COLOR_RED = new Color3f(1,0,0);
	public static final Color3f COLOR_BLUE = new Color3f(0,0,1);
	public static final Color3f COLOR_GREEN = new Color3f(0,1,0);
	public static final Color3f COLOR_BLACK = new Color3f(0,0,0);
	public static final Color3f COLOR_WHITE = new Color3f(1,1,1);

	public static Appearance RED = Utils3D.createAppearance(255, 0, 0);
	public static Appearance BLUE = Utils3D.createAppearance(0, 0, 255);
	public static Appearance GREEN = Utils3D.createAppearance(0, 255, 0);
	public static Appearance STEEL = Utils3D.createAppearance(170, 170, 170);

	public static Appearance REDPOLYGON;

	public static boolean HD;

	// Définition de la zone de visibilité
	public final static BoundingSphere BOUNDS =
		new BoundingSphere(new Point3d(0, 0, 0), Double.MAX_VALUE);

	///////////////////////////////////////////////////
	// Définition des constantes-objets
	///////////////////////////////////////////////////

	// https://books.google.fr/books?id=QEoOBwAAQBAJ&pg=PA44&lpg=PA44&dq=java3D+Appearance+edges&source=bl&ots=p3KKt2kwGs&sig=ACfU3U3eGvDx6bxqRR8m-UznmzaVuj9KQw&hl=fr&sa=X&ved=2ahUKEwjlkuCXp47qAhUuyIUKHWMoDQwQ6AEwA3oECAgQAQ#v=onepage&q=java3D%20Appearance%20edges&f=false

	public static void init() {

		// Définition de l'aspect polygone rouge
		PointAttributes ptattr = new PointAttributes();
		PolygonAttributes polattr = new PolygonAttributes();
		ColoringAttributes colattr = new ColoringAttributes();
		RenderingAttributes rendattr = new RenderingAttributes();
		// polattr.setPolygonMode(PolygonAttributes.POLYGON_FILL);
		polattr.setPolygonMode(PolygonAttributes.POLYGON_LINE);
		// polattr.setCullFace(PolygonAttributes.CULL_NONE);
		ptattr.setPointSize(2.0f);
		ptattr.setPointAntialiasingEnable(true); // Point rond (et pas carré)
		colattr.setColor(COLOR_RED);
		rendattr.setVisible(false);
		rendattr.setCapability(RenderingAttributes.ALLOW_VISIBLE_WRITE);
		REDPOLYGON = new Appearance();
		REDPOLYGON.setPointAttributes(ptattr);
		REDPOLYGON.setPolygonAttributes(polattr);
		REDPOLYGON.setColoringAttributes(colattr);
		REDPOLYGON.setRenderingAttributes(rendattr);

		// Déterminer la résolution de l'écran
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		HD = (screenSize.getWidth() > 1000) ? true : false;
	}
}
