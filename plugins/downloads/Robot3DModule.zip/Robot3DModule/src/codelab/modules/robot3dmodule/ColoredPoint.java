package codelab.modules.robot3dmodule;

import org.jogamp.java3d.Appearance;
import org.jogamp.java3d.BranchGroup;
import org.jogamp.java3d.GeometryArray;
import org.jogamp.java3d.PointArray;
import org.jogamp.java3d.PointAttributes;
import org.jogamp.java3d.Shape3D;
import org.jogamp.vecmath.Point3d;

/**
*	Classe des points colorés
*	@author Jérôme Lehuen
*	@version 27/01/21
*/

public class ColoredPoint extends BranchGroup {

	///////////////////////////////////////////////////
	// Constructeur
	///////////////////////////////////////////////////

	public ColoredPoint(Point3d coords, float radius, int r, int g, int b) {
		PointArray array = new PointArray(1, GeometryArray.COORDINATES);
		array.setCoordinate(0, coords);
		PointAttributes attr = new PointAttributes();
		attr.setPointSize(radius);
		attr.setPointAntialiasingEnable(true); // Point rond (et pas carré)
		Appearance appearance = Utils3D.createAppearance(r, g, b);
		appearance.setPointAttributes(attr);
		addChild(new Shape3D(array, appearance));
	}
}
