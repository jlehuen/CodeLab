package codelab.modules.robot3dmodule;

import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;

/**
*	Classe du gestionnaire d'évènements-clavier
*	@author Jérôme Lehuen
*	@version 10/12/22
*/

public class KeyEventManager implements KeyListener {

	// Les touches avec flêche ont une répétition automatique
	private boolean VK_LEFT = false;
	private boolean VK_RIGHT = false;
	private boolean VK_UP = false;
	private boolean VK_DOWN = false;
	private boolean VK_SPACE = false;

	private Simulator3D simulator;
	private AbstractRobot3D robot;

	///////////////////////////////////////////////////
	// Constructeur
	///////////////////////////////////////////////////

	public KeyEventManager(Simulator3D simulator) {
		this.simulator = simulator;
		robot = simulator.getRobot();
	}

	///////////////////////////////////////////////////
	// Méthodes de l'interface KeyListener
	///////////////////////////////////////////////////

	public void keyTyped(KeyEvent e) {}

	public void keyPressed(KeyEvent e) {
		if (simulator.module.codelab.isRunning()) return; // Interdit en cours d'exécution
		if (!simulator.isRunning()) simulator.start();
		switch (e.getKeyCode()) {
			case KeyEvent.VK_LEFT:    if (!VK_LEFT)  { VK_LEFT = true;  robot.motorOn(0, 1); } break;
			case KeyEvent.VK_RIGHT:   if (!VK_RIGHT) { VK_RIGHT = true; robot.motorOn(0, -1); } break;
			case KeyEvent.VK_UP:      if (!VK_UP)    { VK_UP = true;    robot.motorOn(1, -0.25f); } break;
			case KeyEvent.VK_DOWN:    if (!VK_DOWN)  { VK_DOWN = true;  robot.motorOn(1, 0.25f); } break;
			case KeyEvent.VK_SPACE:   if (!VK_SPACE) { VK_SPACE = true; robot.grab(); } break;
			case KeyEvent.VK_NUMPAD1: robot.motorOn(2, 0.25f); break;
			case KeyEvent.VK_NUMPAD4: robot.motorOn(2, -0.25f); break;
			case KeyEvent.VK_NUMPAD2: robot.motorOn(3, 0.25f); break;
			case KeyEvent.VK_NUMPAD5: robot.motorOn(3, -0.25f); break;
			case KeyEvent.VK_NUMPAD3: robot.motorOn(4, 2); break;
			case KeyEvent.VK_NUMPAD6: robot.motorOn(4, -2); break;
		}
	}

	public void keyReleased(KeyEvent e) {
		if (simulator.module.codelab.isRunning()) return; // Interdit en cours d'exécution
		switch (e.getKeyCode()) {
			case KeyEvent.VK_LEFT:    VK_LEFT = false;  robot.motorOff(0); break;
			case KeyEvent.VK_RIGHT:   VK_RIGHT = false; robot.motorOff(0); break;
			case KeyEvent.VK_UP:      VK_UP = false;    robot.motorOff(1); break;
			case KeyEvent.VK_DOWN:    VK_DOWN = false;  robot.motorOff(1); break;
			case KeyEvent.VK_SPACE:   VK_SPACE = false; robot.drop(); break;
			case KeyEvent.VK_NUMPAD1: robot.motorOff(2); break;
			case KeyEvent.VK_NUMPAD4: robot.motorOff(2); break;
			case KeyEvent.VK_NUMPAD2: robot.motorOff(3); break;
			case KeyEvent.VK_NUMPAD5: robot.motorOff(3); break;
			case KeyEvent.VK_NUMPAD3: robot.motorOff(4); break;
			case KeyEvent.VK_NUMPAD6: robot.motorOff(4); break;
		}
		if (robot.allMotorsStopped()) simulator.stop(); // Stopper le thread du simulateur
	}
}
