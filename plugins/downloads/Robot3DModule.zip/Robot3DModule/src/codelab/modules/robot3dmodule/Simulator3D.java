package codelab.modules.robot3dmodule;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import org.jogamp.java3d.Canvas3D;
import org.jogamp.java3d.Transform3D;
import org.jogamp.java3d.TransformGroup;
import org.jogamp.java3d.utils.universe.SimpleUniverse;
import org.jogamp.java3d.utils.universe.ViewingPlatform;
import org.jogamp.vecmath.Point3d;
import org.jogamp.vecmath.Vector3d;

import codelab.modules.robot3dmodule.coretech.RobotCoreTech;

/**
*	Classe du simulateur robotique 3D
*	@author Jérôme Lehuen
*	@version 09/04/23
*/

public class Simulator3D extends JPanel implements Runnable, MouseListener, MouseMotionListener, MouseWheelListener {

	private static final long serialVersionUID = 1L;

	public boolean collisionFlag = false;
	public Robot3DModule module;

	private AbstractRobot3D robot;
	private SimpleUniverse universe;
	private Canvas3D canvas;

	public AbstractRobot3D getRobot() {
		// Utilisé par le handleRequest
		return robot;
	}

	public void printToConsole(String str, Color color) {
		module.printToConsole(str, color);
	}

	///////////////////////////////////////////////////
	// Constructeur
	///////////////////////////////////////////////////

	public Simulator3D(Robot3DModule module) {
		this.module = module;
		Constants.init();

		// Dans cet ordre
		canvas = Utils3D.createCanvas3D();
		universe = new SimpleUniverse(canvas);
		//View view = universe.getViewer().getView();
        //view.setSceneAntialiasingEnable(true);
		robot = new RobotCoreTech(this);
		universe.addBranchGraph(robot);
		resetViewerPosition();

		// Placement du Canvas3D
		setLayout(new BorderLayout());
		add(canvas, BorderLayout.CENTER);
		setMinimumSize(new Dimension(0,0));
		setMaximumSize(new Dimension(0,0));

		// Ajout des listeners
		addMouseWheelListener(this);
		canvas.addMouseListener(this);
		canvas.addMouseMotionListener(this);
		canvas.addKeyListener(new KeyEventManager(this));
	}

	///////////////////////////////////////////////////
	// Calcul du point de vue
	///////////////////////////////////////////////////

	private double theta; // Modifié dans mouseDragged
	private double rayon; // Modifié dans mouseWheelMoved
	private double elevation; // Modifié dans mouseDragged
	private Point3d pos; // Point de vue du spectateur
	private Point3d dir; // Direction du regard

	private void updateViewerPosition() {
		double x = rayon * Math.cos(theta);
		double z = rayon * Math.sin(theta);
		pos = new Point3d(x, elevation, z);
		ViewingPlatform vp = universe.getViewingPlatform();
		TransformGroup steerTG = vp.getViewPlatformTransform();
		Transform3D t3d = new Transform3D();
		steerTG.getTransform(t3d);
		t3d.lookAt(pos, dir, new Vector3d(0,1,0));
		t3d.invert();
		steerTG.setTransform(t3d);
		robot.updateDashboard(); // Actualisation de la table
	}

	private void resetViewerPosition() {
		theta = Math.toRadians(robot.VIEWER_THETA);
		rayon = robot.VIEWER_DISTANCE;
		elevation = robot.VIEWER_ELEVATION;
		dir = robot.VIEWER_DIRECTION;
		updateViewerPosition();
	}

	public double getTheta() { return Math.toDegrees(theta); }
	public double getRayon() { return rayon; }
	public double getElevation() { return elevation; }

	///////////////////////////////////////////////////
	// Pour activer ou désactiver le mode DEBUG
	///////////////////////////////////////////////////

	public boolean DEBUG = false;

	public void debug_on() {
		if (DEBUG) return;
		robot.debug_on();
		Constants.REDPOLYGON.getRenderingAttributes().setVisible(true);
		DEBUG = true;
	}

	public void debug_off() {
		if (!DEBUG) return;
		robot.debug_off();
		Constants.REDPOLYGON.getRenderingAttributes().setVisible(false);
		DEBUG = false;
	}

	///////////////////////////////////////////////////////////
	// Méthodes de l'interface MouseWheelListener
	///////////////////////////////////////////////////////////

	public void mouseWheelMoved(MouseWheelEvent e) {
		int pas = e.getWheelRotation();
		double dz = (float) pas / 10;
		rayon += dz;
		if (rayon > 20) rayon = 20;
		if (rayon < 0.1) rayon = 0.1;
		updateViewerPosition();
	}

	///////////////////////////////////////////////////////////
	// Méthodes de l'interface MouseListener
	///////////////////////////////////////////////////////////

	private Point origin = new Point(0, 0);

	public void mousePressed(MouseEvent e) {
		if (SwingUtilities.isLeftMouseButton(e)) {
			origin = new Point(e.getX(), e.getY());
		}
	}

	public void mouseClicked(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}

	///////////////////////////////////////////////////////////
	// Méthodes de l'interface MouseMotionListener
	///////////////////////////////////////////////////////////

	public void mouseDragged(MouseEvent e) {
		if (SwingUtilities.isLeftMouseButton(e)) {
			double dx = (e.getX() - origin.x);
			double dy = (e.getY() - origin.y);
			origin = new Point(e.getX(), e.getY());
			theta += dx / 100;
			elevation += dy / 100;
			if (elevation > 20) elevation = 20;
			if (elevation < -20) elevation = -20;
			updateViewerPosition();
		}
	}

	public void mouseMoved(MouseEvent e) {}

	///////////////////////////////////////////////////
	// Méthode de l'interface Runnable
	///////////////////////////////////////////////////

	private Thread simuthread = null;
	private boolean isrunning = false;

	public boolean isRunning() {
		return isrunning;
	}

	public void run() {
		while (isrunning) {
			robot.update();
			robot.updateDashboard(); // Actualisation de la table
			Utils3D.wait(10);
		}
		robot.stopAllMotors(); // Stopper tous les moteurs
		robot.removeAllThreads(); // Arrêter tous les threads
		robot.drawOff(); // Lever le crayon (si besoin)
		robot.updateDashboard(); // Actualisation de la table
	}

	public void start() {
		if (isrunning) return;
		isrunning = true;
		simuthread = new Thread(this);
		simuthread.start();
	}

	public void stop() {
		if (!isrunning) return;
		try {
			isrunning = false;
			simuthread.join();
			simuthread = null;
		}
		catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void reset() {
		this.stop();
		robot.reset();
		resetViewerPosition();
		debug_off();
	}
}
 