package codelab.modules.robot3dmodule;

import java.awt.Color;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Hashtable;

import org.jogamp.java3d.Appearance;
import org.jogamp.java3d.Background;
import org.jogamp.java3d.BranchGroup;
import org.jogamp.java3d.DirectionalLight;
import org.jogamp.java3d.GeometryArray;
import org.jogamp.java3d.Group;
import org.jogamp.java3d.LineAttributes;
import org.jogamp.java3d.PointArray;
import org.jogamp.java3d.RenderingAttributes;
import org.jogamp.java3d.Shape3D;
import org.jogamp.java3d.Texture2D;
import org.jogamp.java3d.utils.geometry.Sphere;
import org.jogamp.vecmath.Point3d;
import org.jogamp.vecmath.Point3f;
import org.jogamp.vecmath.Vector3f;

import codelab.DataTable;
import codelab.DataTableInterface;

/*
import codelab.CodeLab;
import codelab.DataTableInterface;
import codelab.PropertyBase;
import codelab.console.Console;
import codelab.utils.Utils;
*/

/**
*	Classe abstraite des robots 3D
*	@author Jérôme Lehuen
*	@version 09/04/23
*/

public abstract class AbstractRobot3D extends BranchGroup implements DataTableInterface {

	public Simulator3D simulator;

	private ArrayList<Motor> motors; // Liste des moteurs à actualiser
	private ArrayList<AbstractRobotPart> parts; // Liste des parties du robot
	private ArrayList<CollisionDetector> detectors; // Liste des détecteurs de collision
	private Hashtable<String, AbstractObject3D> objects; // Table des objets déplacables
	private ArrayList<BranchGroup> lines; // Liste des tracés

	protected Appearance app_sol = new Appearance();
	protected Appearance app_murs = new Appearance();
	protected Appearance app_plafond = new Appearance();
	private RenderingAttributes rendattr = new RenderingAttributes();

	protected boolean detectCollisions = false;

	public double VIEWER_THETA;
	public double VIEWER_DISTANCE;
	public double VIEWER_ELEVATION;
	public Point3d VIEWER_DIRECTION;

	protected void runtimeError(String msg) {
		simulator.printToConsole(msg, Color.RED);
		Robot3DModule.INSTANCE.codelab.halt();
		Utils3D.beep();
	}
	
	private String LABEL(String id) {
		return Robot3DModule.INSTANCE.LABEL(id);
	}
	
	///////////////////////////////////////////////////
	// Constructeur
	///////////////////////////////////////////////////

	public AbstractRobot3D(Simulator3D simulator) {
		this.simulator = simulator;
		// Autoriser les modifications de structure
		setCapability(BranchGroup.ALLOW_CHILDREN_READ);
		setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);
		setCapability(Group.ALLOW_CHILDREN_EXTEND);
		// Autoriser les modifications de visibilité
		rendattr.setCapability(RenderingAttributes.ALLOW_VISIBLE_WRITE);

		app_sol.setRenderingAttributes(rendattr);
		app_murs.setRenderingAttributes(rendattr);
		app_plafond.setRenderingAttributes(rendattr);

		parts = new ArrayList<AbstractRobotPart>();
		motors = new ArrayList<Motor>();
		lines = new ArrayList<BranchGroup>();
		objects = new Hashtable<String, AbstractObject3D>();
		detectors = new ArrayList<CollisionDetector>();
	}
	
	///////////////////////////////////////////////////
	// Gestion du Dashboard
	///////////////////////////////////////////////////

	private DataTable dashboard;

	public void setDashboard(DataTable dashboard) {
		this.dashboard = dashboard;
	}

	public void updateDashboard() {
		updateValues(); // Actualisation des propriétés pour le dashboard
		if (dashboard != null) dashboard.update(); // Actualisation du dashboard
	}

	///////////////////////////////////////////////////
	// Méthodes de construction de la scène
	///////////////////////////////////////////////////

	protected void addRobot(AbstractRobotPart base) {
		addChild(base.getRoot());
	}

	protected void addBackground(Background background) {
		background.setApplicationBounds(Constants.BOUNDS);
		addChild(background);
	}

	protected void addBackground(String filename) {
		Texture2D texture = Utils3D.loadTexture(filename);
		Sphere sphere = new Sphere(1.0f, Sphere.GENERATE_NORMALS_INWARD | Sphere.GENERATE_TEXTURE_COORDS, 8);
		Appearance appearance = sphere.getAppearance();
		appearance.setTexture(texture);
		BranchGroup group = new BranchGroup();
		group.addChild(sphere);
		Background bg = new Background();
		bg.setApplicationBounds(Constants.BOUNDS);
		bg.setGeometry(group);
		addChild(bg);
	}

	protected void addSceneBox(double hauteur_plancher, double hauteur_plafond, double longueur_murs) {
		Point3d p1 = new Point3d(-longueur_murs/2, hauteur_plancher, longueur_murs/2);
		Point3d p2 = new Point3d(longueur_murs/2, hauteur_plancher, longueur_murs/2);
		Point3d p3 = new Point3d(longueur_murs/2, hauteur_plancher, -longueur_murs/2);
		Point3d p4 = new Point3d(-longueur_murs/2, hauteur_plancher, -longueur_murs/2);
		Point3d p5 = new Point3d(-longueur_murs/2, hauteur_plafond, longueur_murs/2);
		Point3d p6 = new Point3d(longueur_murs/2, hauteur_plafond, longueur_murs/2);
		Point3d p7 = new Point3d(longueur_murs/2, hauteur_plafond, -longueur_murs/2);
		Point3d p8 = new Point3d(-longueur_murs/2, hauteur_plafond, -longueur_murs/2);
		addChild(new Plan3D(p2, p3, p4, p1, app_sol, "the floor")); // Id en cas de collision
		addChild(new Plan3D(p4, p3, p7, p8, app_murs)); // Mur avant
		addChild(new Plan3D(p3, p2, p6, p7, app_murs)); // Mur droit
		addChild(new Plan3D(p2, p1, p5, p6, app_murs)); // Mur arrière
		addChild(new Plan3D(p1, p4, p8, p5, app_murs)); // Mur gauche
		addChild(new Plan3D(p5, p8, p7, p6, app_plafond));
	}

	public void setSceneBoxVisible(boolean visible) {
		rendattr.setVisible(visible);
	}

	public void addObject(AbstractObject3D object, Vector3f translation, float scale) {
		objects.put(object.getUID(), object); // Ajouter à la table
		object.positionne(translation, scale); // Appliquer la transfotmation
		addChild(object); // Ajouter à la scène
	}

	protected void drawPoint(Point3d coords, int color_r, int color_g, int color_b) {
		ColoredPoint point = new ColoredPoint(coords, 0.5f, color_r, color_g, color_b);
		BranchGroup bg = new BranchGroup();
		bg.setCapability(BranchGroup.ALLOW_DETACH);
		bg.addChild(point);
		lines.add(bg); // Ajouter à la liste
		addChild(bg); // Ajouter à la scène
	}

	protected void drawLine(Point3d p1, Point3d p2, Appearance color) {
		Shape3D line = Utils3D.createLine3D(p1, p2, color);
		BranchGroup bg = new BranchGroup();
		bg.setCapability(BranchGroup.ALLOW_DETACH);
		bg.addChild(line);
		lines.add(bg); // Ajouter à la liste
		addChild(bg); // Ajouter à la scène
	}

	protected void addLight(DirectionalLight light) {
		light.setInfluencingBounds(Constants.BOUNDS);
		addChild(light);
	}

	protected void addPart(AbstractRobotPart part) {
		parts.add(part);
	}

	protected void addMotor(Motor motor) {
		motors.add(motor);
	}

	protected void drawAxis() {
		// Epaisseur du trait
		LineAttributes la = new LineAttributes();
		la.setCapability(LineAttributes.ALLOW_WIDTH_WRITE);
		la.setLineWidth(Constants.HD ? 2 : 1);
		Constants.REDPOLYGON.setLineAttributes(la);

		addChild(Utils3D.createLine3D(new Point3d(0, 0, 0), new Point3d(10, 0, 0), Constants.REDPOLYGON));
		addChild(Utils3D.createLine3D(new Point3d(0, 0, 0), new Point3d(0, 10, 0), Constants.REDPOLYGON));
		addChild(Utils3D.createLine3D(new Point3d(0, 0, 0), new Point3d(0, 0, 10), Constants.REDPOLYGON));
		//addChild(Utils3D.createText2D("X", Simulator3D.RED, 18, 1.0f, 0.0f, 0.0f));
		//addChild(Utils3D.createText2D("Z", Simulator3D.RED, 18, 0.0f, 0.0f, 1.0f));
		int nbPts = 0;
		PointArray pa = new PointArray(21*21+1, GeometryArray.COORDINATES);
		for (int x = -10; x <= 10; x++)
			for (int z = -10; z <= 10; z++)
				pa.setCoordinate(nbPts++, new Point3f(x, 0, z));
		addChild(new Shape3D(pa, Constants.REDPOLYGON));
	}

	protected boolean errorRGB(int r, int g, int b) {
		String msg;
		if ((r < 0) || (r > 255)) {
			msg = String.format(LABEL("COLOR_ERROR"), "R");
			simulator.printToConsole(msg, Color.RED);
			emergencyStop();
			return true;
		}
		if ((g < 0) || (g > 255)) {
			msg = String.format(LABEL("COLOR_ERROR"), "G");
			simulator.printToConsole(msg, Color.RED);
			emergencyStop();
			return true;
		}
		if ((b < 0) || (b > 255)) {
			msg = String.format(LABEL("COLOR_ERROR"), "B");
			simulator.printToConsole(msg, Color.RED);
			emergencyStop();
			return true;
		}
		return false;
	}

	///////////////////////////////////////////////////
	// Autres méthodes publiques
	///////////////////////////////////////////////////

	public void addCollisionDetector(AbstractRobotPart part, Shape3D shape, boolean sensor) {
		CollisionDetector detector = new CollisionDetector(this, part, shape, sensor, Constants.BOUNDS);
		detectors.add(detector);
		addChild(detector);
	}

	public AbstractObject3D findObject(String uid) {
		return objects.get(uid);
	}

	public void debug_on() {
		for (AbstractRobotPart part : parts) part.debug_on();
		setSceneBoxVisible(false);
	}

	public void debug_off() {
		for (AbstractRobotPart part : parts) part.debug_off();
		setSceneBoxVisible(true);
	}

	public void reset() {
		try {
			for (AbstractRobotPart part : parts) part.reset(); // On réinitialise le robot
			threads = new ArrayList<Thread>(); // On supprime les threads en attente
			removeObjects(); // On supprime les objets
			clearScreen(); // On efface les tracés
			drawOff(); // On lève le crayon
		}
		catch (ConcurrentModificationException e) {
			// Peut arriver si la scène est modifiée en même temps
		}
	}

	public void emergencyStop() {
		simulator.module.stop();
	}

	///////////////////////////////////////////////////
	// Méthodes protégées
	///////////////////////////////////////////////////

	protected void removeLines() {
		for (BranchGroup line : lines) line.detach();
		lines = new ArrayList<BranchGroup>();
	}

	protected void removeObjects() {
		for (String uid : objects.keySet()) objects.get(uid).detach();
		objects = new Hashtable<String, AbstractObject3D>();
	}

	///////////////////////////////////////////////////
	// Contrôle des moteurs
	///////////////////////////////////////////////////

	public void update() {
		for (Motor motor : motors) motor.update();
	}

	public void stopAllMotors() {
		for (Motor motor : motors) motor.stop();
	}

	public boolean allMotorsStopped() {
		for (Motor motor : motors)
			if (!motor.isStopped()) return false;
		return true;
	}

	///////////////////////////////////////////////////
	// Méthodes invoquées par le serveur
	///////////////////////////////////////////////////

	// Méthodes spécifiques à une sous-classe de robots

	public int plot() { return 0; }
	public int grab() { return 0; }
	public int drop() { return 0; }
	public int drawOn() { return 0; }
	public int drawOff() { return 0; }
	public int setColor(int r, int g, int b) { return 0; }
	public int clearScreen() { return 0; }
	public String putBall(float x, float y, float z, int r, int g, int b, String descr) { return ""; }
	public float getX() { return 0; }
	public float getY() { return 0; }
	public float getZ() { return 0; }
	public String getPencilPosition() { return ""; }
	public String getSensorValue(int sensor) { return ""; }

	// Méthodes valables pour tous les robots

	public String getObjectPosition(String uid) {
		// Retourne les coordonées d'un objet de la scène au format "x:y:z"
		if (!objects.containsKey(uid)) return "ERROR";
		AbstractObject3D object = objects.get(uid);
		Vector3f vector = object.getGlobalCoordinates();
		return String.format("%f:%f:%f", vector.x, vector.y, vector.z).replace(',', '.');
	}

	public float getRotation(int motor) {
		if ((motor < 0) || (motor >= motors.size())) {
			runtimeError(String.format(LABEL("Robot3D_Error_1"), motor, motors.size()-1));
			return -1;
		}
		return motors.get(motor).getRotation();
	}

	public int setRotation(int motor, float angle) {
		if ((motor < 0) || (motor >= motors.size())) {
			runtimeError(String.format(LABEL("Robot3D_Error_1"), motor, motors.size()-1));
			return -1;
		}
		motors.get(motor).setRotation(angle);
		return 1;
	}

	public int motorStep(int motor, int steps) {
		if ((motor < 0) || (motor >= motors.size())) {
			runtimeError(String.format(LABEL("Robot3D_Error_1"), motor, motors.size()-1));
			return -1;
		}
		if ((steps < -10) || (steps > 10)) {
			runtimeError(String.format(LABEL("Robot3D_Error_2"), steps));
			return -1;
		}
		motors.get(motor).step((float)steps/10); // Projection dans l'intervalle [-1, 1]
		return 1;
	}

	public int motorOn(int motor, float speed) {
		if ((motor < 0) || (motor >= motors.size())) {
			runtimeError(String.format(LABEL("Robot3D_Error_1"), motor, motors.size()-1));
			return -1;
		}
		if (Math.abs(speed) > Motor.MAX_SPEED) {
			runtimeError(String.format(LABEL("Robot3D_Error_3"), speed, Motor.MAX_SPEED));
			return -1;
		}
		motors.get(motor).start(speed);
		return 1;
	}

	public int motorOff(int motor) {
		if ((motor < 0) || (motor >= motors.size())) {
			runtimeError(String.format(LABEL("Robot3D_Error_1"), motor, motors.size()-1));
			return -1;
		}
		motors.get(motor).stop();
		return 1;
	}

	public int motorOnMulti(float speed0, float speed1, float speed2, float speed3) {
		// Mise en route multi-moteurs (4 moteurs)
		motors.get(0).start(speed0);
		motors.get(1).start(speed1);
		motors.get(2).start(speed2);
		motors.get(3).start(speed3);
		return 1;
	}

	public int motorOffMulti(int code) {
		// Codage binaire multi-moteurs
		if ((code & 1) != 0) motors.get(0).stop();
		if ((code & 2) != 0) motors.get(1).stop();
		if ((code & 4) != 0) motors.get(2).stop();
		if ((code & 8) != 0) motors.get(3).stop();
		return 1;
	}

	// Méthodes defineThread, startAllThreads et removeAllThreads

	private ArrayList<Thread> threads = new ArrayList<Thread>();

	public int defineThread(int motor, float angle, float speed) {
		if ((motor < 0) || (motor >= motors.size())) {
			runtimeError(String.format(LABEL("Robot3D_Error_1"), motor, motors.size()-1));
			return -1;
		}
		threads.add(motors.get(motor).defineThread(angle, speed));
		return 1;
	}

	public int removeAllThreads() {
		for (Thread thread : threads) thread.interrupt();
		threads = new ArrayList<Thread>();
		return 1;
	}

	public int startAllThreads() {
		for (Thread thread : threads) thread.start();
		try {
			for (Thread thread : threads) thread.join();
		}
		catch (InterruptedException e) {
			e.printStackTrace();
		}
		threads = new ArrayList<Thread>();
		return 1;
	}

	public int clearAll() {
		removeObjects();
		clearScreen();
		return 1;
	}
}
