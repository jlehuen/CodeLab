package codelab.modules.robot3dmodule;

import java.awt.Color;

import javax.swing.ImageIcon;

import codelab.CodeLab;
import codelab.ToolButton;
import codelab.AbstractToolbar;

/**
*	Classe de la barre d'outils de l'atelier robotique 3D
*	@author Jérôme Lehuen
*	@version 09/04/23
*/

public class ToolbarSim3D extends AbstractToolbar {

	private ImageIcon icon_clear = loadImageIcon("icon_clear.png");
	private ImageIcon icon_dashboard = loadImageIcon("icon_dashboard.png");
	private ImageIcon icon_toggle_on = loadImageIcon("icon_toggle_on.png");
	private ImageIcon icon_toggle_off = loadImageIcon("icon_toggle_off.png");
	
	private Robot3DModule module;
	private ToolButton debugButton;
	private ToolButton clearButton;
	
	private String LABEL(String id) {
		return Robot3DModule.INSTANCE.LABEL(id);
	}
		
	///////////////////////////////////////////////////
	// Constructor
	///////////////////////////////////////////////////

	public ToolbarSim3D(Robot3DModule module) {
		super(module);
		this.module = (Robot3DModule) module;
		addSeparator();
		addButton("NUMPAD");
		addButton("STICK");
		addButton("CTRL");
		addSeparator();
		addButton("RESET");
		add(new ToolButton("DATA", LABEL("Btn_data"), LABEL("Btn_data_tooltip"), icon_dashboard, this));
		add(debugButton = new ToolButton("DEBUG", LABEL("Btn_wireframe"), LABEL("Btn_wireframe_tooltip"), icon_toggle_off, this));
		add(clearButton = new ToolButton("CLEAR", LABEL("Btn_clear"), LABEL("Btn_clear_tooltip"), icon_clear, this));
		endToolbar();
	}
	
	public void update() {
		super.update();
		clearButton.setEnabled(!module.codelab.isRunning());
	}

	///////////////////////////////////////////////////
	// Action handler
	///////////////////////////////////////////////////

	public void action(String ident) {
		switch (ident) {
			case "DEBUG":	action_debug(); break;
			case "CLEAR":	action_clear(); break;
			default: super.action(ident);
		}
	}
	
	private void action_debug() {
		Simulator3D simulator = module.getSimulator();
		if (simulator.DEBUG) {
			debugButton.setIcon(icon_toggle_off);
			simulator.debug_off();
		}
		else {
			debugButton.setIcon(icon_toggle_on);
			simulator.debug_on();
		}
	}
	
	private void action_clear() {
		Simulator3D simulator = module.getSimulator();
		AbstractRobot3D robot = simulator.getRobot();
		robot.clearScreen();
	}

	public void debug_off() {
		debugButton.setIcon(icon_toggle_off);
	}
}
