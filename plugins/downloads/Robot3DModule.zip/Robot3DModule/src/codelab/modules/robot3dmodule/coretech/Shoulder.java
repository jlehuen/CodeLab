package codelab.modules.robot3dmodule.coretech;

import org.jogamp.java3d.Transform3D;
import org.jogamp.vecmath.Point3d;
import org.jogamp.vecmath.Vector3f;

import codelab.modules.robot3dmodule.AbstractRobotPart;
import codelab.modules.robot3dmodule.Constants;
import codelab.modules.robot3dmodule.Utils3D;

/**
*	Classe de l'épaule du robot CoreTech
*	@author Jérôme Lehuen
*	@version 10/07/22
*/

public class Shoulder extends AbstractRobotPart {

	private static final String IDENT = "the shoulder";
	private static final String FILENAME = "coretech/shoulder.obj";

	private final float ALPHA = 90; // Position initiale

	///////////////////////////////////////////////////
	// Constructeur
	///////////////////////////////////////////////////

	Shoulder(RobotCoreTech robot) {
		super(robot, IDENT, FILENAME);
		Utils3D.changeAppearance(loadedBG, 230, 115, 50);
		setCollidable(true);
		circular = true; // Passage possible par le 360

		// Création et ajout du modèle filaire
		//addTransformedPrimitive(
		//	new Cylinder(17, 4, Simulator3D.REDPOLYGON),
		//	new Vector3f(0, -2, 0));
		//addTransformedPrimitive(
		//	new Box(8, 6, 12, Simulator3D.REDPOLYGON),
		//	new Vector3f(0, 6, -3));

		root.addChild(Utils3D.createLine3D(new Point3d(0, 0, 0), new Point3d(0, 25, 0), Constants.REDPOLYGON));
		update();
	}

	///////////////////////////////////////////////////
	// Transformation initiale
	///////////////////////////////////////////////////

	protected Transform3D getT3DInit() {
		Transform3D t3D = new Transform3D();
		t3D.set(new Vector3f(0, 4, 0));
		return t3D;
	}

	///////////////////////////////////////////////////
	// Rotation de l'élément
	///////////////////////////////////////////////////

	private float alpha = ALPHA;

	public float getRotation() { return alpha; }

	public void setRotation(float alpha) {
		this.alpha = alpha;
		update();
	}

	public void rotate(float delta) {
		alpha += delta;
		if (alpha > 360) { alpha -= 360; flag360 = true; }
		if (alpha < 0) { alpha += 360; flag360 = true; }
		update();
	}

	public void reset() {
		alpha = ALPHA;
		update();
	}

	///////////////////////////////////////////////////
	// Actualisation
	///////////////////////////////////////////////////

	private void update() {
		Transform3D t3D = getT3DInit();
		Transform3D rotate = new Transform3D();
		rotate.rotY(Math.toRadians(alpha));
		t3D.mul(rotate);
		root.setTransform(t3D);
	}
}
