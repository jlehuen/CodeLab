package codelab.modules.robot3dmodule;

import java.awt.Color;
import java.util.Iterator;

import org.jogamp.java3d.Behavior;
import org.jogamp.java3d.Bounds;
import org.jogamp.java3d.Node;
import org.jogamp.java3d.WakeupCriterion;
import org.jogamp.java3d.WakeupOnCollisionEntry;
import org.jogamp.java3d.WakeupOnCollisionExit;

/*
import codelab.CodeLab;
import codelab.console.Console;
import codelab.utils.Utils;
*/

/**
*	Classe du collisionneur
*	@author Jérôme Lehuen
*	@version 09/04/23
*/

public class CollisionDetector extends Behavior {

	private Node node;
	private String uid1;
	private AbstractRobot3D robot;
	private AbstractRobotPart part;
	private WakeupOnCollisionEntry collisionEntry;
	private WakeupOnCollisionExit collisionExit;
	private boolean collision = false;
	private boolean sensor; // Mode capteur

	///////////////////////////////////////////////////
	// Constructeur et initialiseur
	///////////////////////////////////////////////////

	public CollisionDetector(AbstractRobot3D robot, AbstractRobotPart part, Node node, boolean sensor, Bounds bounds) {
		this.robot = robot;
		this.part = part;
		this.node = node;
		this.sensor = sensor;
		uid1 = (String) node.getUserData();
		setSchedulingBounds(bounds);
	}

	public void initialize() {
		// Ne pas invoquer cette méthode
		collisionEntry = new WakeupOnCollisionEntry(node, WakeupOnCollisionEntry.USE_GEOMETRY);
		collisionExit = new WakeupOnCollisionExit(node, WakeupOnCollisionExit.USE_GEOMETRY);
		wakeupOn(collisionEntry);
	}

	///////////////////////////////////////////////////
	// Méthode invoquée en cas de stimulus
	///////////////////////////////////////////////////

	public void processStimulus(Iterator<WakeupCriterion> criteria) {
		if (!robot.detectCollisions) return; // Pas de détection
		collision = !collision;
		if (collision) {
			Node other = collisionEntry.getTriggeringPath().getObject();
			String uid2 = (String) other.getUserData();
			collisionOn(uid2);
			wakeupOn(collisionExit);
		} else {
			Node other = collisionEntry.getTriggeringPath().getObject();
			String ident2 = (String) other.getUserData();
			collisionOff(ident2);
			wakeupOn(collisionEntry);
		}
	}

	private void collisionOn(String uid2) {
		String msg = String.format("INFO: %s collided %s\n", uid1, uid2);
		robot.simulator.printToConsole(msg, Color.ORANGE);
		part.collidedObjectIdent = uid2;
		part.collidedObject = robot.findObject(uid2);

		if (sensor) {
			// Rien à faire
		}
		else {
			// On arrête tout
			robot.stopAllMotors();
			robot.simulator.collisionFlag = true;
			robot.simulator.module.codelab.halt();
			robot.simulator.printToConsole("ALERT: Collision!\n", Color.RED);
			Robot3DModule.playAudio("stop_alert.wav");
		}
	}

	private void collisionOff(String uid2) {
		//String msg = String.format("INFO: %s exited %s\n", uid1, uid2);
		//robot.simulator.printToConsole(msg, Console.ORANGE);
		robot.simulator.collisionFlag = false;
		part.collidedObjectIdent = null;
		part.collidedObject = null;
	}
}
