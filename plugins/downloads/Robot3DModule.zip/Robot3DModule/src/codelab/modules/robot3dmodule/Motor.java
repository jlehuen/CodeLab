package codelab.modules.robot3dmodule;

/**
*	Classe des moteurs des robots 3D
*	@author Jérôme Lehuen
*	@version 15/03/23
*/

public class Motor implements Runnable {

	public static final int MAX_SPEED = 2;

	private AbstractRobotPart part;
	private float speed = 0;

	///////////////////////////////////////////////////
	// Constructeur
	///////////////////////////////////////////////////

	public Motor(AbstractRobotPart part) {
		this.part = part;
		part.setMotor(this);
	}

	private boolean isRunning() {
		return Robot3DModule.INSTANCE.codelab.isRunning();
	}

	///////////////////////////////////////////////////
	// Actualisation du moteur
	///////////////////////////////////////////////////

	public void update() {
		part.rotate(speed);
	}

	///////////////////////////////////////////////////
	// Commandes du moteur
	///////////////////////////////////////////////////

	public void start(float speed) {
		this.speed = speed;
		part.flag360 = false; // Passage par le 360
	}

	public void stop() {
		speed = 0;
	}

	public float getSpeed() {
		return speed;
	}

	public boolean isStopped() {
		return (speed == 0);
	}

	public float getRotation() {
		return part.getRotation();
	}

	public void setRotation(float angle) {
		part.setRotation(angle);
	}

	public void step(float step) {
		part.rotate(step);
	}

	public Thread defineThread(float cible, float speed) {
		this.cible_arg = cible;
		this.speed_arg = speed;
		return new Thread(this);
	}

	///////////////////////////////////////////////////
	// Méthode de Runnable
	///////////////////////////////////////////////////

	private float cible_arg;
	private float speed_arg;

	public void run() {

		// Adapter le sens de rotation
		speed_arg = Math.abs(speed_arg);
		float delta = cible_arg - getRotation();
		if (delta < 0) speed_arg = -speed_arg;
		if (part.circular && Math.abs(delta) > 180) {
			speed_arg = -speed_arg; // Sens optimisé
		}

		start(speed_arg); // Lancer le moteur

		if (speed_arg > 0) {
			// Sens trigo
			if (part.circular && cible_arg < getRotation())
				while (isRunning() && !part.flag360) sleep(); // Passage par le 360
			while (isRunning() && getRotation() < cible_arg) sleep();
		}
		else if (speed_arg < 0) {
			// Sens anti-trigo
			if (part.circular && cible_arg == 0) // Cas du zéro
				while (isRunning() && !part.flag360) sleep(); // Passage par le 360
			else {
				if (part.circular && cible_arg > getRotation())
					while (isRunning() && !part.flag360) sleep(); // Passage par le 360
				while (isRunning() && getRotation() > cible_arg) sleep();
			}
		}
		stop(); // Arrêter le moteur

		// Imposer la position finale en fin de mouvement
		if (isRunning()) setRotation(cible_arg);
	}

	private void sleep() {
		try { Thread.sleep(1); }
		catch (InterruptedException e) {}
	}
}
