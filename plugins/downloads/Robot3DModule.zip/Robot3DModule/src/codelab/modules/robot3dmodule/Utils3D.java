package codelab.modules.robot3dmodule;

import java.awt.Font;
import java.awt.Toolkit;
import java.awt.GraphicsConfigTemplate;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;

import javax.imageio.ImageIO;

import org.jogamp.java3d.Appearance;
import org.jogamp.java3d.BoundingBox;
import org.jogamp.java3d.BranchGroup;
import org.jogamp.java3d.Canvas3D;
import org.jogamp.java3d.ColoringAttributes;
import org.jogamp.java3d.GraphicsConfigTemplate3D;
import org.jogamp.java3d.Group;
import org.jogamp.java3d.LineArray;
import org.jogamp.java3d.Material;
import org.jogamp.java3d.Node;
import org.jogamp.java3d.PolygonAttributes;
import org.jogamp.java3d.Shape3D;
import org.jogamp.java3d.TexCoordGeneration;
import org.jogamp.java3d.Texture;
import org.jogamp.java3d.Texture2D;
import org.jogamp.java3d.TextureAttributes;
import org.jogamp.java3d.Transform3D;
import org.jogamp.java3d.TransformGroup;
import org.jogamp.java3d.loaders.Scene;
import org.jogamp.java3d.loaders.objectfile.ObjectFile;
import org.jogamp.java3d.utils.geometry.Box;
import org.jogamp.java3d.utils.geometry.Text2D;
import org.jogamp.java3d.utils.image.TextureLoader;
import org.jogamp.vecmath.Color3f;
import org.jogamp.vecmath.Point3d;
import org.jogamp.vecmath.Vector3d;
import org.jogamp.vecmath.Vector3f;
import org.jogamp.vecmath.Vector4f;

/**
*	Méthodes utilitaires pour Java3D
*	@author Jérôme Lehuen
*	@version 09/04/23
*/

public class Utils3D {

	public static void beep() {
		Toolkit.getDefaultToolkit().beep();
	}

	public static void wait(int ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static BufferedImage loadBufferedImageAsRessource(String filename) {
		try {
			return ImageIO.read(Utils3D.class.getResourceAsStream("/data/" + filename));
		}
		catch (IOException e) {
			return null;
		}
	}
	
	public static BufferedReader getReader(String filename) {
		InputStream is = Utils3D.class.getResourceAsStream("/data/" + filename);
		InputStreamReader isr = new InputStreamReader(is);
		return new BufferedReader(isr);
	}
	
	public static Canvas3D createCanvas3D() {
		GraphicsConfigTemplate3D gct3D = new GraphicsConfigTemplate3D();
		gct3D.setSceneAntialiasing(GraphicsConfigTemplate.REQUIRED);
		gct3D.setSceneAntialiasing(GraphicsConfigTemplate3D.REQUIRED);
		// https://forum.jogamp.org/8-pass-accumulation-Anti-Aliasing-td4040265.html
		// Ajouter System.setProperty("j3d.implicitAntialiasing", "true");
		// Ajouter System.setProperty("j3d.numSamples", "8");
		GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
		GraphicsDevice device = env.getDefaultScreenDevice();
		GraphicsConfiguration config = device.getBestConfiguration(gct3D);
		return new Canvas3D(config);
	}
	
	public static BranchGroup loadObject(String filename) {
		//System.out.println(String.format("Loading %s...", filename));
		ObjectFile loader = new ObjectFile();
		try {
			Scene scene = loader.load(getReader(filename));
			BranchGroup bg = scene.getSceneGroup();
			return bg;
		}
		catch (java.io.FileNotFoundException error) {
			System.err.println(error);
			System.exit(1);
			return null;
		}
	}

	public static void recursiveSetUserData(Node node, Object value) {
		// Pour propager récursivement le userdata
		node.setUserData(value);
		if (node instanceof Group) {
			Group group = (Group) node;
			Iterator<Node> nodes = group.getAllChildren();
			while(nodes.hasNext())
				recursiveSetUserData((Node) nodes.next(), value);
		}
	}

	public static Vector3f getGlobalCoordinates(TransformGroup tGroup) {
		// Position NOT including the last node's transform
		Transform3D globalT3d = new Transform3D();
		tGroup.getLocalToVworld(globalT3d);
		// Combiner avec la dernière transformation
		Transform3D t3d = new Transform3D();
		tGroup.getTransform(t3d);
		globalT3d.mul(t3d);
		// Récupérer la position
		Vector3f vector = new Vector3f();
		globalT3d.get(vector);
		return vector;
	}

	public static Texture2D loadTexture(String filename) {
		// Chargement d'une texture présente dans le répertoire data
		BufferedImage image = loadBufferedImageAsRessource(filename);
		TextureLoader textureLoader = new TextureLoader(image);
		Texture2D texture = (Texture2D) textureLoader.getTexture();
		texture.setEnable(true);
		texture.setBoundaryModeS(Texture.WRAP);
		texture.setBoundaryModeT(Texture.WRAP);
		return texture;
	}

	public static void addTexture(Shape3D shape, Texture2D texture) {
		// Killer Game Programming p.443
		Appearance app = shape.getAppearance();
		// Coordonnées pour appliquer une texture
		PolygonAttributes pa = new PolygonAttributes();
		pa.setCullFace(PolygonAttributes.CULL_NONE);
		app.setPolygonAttributes(pa);
		app.setTexCoordGeneration(stampTexCoords(shape));
		// Attributs de texture de l'apparence
		TextureAttributes ta = new TextureAttributes();
		ta.setTextureMode(TextureAttributes.REPLACE);
		ta.setPerspectiveCorrectionMode(TextureAttributes.NICEST);
		app.setTextureAttributes(ta);
		// Appliquer la texture
		app.setTexture(texture);
		shape.setAppearance(app);
	}

	public static void setFaceTexture(Box cube, int faceID, Texture2D texture) {
		Appearance app = new Appearance();
		app.setTexture(texture);
		cube.getShape(faceID).setAppearance(app);
	}

	private static TexCoordGeneration stampTexCoords(Shape3D shape) {
		// Killer Game Programming p.442
		BoundingBox boundBox = new BoundingBox(shape.getBounds());
		Point3d lower = new Point3d();
		Point3d upper = new Point3d();
		boundBox.getLower(lower);
		boundBox.getUpper(upper);
		double width = upper.x - lower.x;
		double height = upper.z - lower.z;
		//System.out.println(width + "," + height);
		Vector4f planeS = new Vector4f((float)(1/width), (float)(lower.x/width), 0, 0);
		Vector4f planeT = new Vector4f(0, (float)(lower.z/height), (float)(-1/height), 0);
		TexCoordGeneration texGen = new TexCoordGeneration();
		texGen.setPlaneS(planeS);
		texGen.setPlaneT(planeT);
		return texGen;
	}

	public static TransformGroup createText2D(String text, Color3f color, int size, float x, float y, float z) {
		TransformGroup tg = new TransformGroup();
		Transform3D t3d = new Transform3D();
		t3d.setTranslation(new Vector3d(x, y, z));
		tg.setTransform(t3d);
		Text2D text2D = new Text2D(text, color, "Helvetica", size, Font.PLAIN);
		tg.addChild(text2D);
		return tg;
	}

	public static Shape3D createLine3D(Point3d A, Point3d B, Appearance app) {
		LineArray line = new LineArray(2, LineArray.COORDINATES);
		line.setCoordinate(0, A);
		line.setCoordinate(1, B);
		Shape3D shape = new Shape3D(line);
		shape.setAppearance(app);
		shape.setCollidable(false);
		return shape;
	}

	public static void changeAppearance(BranchGroup bg, Appearance appearance) {
		Iterator<Node> iterator = bg.getAllChildren();
		while (iterator.hasNext()) {
			Node node = iterator.next();
			if (node instanceof Shape3D) {
				Shape3D shape = (Shape3D) node;
				shape.setAppearance(appearance);
			}
		 	else if (node instanceof Group) {
				changeAppearance((BranchGroup)node, appearance);
			}
		}
	}

	public static Appearance createAppearance(int r, int g, int b) {
		Color3f color = color3f(r, g, b);
		Material material = new Material();
		material.setSpecularColor(color);
		material.setDiffuseColor(color);
		Appearance appareance = new Appearance();
		appareance.setMaterial(material); // Pour les balles
		appareance.setCapability(Appearance.ALLOW_LINE_ATTRIBUTES_WRITE); // Pour les lignes
		appareance.setColoringAttributes(new ColoringAttributes(color, ColoringAttributes.NICEST)); // Pour les lignes
		return appareance;
	}

	public static Color3f getColor(Appearance appareance) {
		Material material = appareance.getMaterial();
		if (material == null) return null;
		Color3f color = new Color3f();
		material.getDiffuseColor(color);
		return color;
	}

	public static Color3f color3f(int r, int g, int b) {
		return new Color3f((float)r/255, (float)g/255, (float)b/255);
	}

	public static void changeAppearance(BranchGroup bg, int r, int g, int b) {
		changeAppearance(bg, createAppearance(r, g, b));
	}

	public static TransformGroup translate(Node note, float dx, float dy, float dz) {
		Transform3D t3D = new Transform3D();
		t3D.setTranslation(new Vector3f(dx, dy, dz));
		TransformGroup group = new TransformGroup(t3D);
		group.addChild(note);
		return group;
	}
}
