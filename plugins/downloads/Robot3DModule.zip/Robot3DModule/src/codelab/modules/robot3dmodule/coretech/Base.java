package codelab.modules.robot3dmodule.coretech;

import org.jogamp.java3d.Transform3D;
import org.jogamp.vecmath.Point3d;
import org.jogamp.vecmath.Vector3f;

import codelab.modules.robot3dmodule.AbstractRobotPart;
import codelab.modules.robot3dmodule.Constants;
import codelab.modules.robot3dmodule.Utils3D;

/**
*	Classe de la base du robot CoreTech
*	@author Jérôme Lehuen
*	@version 25/01/21
*/

public class Base extends AbstractRobotPart {

	private static final String IDENT = "the base";
	private static final String FILENAME = "coretech/base.obj";

	///////////////////////////////////////////////////
	// Constructeur
	///////////////////////////////////////////////////

	Base(RobotCoreTech robot) {
		super(robot, IDENT, FILENAME);
		Utils3D.changeAppearance(loadedBG, 230, 115, 50);
		setCollidable(true);

		// Création et ajout du modèle filaire

		/*
		addTransformedPrimitive(
			new Cylinder(17, 3, Simulator3D.REDPOLYGON),
			new Vector3f(0, -3, 0));
		addTransformedPrimitive(
			new Cylinder(14, 18, Simulator3D.REDPOLYGON),
			new Vector3f(0, -14, 0));
		addTransformedPrimitive(
			new Cylinder(17, 4, Simulator3D.REDPOLYGON),
			new Vector3f(0, -24, 0));
		*/

		root.addChild(Utils3D.createLine3D(new Point3d(0, 0, 0), new Point3d(0, -26, 0), Constants.REDPOLYGON));
	}

	///////////////////////////////////////////////////
	// Transformation initiale
	///////////////////////////////////////////////////

	protected Transform3D getT3DInit() {
		Transform3D t3D = new Transform3D();
		t3D.set(new Vector3f(0, 0.26f, 0));
		t3D.setScale(0.01f); // Échelle 1:100
		return t3D;
	}

	///////////////////////////////////////////////////
	// Rotation de l'élément
	///////////////////////////////////////////////////

	public float getRotation() { return 0; }
	public void setRotation(float alpha) {}
	public void rotate(float delta) {}
	public void reset() {}
}
