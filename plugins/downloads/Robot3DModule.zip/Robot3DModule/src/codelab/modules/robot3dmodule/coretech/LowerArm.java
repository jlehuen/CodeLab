package codelab.modules.robot3dmodule.coretech;

import org.jogamp.java3d.Transform3D;
import org.jogamp.vecmath.Point3d;
import org.jogamp.vecmath.Vector3f;

import codelab.modules.robot3dmodule.AbstractRobotPart;
import codelab.modules.robot3dmodule.Constants;
import codelab.modules.robot3dmodule.Utils3D;

/**
*	Classe de l'épaule du bras inférieur du robot CoreTech
*	@author Jérôme Lehuen
*	@version 25/01/21
*/

public class LowerArm extends AbstractRobotPart {

	private static final String IDENT = "the lower arm";
	private static final String FILENAME = "coretech/lowerArm.obj";

	private final float ALPHA = 90; // Position initiale

	///////////////////////////////////////////////////
	// Constructeur
	///////////////////////////////////////////////////

	LowerArm(RobotCoreTech robot) {
		super(robot, IDENT, FILENAME);
		Utils3D.changeAppearance(loadedBG, 230, 115, 50);
		setCollidable(true);

		// Création et ajout du modèle filaire
		//addTransformedPrimitive(
		//	new Box(10, 9, 7, Simulator3D.REDPOLYGON),
		//	new Vector3f(0, 29, 0));

		root.addChild(Utils3D.createLine3D(new Point3d(-AXE, 0, 0), new Point3d(AXE, 0, 0), Constants.REDPOLYGON));
		root.addChild(Utils3D.createLine3D(new Point3d(0, 0, 0), new Point3d(0, 50, 0), Constants.REDPOLYGON));
		update();
	}

	///////////////////////////////////////////////////
	// Transformation initiale
	///////////////////////////////////////////////////

	protected Transform3D getT3DInit() {
		Transform3D t3D = new Transform3D();
		t3D.set(new Vector3f(0, 50, 0));
		return t3D;
	}

	///////////////////////////////////////////////////
	// Rotation de l'élément
	///////////////////////////////////////////////////

	private float alpha = ALPHA;

	public float getRotation() { return alpha; }

	public void setRotation(float alpha) {
		this.alpha = alpha;
		update();
	}

	public void rotate(float delta) {
		alpha += delta;
		if (alpha > 130) { alpha = 130; stopperAlert(); }
		if (alpha < -130) { alpha = -130; stopperAlert(); }
		update();
	}

	public void reset() {
		alpha = ALPHA;
		update();
	}

	///////////////////////////////////////////////////
	// Actualisation
	///////////////////////////////////////////////////

	private void update() {
		Transform3D t3D = getT3DInit();
		Transform3D rotate = new Transform3D();
		rotate.rotX(Math.toRadians(alpha));
		t3D.mul(rotate);
		root.setTransform(t3D);
	}

}
