package codelab.modules.robot3dmodule;

import org.jogamp.java3d.Appearance;
import org.jogamp.java3d.BranchGroup;
import org.jogamp.java3d.Node;
import org.jogamp.java3d.Transform3D;
import org.jogamp.java3d.TransformGroup;
import org.jogamp.java3d.utils.geometry.Primitive;
import org.jogamp.vecmath.Vector3f;

/**
*	Classe des objets 3D abstraits
*	@author Jérôme Lehuen
*	@version 08/02/21
*/

public abstract class AbstractObject3D extends BranchGroup {

	protected TransformGroup root;
	protected Appearance appearance;
	protected String descr; // Description
	protected String uid; // Identificateur unique

	///////////////////////////////////////////////////
	// Constructeur
	///////////////////////////////////////////////////

	public AbstractObject3D(String descr, Appearance appearance) {
		this.descr = descr;
		this.appearance = appearance;
		uid = String.format("%s-%s", descr, Integer.toHexString(hashCode()));
		setCapability(BranchGroup.ALLOW_DETACH);
		setCapability(Node.ALLOW_LOCAL_TO_VWORLD_READ);

		Transform3D t3D = new Transform3D();
		root = new TransformGroup(t3D);
		root.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
		root.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		addChild(root);
	}

	protected void add(Primitive primitive) {
		Utils3D.recursiveSetUserData(primitive, uid);
		root.addChild(primitive);
	}

	///////////////////////////////////////////////////
	// Méthodes publiques
	///////////////////////////////////////////////////

	public String getIdent() { return descr; }
	public String getUID() { return uid; }

	public Vector3f getGlobalCoordinates() {
		return Utils3D.getGlobalCoordinates(root);
	}

	public void positionne(Vector3f translation, float scale) {
		Transform3D t3D = new Transform3D();
		t3D.set(translation);
		t3D.setScale(scale);
		root.setTransform(t3D);
	}

	public Appearance getAppearance() {
		return appearance;
	}
}
