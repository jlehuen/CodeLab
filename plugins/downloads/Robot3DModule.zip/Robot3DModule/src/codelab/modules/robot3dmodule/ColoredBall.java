package codelab.modules.robot3dmodule;

import org.jogamp.java3d.Appearance;
import org.jogamp.java3d.utils.geometry.Sphere;

/**
*	Classe des balles colorées
*	@author Jérôme Lehuen
*	@version 08/02/21
*/

public class ColoredBall extends AbstractObject3D {

	///////////////////////////////////////////////////
	// Constructeurs
	///////////////////////////////////////////////////

	public ColoredBall(float radius, Appearance appearance, String descr, boolean collidable) {
		super(descr, appearance);
		Sphere sphere = new Sphere(radius, Sphere.GENERATE_NORMALS, 120, appearance);
		sphere.setCollidable(collidable);
		add(sphere);
	}

	public ColoredBall(float radius, Appearance appearance) {
		super("a ball", appearance);
		Sphere sphere = new Sphere(radius, Sphere.GENERATE_NORMALS, 120, appearance);
		sphere.setCollidable(false);
		add(sphere);
	}
}
