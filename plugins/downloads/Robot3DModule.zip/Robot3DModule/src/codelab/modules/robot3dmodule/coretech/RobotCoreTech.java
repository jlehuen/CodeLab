package codelab.modules.robot3dmodule.coretech;

import java.awt.Color;

import org.jogamp.java3d.Appearance;
import org.jogamp.java3d.DirectionalLight;
import org.jogamp.java3d.LineAttributes;
import org.jogamp.vecmath.Color3f;
import org.jogamp.vecmath.Point3d;
import org.jogamp.vecmath.Vector3f;

import codelab.CodeLab;
import codelab.DataTableInterface;
import codelab.modules.robot3dmodule.Robot3DModule;
import codelab.modules.robot3dmodule.AbstractObject3D;
import codelab.modules.robot3dmodule.AbstractRobot3D;
import codelab.modules.robot3dmodule.ColoredBall;
import codelab.modules.robot3dmodule.Constants;
import codelab.modules.robot3dmodule.Motor;
import codelab.modules.robot3dmodule.Simulator3D;
import codelab.modules.robot3dmodule.Utils3D;

/**
*	Classe du robot 3D CoreTech
*	@author Jérôme Lehuen
*	@version 09/04/23
*/

public class RobotCoreTech extends AbstractRobot3D implements DataTableInterface {

	private Base base;
	private Hand hand;
	private Claw claw;
	private Pencil pencil;
	private Shoulder shoulder;
	private UpperArm upperArm;
	private LowerArm lowerArm;

	public final static int MAX_SENSOR = 1; // Deux capteurs
	
	private String LABEL(String id) {
		return Robot3DModule.INSTANCE.LABEL(id);
	}

	///////////////////////////////////////////////////
	// Implémentation de DataTableInterface
	///////////////////////////////////////////////////

	private final int NBDATA = 16;
	private String[] propKey = new String[NBDATA];
	private String[] propVal = new String[NBDATA];
	
	public int getNbProp() {
		return NBDATA;
	}

	public String getPropKey(int i) {
		return propKey[i];
	}

	public String getPropVal(int i) {
		return propVal[i];
	}

	public void updateValues() {
	
		propKey[0] = LABEL("RobotCoretech_key_0");
		propKey[1] = LABEL("RobotCoretech_key_1");
		propKey[2] = "";
		propKey[3] = "";
		propKey[4] = LABEL("RobotCoretech_key_4");
		propKey[5] = "";
		propKey[6] = LABEL("RobotCoretech_key_6");
		propKey[7] = "";
		propKey[8] = LABEL("RobotCoretech_key_8");
		propKey[9] = "";
		propKey[10] = LABEL("RobotCoretech_key_10");
		propKey[11] = "";
		propKey[12] = LABEL("RobotCoretech_key_12");
		propKey[13] = "";
		propKey[14] = LABEL("RobotCoretech_key_14");
		propKey[15] = "";
		
		propVal[0] = LABEL("RobotCoretech_val_0");
		propVal[1] = String.format(LABEL("RobotCoretech_val_1"), simulator.getTheta());
		propVal[2] = String.format(LABEL("RobotCoretech_val_2"), simulator.getRayon());
		propVal[3] = String.format(LABEL("RobotCoretech_val_3"), simulator.getElevation());
		propVal[4] = String.format(LABEL("RobotCoretech_val_angle"), shoulder.getRotation());
		propVal[5] = String.format(LABEL("RobotCoretech_val_speed"), shoulder.getMotor().getSpeed());
		propVal[6] = String.format(LABEL("RobotCoretech_val_angle"), upperArm.getRotation());
		propVal[7] = String.format(LABEL("RobotCoretech_val_speed"), upperArm.getMotor().getSpeed());
		propVal[8] = String.format(LABEL("RobotCoretech_val_angle"), lowerArm.getRotation());
		propVal[9] = String.format(LABEL("RobotCoretech_val_speed"), lowerArm.getMotor().getSpeed());
		propVal[10] = String.format(LABEL("RobotCoretech_val_angle"), hand.getRotation());
		propVal[11] = String.format(LABEL("RobotCoretech_val_speed"), hand.getMotor().getSpeed());
		propVal[12] = String.format(LABEL("RobotCoretech_val_angle"), claw.getRotation());
		propVal[13] = String.format(LABEL("RobotCoretech_val_speed"), claw.getMotor().getSpeed());
		propVal[14] = claw.getObjectName();
		propVal[15] = String.format(LABEL("RobotCoretech_val_objcolor"), claw.getObjectColor());
	}
	
	///////////////////////////////////////////////////
	// Constructeur (description de la scène)
	///////////////////////////////////////////////////

	public RobotCoreTech(Simulator3D simulator) {
		super(simulator);

		// Assembler le robot
		base = new Base(this);
		base.addChild(shoulder = new Shoulder(this));
		shoulder.addChild(upperArm = new UpperArm(this));
		upperArm.addChild(lowerArm = new LowerArm(this));
		lowerArm.addChild(hand = new Hand(this));
		hand.addChild(pencil = new Pencil(this));
		hand.addChild(claw = new Claw(this));

		// Ajouter des moteurs
		addMotor(new Motor(shoulder));
		addMotor(new Motor(upperArm));
		addMotor(new Motor(lowerArm));
		addMotor(new Motor(hand));
		addMotor(new Motor(claw));

		// Positionner le robot
		addRobot(base);

		// Ajouter un fond
		//addBackground("textures/night.jpg");
		//addBackground(new Background(Simulator3D.COLOR_BLACK));
		app_sol.setTexture(Utils3D.loadTexture("textures/sol.jpg"));
		app_murs.setTexture(Utils3D.loadTexture("textures/murs.jpg"));
		app_plafond.setTexture(Utils3D.loadTexture("textures/plafond.jpg"));
		addSceneBox(0, 2, 6); // Hauteur sol, hauteur plafond, longueur murs

		// Positionner des éclairages directionnels
		Color3f lightColor = Utils3D.color3f(255, 255, 255);
		Vector3f lightDirection1 = new Vector3f(4.0f, -7.0f, -12.0f);
		Vector3f lightDirection2 = new Vector3f(-4.0f, -7.0f, 12.0f);
		addLight(new DirectionalLight(lightColor, lightDirection1));
		addLight(new DirectionalLight(lightColor, lightDirection2));

		// Initialiser la position du spectateur
		VIEWER_THETA = 55;
		VIEWER_DISTANCE = 4;
		VIEWER_ELEVATION = 1.5;
		VIEWER_DIRECTION = new Point3d(0, 0.5f, 0);

		// Activer les collisions
		detectCollisions = true;

		drawAxis();
		compile();
	}

	///////////////////////////////////////////////////
	// Surcharge de update()
	///////////////////////////////////////////////////

	public void update() {
		super.update();
		if (draw) draw();
	}

	///////////////////////////////////////////////////
	// Instructions grab et drop
	///////////////////////////////////////////////////

	public int grab() {
		AbstractObject3D object = pencil.getCollidedObject();
		if (object == null) {
			String msg = LABEL("RobotCoretech_nograsp");
			simulator.printToConsole(msg, Color.ORANGE);
			return -1;
		}
		claw.grab(object);
		return 1;
	}

	public int drop() {
		AbstractObject3D object = claw.drop();
		if (object == null) {
			String msg = LABEL("RobotCoretech_nodrop");
			simulator.printToConsole(msg, Color.ORANGE);
			return -1;
		}
		Vector3f position = object.getGlobalCoordinates();
		position.y = 0.05f; // Hauteur = rayon de la balle
		object.detach();
		addObject(object, position, 1.0f); // Echelle 1
		return 1;
	}

	///////////////////////////////////////////////////
	// Instruction setColor
	///////////////////////////////////////////////////

	private Appearance draw_color = Constants.RED;

	private int color_r = 255;
	private int color_g = 255;
	private int color_b = 255;

	public int setColor(int r, int g, int b) {
		if (errorRGB(r, g, b)) return -1;
		draw_color = Utils3D.createAppearance(r, g, b);
		// Epaisseur du trait
		LineAttributes la = new LineAttributes();
		la.setCapability(LineAttributes.ALLOW_WIDTH_WRITE);
		la.setLineWidth(Constants.HD ? 4 : 2);
		draw_color.setLineAttributes(la);
		// Pour la méthode plot()
		this.color_r = r;
		this.color_g = g;
		this.color_b = b;
		return 1;
	}

	///////////////////////////////////////////////////
	// Instructions drawOn, drawOff et clearScreen
	///////////////////////////////////////////////////

	private final float SEGMENT = 0.01f; // Longueur des segments

	private Point3d p1;
	private boolean draw = false;

	public int drawOn() {
		p1 = pencil.getDrawingPoint();
		draw = true;
		return 1;
	}

	public int drawOff() {
		drawEnd();
		draw = false;
		return 1;
	}

	private void draw() {
		// Pour tracer une ligne à partir de petits segments
		if (p1 == null) return;
		Point3d p2 = pencil.getDrawingPoint();
		if (p1.distance(p2) > SEGMENT) {
			drawLine(p1, p2, draw_color);
			p1 = p2;
		}
	}

	private void drawEnd() {
		// Pout terminer un tracé depuis la dernière position
		if (!draw) return;
		if (p1 == null) return;
		Point3d p2 = pencil.getDrawingPoint();
		drawLine(p1, p2, draw_color);
	}

	public int clearScreen() {
		claw.clear(); // Au cas où
		removeLines(); // Supprimer les lignes
		removeObjects(); // Supprimer les objets
		return 1;
	}

	///////////////////////////////////////////////////
	// Instructions plot et putBall
	///////////////////////////////////////////////////

	public int plot() {
		Point3d coords = pencil.getDrawingPoint();
		drawPoint(coords, color_r, color_g, color_b);
		return 1;
	}

	public String putBall(float x, float y, float z, int r, int g, int b, String descr) {
		if (errorRGB(r, g, b)) return "-1";
		Appearance appearance = Utils3D.createAppearance(r, g, b);
		ColoredBall ball = new ColoredBall(0.05f, appearance, descr, true);
		addObject(ball, new Vector3f(x, y, z), 1.0f);
		return ball.getUID();
	}

	///////////////////////////////////////////////////
	// Instructions getX, getY et getZ
	///////////////////////////////////////////////////

	public float getX() {
		Point3d point = pencil.getDrawingPoint();
		return (float)point.x;
	}

	public float getY() {
		Point3d point = pencil.getDrawingPoint();
		return (float)point.y;
	}

	public float getZ() {
		Point3d point = pencil.getDrawingPoint();
		return (float)point.z;
	}

	public String getPencilPosition() {
		// Retourne les coordonées du crayon au format "x:y:z"
		Point3d point = pencil.getDrawingPoint();
		return String.format("%f:%f:%f", point.x, point.y, point.z).replace(',', '.');
	}

	///////////////////////////////////////////////////
	// Instruction getContactValue
	///////////////////////////////////////////////////

	public String getSensorValue(int sensor) {
		if ((sensor < 0) || (sensor > MAX_SENSOR)) {
			runtimeError(String.format(LABEL("RobotCoreTech_Error_1"), sensor, MAX_SENSOR));
			return "ERROR";
		}
		// Capteur de contact au bout du pencil
		if (sensor == 0) return pencil.getContactValue();
		// Capteur de couleur dans la pince
		if (sensor == 1) return claw.getObjectColor();

		return "ERROR";
	}
}
