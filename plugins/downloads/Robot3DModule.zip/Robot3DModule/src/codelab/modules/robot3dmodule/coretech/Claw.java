package codelab.modules.robot3dmodule.coretech;

import java.awt.Color;

import org.jogamp.java3d.Shape3D;
import org.jogamp.java3d.Transform3D;
import org.jogamp.vecmath.Color3f;
//import org.jogamp.java3d.utils.geometry.Box;
import org.jogamp.vecmath.Point3d;
import org.jogamp.vecmath.Vector3f;

import codelab.CodeLab;
import codelab.modules.robot3dmodule.Robot3DModule;
import codelab.modules.robot3dmodule.AbstractObject3D;
import codelab.modules.robot3dmodule.AbstractRobotPart;
import codelab.modules.robot3dmodule.Constants;
import codelab.modules.robot3dmodule.Utils3D;

/**
*	Classe de la pince du robot CoreTech
*	@author Jérôme Lehuen
*	@version 09/04/23
*/

public class Claw extends AbstractRobotPart {

	private static final String IDENT = "the claw";
	private static final String FILENAME = "coretech/claw.obj";

	private final float ALPHA = 90; // Position initiale

	//private Box box;

	// Modèle filaire de la pince
	private Point3d P1 = new Point3d(-10, 10, 0);
	private Point3d P2 = new Point3d(-5, 2, 0);
	private Point3d P3 = new Point3d(5, 2, 0);
	private Point3d P4 = new Point3d(10, 10, 0);

	///////////////////////////////////////////////////
	// Constructeur
	///////////////////////////////////////////////////

	Claw(RobotCoreTech robot) {
		super(robot, IDENT, FILENAME);
		Utils3D.changeAppearance(loadedBG, 170, 170, 170);
		setCollidable(false);

		// Création et ajout du modèle filaire
		//addTransformedPrimitive(
		//	box = new Box(11, 6, 3, Simulator3D.REDPOLYGON),
		//	new Vector3f(0, 6, 0));

		// Dessin de la pince
		Shape3D line1 = Utils3D.createLine3D(P1, P2, Constants.REDPOLYGON);
		Shape3D line2 = Utils3D.createLine3D(P2, P3, Constants.REDPOLYGON);
		Shape3D line3 = Utils3D.createLine3D(P3, P4, Constants.REDPOLYGON);
		addCollidableShape(this, line1);
		addCollidableShape(this, line2);
		addCollidableShape(this, line3);
		root.addChild(line1);
		root.addChild(line2);
		root.addChild(line3);

		update();
	}

	///////////////////////////////////////////////////
	// Transformation initiale
	///////////////////////////////////////////////////

	protected Transform3D getT3DInit() {
		Transform3D t3D = new Transform3D();
		t3D.set(new Vector3f(0, 13, 0));
		return t3D;
	}

	///////////////////////////////////////////////////
	// Rotation de l'élément
	///////////////////////////////////////////////////

	private float alpha = ALPHA;

	public float getRotation() { return alpha; }

	public void setRotation(float alpha) {
		this.alpha = alpha;
		update();
	}

	public void rotate(float delta) {
		alpha += delta;
		if (alpha > 360) alpha -= 360;
		if (alpha < 0) alpha += 360;
		update();
	}

	public void reset() {
		alpha = ALPHA;
		update();
		takedObject = null; // Vider la pince
	}

	///////////////////////////////////////////////////
	// Actualisation
	///////////////////////////////////////////////////

	private void update() {
		Transform3D t3D = getT3DInit();
		Transform3D rotate = new Transform3D();
		rotate.rotY(Math.toRadians(alpha));
		t3D.mul(rotate);
		root.setTransform(t3D);
	}

	///////////////////////////////////////////////////
	// Actions grab et drop
	///////////////////////////////////////////////////

	private AbstractObject3D takedObject = null;

	public String getObjectName() {
		if (takedObject == null) return "NONE";
		return takedObject.getUID();
	}

	public void grab(AbstractObject3D object) {
		if (takedObject != null) {
			// Il y a déjà un objet dans la pince
			robot.simulator.module.codelab.halt();
			robot.simulator.printToConsole("ALERT: Non-empty clow!\n", Color.RED);
			Robot3DModule.playAudio("stop_alert.wav");
		}
		object.detach();
		object.positionne(new Vector3f(0, 14, 0), 100.0f); // Adptation d'échelle
		root.addChild(object);
		takedObject = object;
	}

	public AbstractObject3D drop() {
		if (takedObject == null) return null; // Il n'y a rien à lâcher
		AbstractObject3D object = takedObject;
		takedObject = null;
		return object;
	}

	public void clear() {
		takedObject = null; // Pour le clearScreen
	}

	///////////////////////////////////////////////////
	// Instruction getColorObject
	///////////////////////////////////////////////////

	public String getObjectColor() {
		if (takedObject == null) return "NONE";
		Color3f color = Utils3D.getColor(takedObject.getAppearance());
		if (color == null) return "NONE";
		return String.format("%d:%d:%d", (int)(color.x*255), (int)(color.y*255), (int)(color.z*255));
	}
}
