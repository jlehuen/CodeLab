package codelab.modules.robot3dmodule;

import java.awt.Color;

import org.jogamp.java3d.BranchGroup;
import org.jogamp.java3d.Group;
import org.jogamp.java3d.Node;
import org.jogamp.java3d.Shape3D;
import org.jogamp.java3d.Transform3D;
import org.jogamp.java3d.TransformGroup;
import org.jogamp.java3d.utils.geometry.Primitive;
import org.jogamp.vecmath.Vector3f;

import codelab.CodeLab;

/**
*	Classe abstraite des parties d'un robot 3D
*	@author Jérôme Lehuen
*	@version 09/04/23
*/

public abstract class AbstractRobotPart {

	protected static final boolean COLLIDABLE = true;
	protected static final boolean NO_COLLIDABLE = false;
	protected static final int AXE = 5; // Longueur du demi-axe de rotation

	protected String ident;
	protected BranchGroup loadedBG;
	protected TransformGroup root;
	protected AbstractRobot3D robot;
	protected Motor motor = null;

	public boolean circular = false; // Passage possible par le 360
	public boolean flag360 = false; // Flag du passage par le 360 (cf. Shoulder & Motor)

	protected void setCollidable(boolean collidable) {
		root.setCollidable(collidable);
	}

	///////////////////////////////////////////////////
	// Constructeur
	///////////////////////////////////////////////////

	public AbstractRobotPart(AbstractRobot3D robot, String ident, String filename) {
		this.robot = robot;
		this.ident = ident;
		robot.addPart(this);

		// Instanciation du noeud racine
		Transform3D t3D = getT3DInit();
		root = new TransformGroup(t3D);
		root.setUserData(ident);

		// Autoriser les mouvements
		root.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
		root.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		// Autoriser les modifications de structure
		root.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
		root.setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);
		root.setCapability(Group.ALLOW_CHILDREN_EXTEND);

		// Autoriser les changements d'état collidable
		root.setCapability(Node.ALLOW_COLLIDABLE_WRITE);

		// Chargement et ajout d'un modèle wavefront
		if (filename != null) {
			loadedBG = Utils3D.loadObject(filename);
			loadedBG.setCapability(BranchGroup.ALLOW_DETACH);
			loadedBG.setCollidable(true);
			Utils3D.recursiveSetUserData(loadedBG, ident);
			root.addChild(loadedBG);
		}
	}

	///////////////////////////////////////////////////
	// Ajout d'un élément du modèle filaire
	///////////////////////////////////////////////////

	protected void addTransformedPrimitive(Primitive primitive, Vector3f translation) {
		primitive.setCollidable(false);
		Utils3D.recursiveSetUserData(primitive, ident);
		Transform3D t3D = new Transform3D();
		t3D.setTranslation(translation);
		TransformGroup group = new TransformGroup(t3D);
		group.addChild(primitive);
		root.addChild(group);
	}

	///////////////////////////////////////////////////
	// Ajout d'un détecteur de collision
	///////////////////////////////////////////////////

	protected String collidedObjectIdent = null;
	protected AbstractObject3D collidedObject = null;

	public AbstractObject3D getCollidedObject() {
		return collidedObject;
	}

	protected void addCollidableShape(AbstractRobotPart part, Shape3D shape, boolean sensor) {
		shape.setUserData(ident);
		robot.addCollisionDetector(part, shape, sensor);
	}

	protected void addCollidableShape(AbstractRobotPart part, Shape3D shape) {
		this.addCollidableShape(part, shape, false);
	}

	///////////////////////////////////////////////////
	// Collision en butée
	///////////////////////////////////////////////////

	public void stopperAlert() {
		robot.stopAllMotors(); // On arrête les moteurs
		robot.simulator.module.codelab.halt(); // On arrête le simulateur et le programme
		robot.simulator.printToConsole(String.format("INFO: %s is stopped to its limit\n", ident), Color.ORANGE);		
		Robot3DModule.playAudio("stop_alert.wav");
	}

	///////////////////////////////////////////////////
	// Pour activer ou désactiver le mode DEBUG
	///////////////////////////////////////////////////

	public void debug_on() {
		loadedBG.detach();
	}

	public void debug_off() {
		root.addChild(loadedBG);
	}

	///////////////////////////////////////////////////
	// Méthodes imposées à implémenter
	///////////////////////////////////////////////////

	protected abstract Transform3D getT3DInit();
	public abstract void rotate(float delta);
	public abstract float getRotation();
	public abstract void setRotation(float alpha);
	public abstract void reset();

	///////////////////////////////////////////////////
	// Quelques méthodes publiques
	///////////////////////////////////////////////////

	public TransformGroup getRoot() {
		return root;
	}

	public Vector3f getGlobalCoordinates() {
		return Utils3D.getGlobalCoordinates(root);
	}

	public void addChild(AbstractRobotPart part) {
		root.addChild(part.getRoot());
	}

	public void setMotor(Motor motor) {
		this.motor = motor;
	}

	public Motor getMotor() {
		return motor;
	}

	public void translate(Vector3f vector) {
		// Inutilisé pour l'instant
		Transform3D t3D = new Transform3D();
		root.getTransform(t3D);
		Transform3D translate = new Transform3D();
		translate.set(vector);
		t3D.mul(translate);
		root.setTransform(t3D);
	}
}
