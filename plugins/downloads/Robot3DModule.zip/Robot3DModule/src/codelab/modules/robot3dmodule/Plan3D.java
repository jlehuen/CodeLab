package codelab.modules.robot3dmodule;

import org.jogamp.java3d.Appearance;
import org.jogamp.java3d.Geometry;
import org.jogamp.java3d.GeometryArray;
import org.jogamp.java3d.Material;
import org.jogamp.java3d.QuadArray;
import org.jogamp.java3d.Shape3D;
import org.jogamp.vecmath.Point3d;
import org.jogamp.vecmath.TexCoord2f;

/**
*	Classe des plans définis par 4 points
*	@author Jérôme Lehuen
*	@version 27/01/21
*/

public class Plan3D extends Shape3D {

	///////////////////////////////////////////////////
	// Constructeurs
	///////////////////////////////////////////////////

	public Plan3D(Point3d A, Point3d B, Point3d C, Point3d D) {
		setGeometry(createGeometry(A, B, C, D));
		Appearance appearance = new Appearance();
		Material material = new Material();
		appearance.setMaterial(material);
		setAppearance(appearance);
	}

	public Plan3D(Point3d A, Point3d B, Point3d C, Point3d D, Appearance appearance) {
		setGeometry(createGeometry(A, B, C, D));
		setAppearance(appearance);
	}

	public Plan3D(Point3d A, Point3d B, Point3d C, Point3d D, Appearance appearance, String id) {
		this(A, B, C, D, appearance);
		setUserData(id);
	}

	///////////////////////////////////////////////////
	// Méthodes privées
	///////////////////////////////////////////////////

	private Geometry createGeometry(Point3d A, Point3d B, Point3d C, Point3d D) {
		Point3d[] coords = new Point3d[] { A, B, C, D };
		QuadArray plane = new QuadArray(4,
			GeometryArray.COORDINATES |
			GeometryArray.TEXTURE_COORDINATE_2);
		plane.setCoordinates(0, coords);
		plane.setTextureCoordinate(0, 0, new TexCoord2f(0.0f, 0.0f));
		plane.setTextureCoordinate(0, 1, new TexCoord2f(1.0f, 0.0f));
		plane.setTextureCoordinate(0, 2, new TexCoord2f(1.0f, 1.0f));
		plane.setTextureCoordinate(0, 3, new TexCoord2f(0.0f, 1.0f));
		return plane;
	}
}
