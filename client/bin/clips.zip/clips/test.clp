(printout t "bonjour" crlf)

(deffacts toto
	(a b c)
	(d e f))

(defrule titi
	(a ?x ?
	=>
	(assert (b c d)))

