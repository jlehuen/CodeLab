/*
#####################################################################
## This file is part of the software CodeLab IDE & Simulators      ##
## For any question about CodeLab e-mail to codelab@univ-lemans.fr ##
#####################################################################
*/

// DO NOT DELETE OR MODIFY THIS FILE !!

package codelab.yourmodule;
import common.*;

public class YourAPI extends SocketClient {


	private final String SETTEXT_CMD = "module=YOURMODULE&cmd=setText&str=%s";
	private final String SETFONT_CMD = "module=YOURMODULE&cmd=setFont&name=%s&size=%d";

	public int setText(String str) {
		String buffer = String.format(SETTEXT_CMD, str);
		return Integer.parseInt(request(buffer));
	}

	public int setFont(String name, int size) {
		String buffer = String.format(SETFONT_CMD, name, size);
		return Integer.parseInt(request(buffer));
	}

}

