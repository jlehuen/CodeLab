<?xml version="1.0" encoding="utf-8"?>

<!--
#####################################################################
## This file is part of the software CodeLab IDE and Simulators    ##
## For any question about CodeLab e-mail to codelab@univ-lemans.fr ##
#####################################################################
-->

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

<xsl:output method="html"
            encoding="utf-8"
            doctype-public="-//W3C//DTD HTML 4.01//EN"
            doctype-system="http://www.w3.org/TR/html4/strict.dtd"
            indent="yes"/>

<xsl:template name="print-javatype">
	<xsl:param name="type" />
	<xsl:choose>
		<xsl:when test="$type='string'"><xsl:text>String</xsl:text></xsl:when>
		<xsl:otherwise><xsl:value-of select="$type"/></xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template name="print-instruction">
	<xsl:param name="node" />
	<xsl:text>public </xsl:text>
	<xsl:call-template name="print-javatype">
		<xsl:with-param name="type" select="@type"/>
	</xsl:call-template>
	<xsl:text> </xsl:text>
	<xsl:value-of select="@name"/>
	<xsl:text>(</xsl:text>
	<xsl:for-each select="arg">
		<xsl:call-template name="print-javatype">
			<xsl:with-param name="type" select="@type"/>
		</xsl:call-template>
		<xsl:text> </xsl:text>
		<xsl:value-of select="@name"/>
		<xsl:choose>
			<xsl:when test="position() != last()">
				<xsl:text>, </xsl:text>
			</xsl:when>
		</xsl:choose>
	</xsl:for-each>
	<xsl:text>)</xsl:text>
</xsl:template>

<xsl:template match="/">
	<HTML>
	<BODY>
	<xsl:apply-templates select="api"/>
	</BODY>
	</HTML>
</xsl:template>

<xsl:template match="api">
	<IMG src="img/logo-codelab.png" style="padding:20px"/>
	<H1>CodeLab Module <xsl:value-of select="@module"/></H1>
	<H2>API <xsl:value-of select="@name"/> for Java language</H2>
	<P><xsl:value-of select="description"/></P>
	<HR/>
	<xsl:if test="constant">
		<H2>Constants:</H2>
		<UL>
		<xsl:for-each select="constant">
			<LI>
				<CODE>
				<xsl:text>public static final </xsl:text>
				<xsl:call-template name="print-javatype">
					<xsl:with-param name="type" select="@type"/>
				</xsl:call-template>
				<xsl:text> </xsl:text>
				<xsl:value-of select="@name"/>
				<xsl:text> = </xsl:text>
				<xsl:choose>
					<xsl:when test="@type='string'">
						<xsl:text>"</xsl:text><xsl:value-of select="@value"/><xsl:text>"</xsl:text>
					</xsl:when>
					<xsl:when test="@type='float'">
						<xsl:value-of select="@value"/><xsl:text>f</xsl:text>
					</xsl:when>
					<xsl:otherwise>
						<xsl:value-of select="@value"/>
					</xsl:otherwise>
				</xsl:choose>
				<xsl:text>;</xsl:text>
				<xsl:if test="@doc and @doc != ''">
					<xsl:text> // </xsl:text>
					<xsl:value-of select="@doc"/>
				</xsl:if>
				</CODE>
			</LI>
		</xsl:for-each>
		</UL>
		<HR/>
	</xsl:if>
	<H2>Function prototypes:</H2>
	<UL>
	<xsl:for-each select="instruction">
		<LI>
		<A>
		<xsl:attribute name="href">#<xsl:value-of select="@name"/></xsl:attribute>
		<CODE>
		<xsl:call-template name="print-instruction">
			<xsl:with-param name="node" select="."/>
		</xsl:call-template>
		</CODE>
		</A>
		</LI>
	</xsl:for-each>
	</UL>
	<BR/>
	<xsl:apply-templates select="instruction"/>
	<xsl:if test="doc_java">
		<HR/>
		<H2>Documentation:</H2>
		<xsl:apply-templates select="doc_java"/>
	</xsl:if>
</xsl:template>

<xsl:template match="instruction">
	<P style="background-color:#F4ECF7;padding:5px">
		<xsl:attribute name="id">
			<xsl:value-of select="@name"/>
		</xsl:attribute>
		<CODE>
		<B>
		<xsl:call-template name="print-instruction">
			<xsl:with-param name="node" select="."/>
		</xsl:call-template>
		</B>
		</CODE>
	</P>
	
	<xsl:if test="@doc and @doc != ''">
		<P><xsl:value-of select="@doc"/></P>
	</xsl:if>
	
	<H4>Parameters:</H4>
	<xsl:choose>
		<xsl:when test="arg">
			<UL>
			<xsl:for-each select="arg">
				<LI>
					<CODE>
					<xsl:call-template name="print-javatype">
						<xsl:with-param name="type" select="@type"/>
					</xsl:call-template>
					<xsl:text> </xsl:text>
					<xsl:value-of select="@name"/>
					<xsl:if test="@doc and @doc != ''">
						<xsl:text> : </xsl:text>
						<xsl:value-of select="@doc"/>
					</xsl:if>
					</CODE>
				</LI>
			</xsl:for-each>
			</UL>
		</xsl:when>
		<xsl:otherwise>
			<P><I>None</I></P>
		</xsl:otherwise>
	</xsl:choose>
	
	<xsl:if test="doc_java">
		<H4>Documentation:</H4>
		<xsl:apply-templates select="doc_java"/>
	</xsl:if>
</xsl:template>

<xsl:template match="doc_java">
	<P><xsl:copy-of select="node()"/></P>
</xsl:template>

</xsl:stylesheet>
