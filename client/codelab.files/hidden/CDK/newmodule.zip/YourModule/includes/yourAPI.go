// #####################################################################
// ## This file is part of the software CodeLab IDE & Simulators      ##
// ## For any question about CodeLab e-mail to codelab@univ-lemans.fr ##
// #####################################################################

// DO NOT DELETE OR MODIFY THIS FILE !!

package yourAPI

import "codelab"
import "fmt"


const SETTEXT_CMD = "module=YOURMODULE&cmd=setText&str=%s"
const SETFONT_CMD = "module=YOURMODULE&cmd=setFont&name=%s&size=%d"

func SetText(str string) int {
	buffer := fmt.Sprintf(SETTEXT_CMD, str)
	return codelab.RequestToi(buffer)
}

func SetFont(name string, size int) int {
	buffer := fmt.Sprintf(SETFONT_CMD, name, size)
	return codelab.RequestToi(buffer)
}


