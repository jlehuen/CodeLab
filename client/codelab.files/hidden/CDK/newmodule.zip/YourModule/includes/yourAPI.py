#####################################################################
## This file is part of the software CodeLab IDE & Simulators      ##
## For any question about CodeLab e-mail to codelab@univ-lemans.fr ##
#####################################################################

## DO NOT DELETE OR MODIFY THIS FILE !!

from __init import *


SETTEXT_CMD = 'module=YOURMODULE&cmd=setText&str=%s'
SETFONT_CMD = 'module=YOURMODULE&cmd=setFont&name=%s&size=%d'

def setText(str):
	buffer = SETTEXT_CMD % str
	return int(request(buffer))

def setFont(name, size):
	buffer = SETFONT_CMD % (name, size)
	return int(request(buffer))


