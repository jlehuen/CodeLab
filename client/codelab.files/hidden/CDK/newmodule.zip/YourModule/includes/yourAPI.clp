; #####################################################################
; ## This file is part of the software CodeLab IDE & Simulators      ##
; ## For any question about CodeLab e-mail to codelab@univ-lemans.fr ##
; #####################################################################

;; DO NOT DELETE OR MODIFY THIS FILE !!


(defglobal ?*SETTEXT_CMD* = "module=YOURMODULE&cmd=setText&str=%s")
(defglobal ?*SETFONT_CMD* = "module=YOURMODULE&cmd=setFont&name=%s&size=%d")

(deffunction setText (?str)
	(bind ?buffer (format nil ?*SETTEXT_CMD* ?str))
	(str2int (request ?buffer)))

(deffunction setFont (?name ?size)
	(bind ?buffer (format nil ?*SETFONT_CMD* ?name ?size))
	(str2int (request ?buffer)))


