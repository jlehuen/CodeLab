/*
#####################################################################
## This file is part of the software CodeLab IDE & Simulators      ##
## For any question about CodeLab e-mail to codelab@univ-lemans.fr ##
#####################################################################
*/

// DO NOT DELETE OR MODIFY THIS FILE !!

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>


const char* SETTEXT_CMD = "module=YOURMODULE&cmd=setText&str=%s";
const char* SETFONT_CMD = "module=YOURMODULE&cmd=setFont&name=%s&size=%d";

int setText(char* str) {
	char buffer[1024];
	snprintf(buffer, sizeof(buffer), SETTEXT_CMD, str);
	return atoi(request(buffer));
}

int setFont(char* name, int size) {
	char buffer[1024];
	snprintf(buffer, sizeof(buffer), SETFONT_CMD, name, size);
	return atoi(request(buffer));
}


