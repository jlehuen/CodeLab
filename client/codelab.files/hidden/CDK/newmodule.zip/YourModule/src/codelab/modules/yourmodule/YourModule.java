package codelab.modules.yourmodule;

import codelab.AbstractModule;
import codelab.CodeLab;

import java.awt.Font;
import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.util.Map;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class YourModule extends AbstractModule {

	private String title = "Module YourModule";

	private JPanel panel; // Or any other JComponent
	private JLabel label; // The content of the panel
	
	///////////////////////////////////////////////////
	// Constructor
	///////////////////////////////////////////////////

	public YourModule(CodeLab codelab) {
		super(codelab);
		setTitle(title);
		setToolbar(new YourToolbar(this));
		setComponent(panel = new JPanel());
		panel.setLayout(new GridBagLayout());
		panel.add(label = new JLabel());
		panel.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent event) {
				printToConsole("Hello from the panel!\n", Color.GREEN);
			}
		});
	}

	///////////////////////////////////////////////////
	// Abstract methods to implement (or not)
	///////////////////////////////////////////////////

	public void init() {
	}
	public void exit() {
	}
	public void start() {
	}
	public void stop() {
	}
	public void reset() {
	}
	
	///////////////////////////////////////////////////
	// Instruction handler (for example)
	///////////////////////////////////////////////////

	public String handleRequest(Map<String, String> params) {
		String cmd = params.get("cmd");
		switch (cmd) {
		
			case "setText":
				String str = params.get("str");
				return String.valueOf(setText(str));

			case "setFont":
				String name = params.get("name");
				int size = Integer.valueOf(params.get("size"));
				return String.valueOf(setFont(name, size));
				
			case "clear":
				return String.valueOf(clear());
				
			default:
				return unknownCommandError(cmd);
		}
	}
	
	///////////////////////////////////////////////////
	// API methods (for example)
	///////////////////////////////////////////////////

	public int setText(String str) {
		label.setText(str);
		return 1;
	}

	public int setFont(String name, int size) {
		label.setFont(new Font(name, 1, size));
		return 1;
	}

	public int clear() {
		panel.removeAll();
		panel.add(label = new JLabel());
		panel.repaint();
		return 1;
	}
}
