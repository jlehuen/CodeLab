package codelab.modules.yourmodule;

import codelab.AbstractToolbar;
import codelab.ToolButton;

import java.awt.Color;
import javax.swing.ImageIcon;

public class YourToolbar extends AbstractToolbar {

	private ImageIcon icon_hello = loadImageIcon("icon_hello.png");

	///////////////////////////////////////////////////
	// Constructor
	///////////////////////////////////////////////////

	public YourToolbar(YourModule module) {
		super(module);
		addSeparator();
		add(new ToolButton("HELLO", "Hello", "Say Hello", icon_hello, this));
		addSeparatorflex();
		endToolbar();
	}

	///////////////////////////////////////////////////
	// Action handler
	///////////////////////////////////////////////////

	public void action(String ident) {
		switch (ident) {
			case "HELLO": action_hello(); break;
			default: super.action(ident);
		}
	}

	private void action_hello() {
		printToConsole("Hello from the toolbar!\n", Color.GREEN);
	}
}
