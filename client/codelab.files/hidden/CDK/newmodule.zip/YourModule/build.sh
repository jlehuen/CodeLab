#!/bin/bash
#####################################################################
## This file is part of the software CodeLab IDE and Simulators    ##
## For any question about CodeLab e-mail to codelab@univ-lemans.fr ##
#####################################################################

## DO NOT DELETE, MODIFY OR MOVE THIS SCRIPT !!

#########################################################
# Retrieving some values
#########################################################

BASE=$(pwd)
CODELAB_FILES=$(cd ../../; pwd)
INFOS=$CODELAB_FILES/.hidden/infos.txt
JAVA_HOME=$(grep "^JAVA_HOME" $INFOS | cut -d'=' -f2)
CLASSNAME=$(basename "$BASE")
CLASSNAME_LOWER=$(echo "$CLASSNAME" | tr '[:upper:]' '[:lower:]')
PACKAGE=codelab/modules/$CLASSNAME_LOWER
MODULE=$CLASSNAME.pac
CLS="printf \33c\e[3J"

JAR=$JAVA_HOME/bin/jar
JAVA=$JAVA_HOME/bin/java
JAVAC=$JAVA_HOME/bin/javac
CLASSPATH=class:lib/*

#########################################################
# Displaying some information
#########################################################

$CLS
echo ---------------------------------------------------
echo "CODELAB_FILES=$CODELAB_FILES"
echo "JAVA_HOME=$JAVA_HOME"
echo "BASE=$BASE"
echo "PACKAGE=$PACKAGE"
echo "MODULE=$MODULE"
echo ---------------------------------------------------

#########################################################
# Compiling the Java files
#########################################################

echo "Compiling the Java files..."

rm -rf class/*
set -e
$JAVAC -encoding UTF8 \
	-classpath $CLASSPATH \
	-sourcepath src \
	-d class \
	src/$PACKAGE/*.java

#########################################################
# Generating the libraries
#########################################################

echo "Generating the libraries..."

cd includes
for fname in *.xml; do
	[ -f "$fname" ] || continue
	echo "   $fname"
	$JAVA -jar ../lib/codelab.jar Parser $fname
done

#########################################################
# Packaging the module
#########################################################

echo "Packaging the module..."

cd ..
cp -r data class
cp -r includes class
cp -r templates class
cp -r exercices class
find class -name *.DS_Store -delete

cd class
for fname in ../lib/*.jar; do
	[ -f "$fname" ] || continue
	$JAR -xf $fname
done

rm -rf META-INF
$JAR cf $MODULE $PACKAGE *
mv $MODULE $CODELAB_FILES/modules

#########################################################
# That's All Folks
#########################################################

cd ..
echo ---------------------------------------------------
echo "A new plugin '$MODULE' was generated"
echo "Have a look into $CODELAB_FILES/modules"
echo "Restart CodeLab"
echo "Have fun!"
echo
