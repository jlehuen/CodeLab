/*
 * Class _className_
 * Created by _author_ on _date_
 */

import codelab.yourmodule.yourAPI;

class _className_ extends yourAPI {

	private void run() {
		setFont("Serif", 100);
		setText("Hello World!");
	}

	public static void main(String args[]) {
		new _className_().run();
	}
}
