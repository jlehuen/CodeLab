/*
 * Program _fileName_
 * Created by _author_ on _date_
 */

#include "codelab/yourmodule/yourAPI.c"

void main() {
	setFont("Serif", 100);
	setText("Hello World!");
}
