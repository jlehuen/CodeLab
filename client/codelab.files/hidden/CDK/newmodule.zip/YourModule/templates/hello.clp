;; Program _fileName_
;; Created by _author_ on _date_

#requires codelab.yourmodule.yourAPI

(defrule only-rule
	=>
	(setFont "Serif" 100)
	(setText "Hello World!")
)
