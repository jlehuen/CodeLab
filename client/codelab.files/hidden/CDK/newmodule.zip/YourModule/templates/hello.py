## Program _fileName_
## Created by _author_ on _date_

from codelab.yourmodule.yourAPI import *

setFont('Serif', 100)
setText('Hello World!')
