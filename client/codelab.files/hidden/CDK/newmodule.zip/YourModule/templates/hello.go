// Program _fileName_
// Created by _author_ on _date_

package main

import (yourmodule "codelab/yourmodule/yourAPI")

func main() {
	yourmodule.SetFont("Serif", 100)
	yourmodule.SetText("Hello World!")
}
