:: #####################################################################
:: ## This file is part of the software CodeLab IDE and Simulators    ##
:: ## For any question about CodeLab e-mail to codelab@univ-lemans.fr ##
:: #####################################################################

:: DO NOT DELETE, MODIFY OR MOVE THIS SCRIPT !!

@ECHO OFF & SETLOCAL ENABLEEXTENSIONS ENABLEDELAYEDEXPANSION

:: #########################################################
:: Retrieving some values
:: #########################################################

:: Base directory
SET "BASE=%~dp0"

:: User directory
CD /d "..\..\"
SET CODELAB_FILES=%CD%

:: Java directory
FINDSTR /I "JAVA_HOME" %CODELAB_FILES%\.hidden\infos.txt > tmp
SET /p "TEMP=" < tmp
DEL tmp
SET JAVA_HOME=%TEMP:~10%

:: Package name
CALL :basename %BASE% CLASSNAME
SET PACKAGE=codelab\modules\%CLASSNAME%
CALL :tolower PACKAGE

:: Module name
SET MODULE=%CLASSNAME%.pac

SET JAR=%JAVA_HOME%\bin\jar
SET JAVA=%JAVA_HOME%\bin\java
SET JAVAC=%JAVA_HOME%\bin\javac
SET CLASSPATH=class;lib\*

:: #########################################################
:: Displaying some information
:: #########################################################

ECHO ---------------------------------------------------
ECHO CODELAB_FILES=%CODELAB_FILES%
ECHO JAVA_HOME=%JAVA_HOME%
ECHO BASE=%BASE%
ECHO PACKAGE=%PACKAGE%
ECHO MODULE=%MODULE%
ECHO ---------------------------------------------------

:: #########################################################
:: # Compiling the Java files
:: #########################################################

ECHO Compiling the Java files...

CD %BASE%
DEL /S /F /Q class\* 1>nul
%JAVAC% -encoding UTF8 ^
	-classpath %CLASSPATH% ^
	-sourcepath src ^
	-d class ^
	src\%PACKAGE%\*.java

:: #########################################################
:: # Generating the libraries
:: #########################################################

ECHO Generating the libraries...

CD includes
FOR %%i in (*.xml) DO (
	@ECHO %%i
	%JAVA% -jar ..\lib\codelab.jar Parser %%i
)

:: #########################################################
:: # Packaging the module
:: #########################################################

ECHO Packaging the module...

CD ..
ROBOCOPY /S data class\data 1>nul
ROBOCOPY /S includes class\includes 1>nul
ROBOCOPY /S templates class\templates 1>nul
ROBOCOPY /S exercices class\exercices 1>nul

CD class
FOR %%i in (..\lib\*.jar) DO (
	%JAR% -xf %%i
)

RMDIR /S /Q META-INF
%JAR% cf %MODULE% %PACKAGE% *
MOVE %MODULE% %CODELAB_FILES%\modules 1>nul

:: #########################################################
:: That's All Folks
:: #########################################################

CD ..
ECHO ---------------------------------------------------
ECHO A new plugin '%MODULE%' was generated
ECHO Have a look into %CODELAB_FILES%\modules
ECHO Restart CodeLab
ECHO Have fun!
PAUSE
EXIT

:tolower
	FOR %%L IN (^^ a b c d e f g h i j k l m n o p q r s t u v w x y z) DO SET %1=!%1:%%L=%%L!
GOTO :EOF

:basename
    SETLOCAL ENABLEEXTENSIONS ENABLEDELAYEDEXPANSION
    SET _dir=%~dp1
    SET _dir=%_dir:~0,-1%
    ENDLOCAL & FOR %%i IN ("%_dir%") DO SET %2=%%~nxi
GOTO :EOF

:dirname
    SETLOCAL ENABLEEXTENSIONS ENABLEDELAYEDEXPANSION
    SET _dir=%~dp1
    SET _dir=%_dir:~0,-1%
    ENDLOCAL & FOR %%i IN ("%_dir%") DO SET %2=%%~dpi
GOTO :EOF
