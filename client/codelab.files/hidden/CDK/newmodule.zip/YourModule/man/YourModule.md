<style>
img[alt=center] {
	display: block;
	margin: 0 auto;
}
</style>

![](./img/logo.png)

# CodeLab IDE & Simulators

# Module name (`PluginModule`)

Le module **PluginModule** etc. etc.

![center](img/screenshot.png)

## Sommaire

1. [Objectifs Pédagogiques](#1-objectifs-pédagogiques)
2. [Title 2](#2-Title-2)
3. [Title 3](#3-Title-3)
4. [Référence Complète de l'API](#4-référence-complète-de-lapi)
5. [Exemples Didactiques Progressifs](#5-exemples-didactiques-progressifs)
6. [Défis & Sujets d'Exercices](#6-défis--sujets-dexercices)

---

## 1. Objectifs Pédagogiques

bla bla bla

---

## 2. Title 2

bla bla bla

---

## 3. Title 3

bla bla bla

---

## 4. Référence Complète de l'API

bla bla bla

---

## 5. Exemples Didactiques Progressifs

### Exemple 1 :

bla bla bla

---

### Exemple 2 :

bla bla bla

---

### Exemple 3 :

bla bla bla

---

## 6. Défis & Sujets d'Exercices

bla bla bla

<br/>
<center>
Document under Creative Commons License CC-BY-NC-ND
<br/>Copyright &copy; Jérôme Lehuen, Le Mans Université, France
<br/>
<br/>![](img/licence.png)
</center>

